/********************************************************************
 * Project:    STM32-Stick
 * File:       uart.h
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2006/12/20      Gn  Initial revision
 *    Revision 1.1    2007/04/9       HS  Updated for STM32-Stick
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#ifndef __UART_H__
#define __UART_H__

#include "stm32f10x_lib.h"

extern void UART_Configuration (void);
extern void UART_Stop (void);
extern int  UART_SendData (u8 *str, u32 len);
extern int  UART_ReadData (u8 *ch);
extern void UART3_isr (void);

extern bool data_received, command_received, rx_error,\
            command_reply, int_ready;

extern u32 TxHead;
extern u32 TxTail;

extern u32 RxHead;
extern u32 RxTail;
#endif   /* __UART_H__ */

