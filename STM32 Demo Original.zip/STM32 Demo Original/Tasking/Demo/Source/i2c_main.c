/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       I2C_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "uart.h"
#include "system.h"
#include "I2C_main.h"



// Globals

TaskInfo I2CState;
/* buffer for receive messages */
i2cmsg RxI2CMsg, I2CMsg;
ErrorStatus I2CErr = SUCCESS;
u8 I2C_Mode = 0;//I2C_Mode_Slave|I2C_Mode_7bit;

//static u8 I2Csendbufptr = 0;

// running checksum count for transmission of UCAN messages to PC
//static u8 I2Csend_checksum;

// if <>0 system is set to record incoming CAN messages
u8 I2Cspy_record;

// ringbuffer with read/write pointers for recording incoming CAN messages
i2cspy_t i2cspy_buf[I2CSPY_BUF_SIZE];
i2cspy_t i2crcv_buf;
volatile int i2cspy_buf_write;
volatile int i2cspy_buf_read;

i2c_msg_t i2c_msg;

// millisecond-timer for generator
volatile u16 i2cgenerate_countdown; // timer
volatile u16 i2cgenerate_repeat; // reload value

// if <>0 then CAN is in loopback mode
//static u8 loopback;

//****************************************************************************
// Prototypes Of Local Functions
//****************************************************************************

static void SendStart(u8 id, u16 length);
static void SendByte(u8 databyte);
static void SendWord(u16 dataword);
//static void SendLong(u32 datalong);
static void SendString(char *string, u8 length);
static void SendChecksum(void);

static void RecvMsg_I2CStatus(void);
static void RecvMsg_I2CSpy(void);
static void RecvMsg_I2CGenerator(void);

static void I2CSendMsg_Status(void);

static void RecvMsg_I2CStatus(void)
{
}
static void RecvMsg_I2CSpy(void)
{
}
static void RecvMsg_I2CGenerator(void)
{
}
/*
static void I2CSendMsg_Status(void)
{
}
*/
/*-----------------------------------------------------------------------------------*/
void I2C_Start(void)
{


   I2CState.enabled = TRUE;
}
void I2C_Stop(void)
{


   I2CState.enabled = FALSE;
}

/*-----------------------------------------------------------------------------------*/

void CommI2C (void)
{
   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_I2C : /* GUI Status request of the CAN enabled */
                           protocol_SendFrame (Rep_Info_I2C, (u8 *)(I2CState.enabled+1),1);
                           break;
    case Cmd_I2C_Msg :     /* 12 GUI container for CAN message */
                           CommTask->Command = Cmd_Idle;  /* none */

                           i2c_msg.i2c_id = CommTask->Data[0];
                           i2c_msg.i2c_checksum = CommTask->Data[0];
                           i2c_msg.i2c_data_length = CommTask->Data[1] + (CommTask->Data[2]<<8);
                           i2c_msg.i2c_checksum += CommTask->Data[1];
                           i2c_msg.i2c_checksum += CommTask->Data[2];

                           // command structure of UCAN
                           switch (i2c_msg.i2c_id) {
                             case I2C_ID_STATUS:
                                                  RecvMsg_I2CStatus();
                                                  break;
                             case I2C_ID_CANSPY:
                                                  i2c_msg.i2c_spy_cmd = CommTask->Data[3];
                                                  RecvMsg_I2CSpy();
                                                  break;
                             case I2C_ID_I2CGENERATOR:
                                                  RecvMsg_I2CGenerator();
                                                  break;
                             default:             // unsupported ID
                                                  break;
                             }
                           break;
    case Cmd_Get_I2C_Mode :/* 0 GUI requests the mode of the CAN controler */
                           protocol_SendFrame (Rep_Info_I2C_Mode, (u8 *)I2C_Mode,2);
                           break;
    case Cmd_Set_I2C_Mode :/* 1 GUI select the mode of the CAN controler */
                           CommTask->Command = Cmd_Idle;  /* none */
                           CommTask->DataLength = 0;
                           I2C_Mode = CommTask->Data[0];
                           I2C_Stop();
                           I2C_Start();
                           break;
    case Cmd_Enable_I2C  : /* GUI Start/Stop the CAN */
                           SendTask->ReplyNew = FALSE;
                           if (CommTask->Data[0] == TaskSwitchOn)
                              {
                              I2C_Start();
                              }
                           else
                              {
                              I2C_Stop();
                              }
                           break;
    default :              /* not implemented */
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}
