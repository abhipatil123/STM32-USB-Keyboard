/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       I2C_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


/* Define to prevent recursive inclusion ------------------------------------ */
#ifndef __I2C_MAIN_H
#define __I2C_MAIN_H

#include "i2c_protocol.h"

#define I2C_RECV_DATABUF_SIZE  16
#define I2CSPY_BUF_SIZE  4

/* CAN message structure*/
typedef struct
{
   u32 IdType;
   u32 Id;
   u8 Dlc;
   u8 Data[8];
} i2cmsg;

typedef struct
{
   u8 extended_type;
   u8 remoterequest;
   u8 error;
   u8 dropped;
   u8 dlc;
   u32 id;
   u8 data[8];
} i2cspy_t;

union time_32 {
   float f;
   u8    c[4];
};
// complete ucan message
typedef struct
{
   u8 i2c_id;
   u8 i2c_checksum;
   u16 i2c_data_length;
   u8 i2c_can_lenght;
   u8 i2c_spy_cmd;
   u8 i2cspy_record;
   u8 i2c_generator;
   i2cspy_t can;
   u16 time;
   u8 timestamp[2];
   union time_32 time_stamp;
   float last_time;
} i2c_msg_t;


extern TaskInfo I2CState;

extern void I2CStart(void);

#endif /* __I2C_MAIN_H */
