/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       power_main.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


/* Define to prevent recursive inclusion ------------------------------------ */
#ifndef __POWER_MAIN_H
#define __POWER_MAIN_H
/* Clock Gating settings bit coding */
/* byte 0 */
#define Gating_Mask_USART1       0x01<<6  /*	0: USART1 clock disabled 1: USART1 clock enabled */
#define Gating_Mask_SPI          0x01<<4  /*	0: SPI 1 clock disabled 1: SPI 1 clock enabled */
#define Gating_Mask_TIM1         0x01<<3  /*	0: TIM1 timer clock disabled 1: TIM1 timer clock enabled */
#define Gating_Mask_ADC2         0x01<<2  /*	0: ADC 2 interface clock disabled 1: ADC 2 interface clock enabled */
#define Gating_Mask_ADC1         0x01<<1  /*	0: ADC 1 interface disabled 1: ADC 1 interface clock enabled */
/* byte 1 */
#define Gating_Mask_IOPE         0x01<<6  /*	0: I/O port E clock disabled 1: I/O port E clock enabled */
#define Gating_Mask_IOPD         0x01<<5  /*	0: I/O port D clock disabled 1: I/O port D clock enabled */
#define Gating_Mask_IOPC         0x01<<4  /*	0: I/O port C clock disabled 1: I/O port C clock enabled */
#define Gating_Mask_IOPB         0x01<<3  /*	0: I/O port B clock disabled 1: I/O port B clock enabled */
#define Gating_Mask_IOPA         0x01<<2  /*	0: I/O port A clock disabled 1: I/O port A clock enabled */
#define Gating_Mask_AFIO         0x01<<0  /*	0: I/O AFIO clock disabled 1: I/O AFIO clock enabled */
/* byte 2 */
#define Gating_Mask_PWR          0x01<<4  /*	0: Power interface clock disabled 1: Power interface clock enable */
#define Gating_Mask_BKP          0x01<<3  /*	0: Backup interface clock disabled 1: Backup interface clock enabled */
#define Gating_Mask_CAN          0x01<<1  /*	0: CAN clock disabled 1: CAN clock enabled */
/* byte 3 */
#define Gating_Mask_USB          0x01<<7  /*	0: USB clock disabled 1: USB clock enabled */
#define Gating_Mask_I2C2         0x01<<6  /*	0: I2C2 clock disabled 1: I2C2 clock enabled */
#define Gating_Mask_I2C1         0x01<<5  /*	0: I2C1 clock disabled 1: I2C1 clock enabled */
#define Gating_Mask_USART3       0x01<<2  /*	0: USART3 clock disabled 1: USART3 clock enabled */
#define Gating_Mask_USART2       0x01<<1  /*	0: USART2 clock disabled 1: USART2 clock enabled */
/* byte 4 */
#define Gating_Mask_SPI2         0x01<<6  /*	0: SPI2 clock disabled 1: SPI2 clock enabled */
#define Gating_Mask_WWDG         0x01<<3  /*	0: Window watchdog clock disabled 1: Window watchdog clock enabled */
/* byte 5 */
#define Gating_Mask_TIM4         0x01<<2  /*	0: Timer 4 clock disabled 1: Timer 4 clock enabled */
#define Gating_Mask_TIM3         0x01<<1  /*	0: Timer 3 clock disabled 1: Timer 3 clock enabled */
#define Gating_Mask_TIM2         0x01<<0  /*	0: Timer 2 clock disabled 1: Timer 2 clock enabled */
/* ---------------------------------------------------------------------------------------------------------------- */
#define RCC_APB2ENR_Mask        (((Gating_Mask_USART1 | Gating_Mask_SPI | Gating_Mask_TIM1 | Gating_Mask_ADC2 | \
                                 Gating_Mask_ADC1) << 8) | \
                                 Gating_Mask_IOPE | Gating_Mask_IOPD | Gating_Mask_IOPC | \
                                 Gating_Mask_IOPA | Gating_Mask_AFIO)
#define RCC_APB2ENR_Must        (RCC_APB2Periph_GPIOA  | RCC_APB2Periph_GPIOB | \
                                 RCC_APB2Periph_GPIOC  | RCC_APB2Periph_GPIOD | \
                                 RCC_APB2Periph_ADC1   | RCC_APB2Periph_AFIO )
#define RCC_APB1ENR_Mask        (((Gating_Mask_PWR  | Gating_Mask_BKP  | Gating_Mask_CAN)<<24) | \
                                 ((Gating_Mask_USB  | Gating_Mask_I2C2 | Gating_Mask_I2C1 | \
                                   Gating_Mask_USART2)<<16) | \
                                  (Gating_Mask_SPI2<<8) | \
                                   Gating_Mask_TIM4 | Gating_Mask_TIM3 | Gating_Mask_TIM2)
//#define RCC_APB1ENR_Must       ((Gating_Mask_USART3<<16)|(Gating_Mask_WWDG<<8))  /* Gating_Mask_USART3 must be enabled */
#define RCC_APB1ENR_Must        (RCC_APB1Periph_USART3 | RCC_APB1Periph_WWDG | \
                                 RCC_APB1Periph_PWR    | RCC_APB1Periph_BKP  | \
                                 RCC_APB1Periph_TIM2   | RCC_APB1Periph_USB)
/* ---------------------------------------------------------------------------------------------------------------- */
/* Power Mode settings bit coding */
#define Power_Mode_Running       0x01  /* normal mode */
#define Power_Mode_Sleep         0x02  /* Sleep Mode */
#define Power_Mode_Stop          0x03  /* Stop Mode */
#define Power_Mode_Standby       0x04  /* Standby */
#define Power_Mode_RTC_Alarm     0x05  /* RTC Alarm */
#define Power_Mode_Mask          0x3E  /* relevant bits in the Power Mode */
/* ---------------------------------------------------------------------------------------------------------------- */
/* Wake Up settings bit coding */
#define WakeUp_Set_ExtInt        0x01 	/* EXTInt will wake up the processor */
#define WakeUp_Set_USART         0x02 	/* USART will wake up the processor */
#define WakeUp_Set_RTCAlarm      0x03 	/* RTC Alarm will wake up the processor */
#define WakeUp_Set_WakeupPin     0x04 	/* WakeUp Pin will wake up the processor */
#define WakeUp_Set_Reset         0x05 	/* Reset will wake up the processor */
#define WakeUp_Set_Mask          0x3E   /* relevant bits in the Power Mode */
/* ---------------------------------------------------------------------------------------------------------------- */
/* LED blink, on, off states */
#define LED_Off                  0x01   /* LED is off */
#define LED_On                   0x02   /* LED is on */
#define LED_Blink_On             0x03   /* LED is blinking */
/* ---------------------------------------------------------------------------------------------------------------- */
/* CFGR register bit mask */
#define CFGR_PLL_Mask            ((u32)0xFFC0FFFF)
#define CFGR_PLLMull_Mask        ((u32)0x003C0000)
#define CFGR_PLLSRC_Mask         ((u32)0x00010000)
#define CFGR_PLLXTPRE_Mask       ((u32)0x00020000)
#define CFGR_SWS_Mask            ((u32)0x0000000C)
#define CFGR_SW_Mask             ((u32)0xFFFFFFFC)
#define CFGR_HPRE_Reset_Mask     ((u32)0xFFFFFF0F)
#define CFGR_HPRE_Set_Mask       ((u32)0x000000F0)
#define CFGR_PPRE1_Reset_Mask    ((u32)0xFFFFF8FF)
#define CFGR_PPRE1_Set_Mask      ((u32)0x00000700)
#define CFGR_PPRE2_Reset_Mask    ((u32)0xFFFFC7FF)
#define CFGR_PPRE2_Set_Mask      ((u32)0x00003800)
#define CFGR_ADCPRE_Reset_Mask   ((u32)0xFFFF3FFF)
#define CFGR_ADCPRE_Set_Mask     ((u32)0x0000C000)
/* ---------------------------------------------------------------------------------------------------------------- */
/* function protoypes */
extern void USART_Configuration(void);
extern void EXTI2_IRQHandler(void);
extern void RCC_Configuration(void);
extern void GPIO_Configuration(void);

#endif /* __POWER_MAIN_H */
