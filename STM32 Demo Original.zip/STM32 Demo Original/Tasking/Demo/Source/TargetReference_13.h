/* Hitex Development Tools GmbH Gn                19.08.2007   */
/* Communication References for STM32-Stick                    */
/* target communication definitions                            */
/* process params                                              */

#ifndef __TARGET_REF_H__
#define __TARGET_REF_H__

#define   HW_Version                   0x00000001
#define   FW_Version                   0x0105;

#define   Target_Initial_String        "STM32-Target"
#define   Target_Initial_String_Length 12

#define   HardwareVersion              1
#define   Ext_None                     0
#define   Ext_IOBrd                    1
#define   Ext_SensorBrd                2
#define   Ext_BluetoothBrd             3
#define   Ext_PatchBrd                 4
#define   Ext_Unknown                  10

#define   ADC1_DR_Address              ((u32)0x4001244C)

#define   MSG_FrameType_S              0xFE   /* Defines frame type S (supply) */
#define   MSG_FrameType_T              0xFF   /* Defines frame type T (target) */

#define   TaskSwitchOff                0x01   /* bit coding off state */
#define   TaskSwitchOn                 0x02   /* bit coding on state */

/* idle message */
#define   MSG_Idle                     0x00   /* No message */
#define   Cmd_Idle                     0x00

/* Error and condition numbers (MSG_Error) */
#define   Err_Unknown                  0x00   /* Unknown error */
#define   Err_Checksum                 0x01   /* Frame incorrect checksum */
#define   Err_NotImplemented           0x02   /* Not implemented message */


/*        Function                     ID       Length typ Initiator   Purpose   */
/*      General ?4.1                     */
#define   Cmd_SWReset                  0x0F   /*   0   T   GUI   Software-reset the device   */
#define   Rep_Initial_String           0x0A   /*   Str-Length   T   App   Identification after Reset   */
#define   Cmd_Get_Setup                0x0B   /*   0   T   GUI   Request for Hardware stet and adapter   */
#define   Rep_Info_Setup               0x0B   /*   4   T   App   Reply of Hardware set and adapter   */
#define   Cmd_GUI_present              0x0C   /*   0   T   GUI   Tell the application the presence of the GUI   */
#define   Cmd_Dummy                    0x01   /*   X   T   GUI   Generally ignored   */
#define   Rep_MSG_TimedOut             0x02   /*   0   T   App   Message was timed out   */
#define   Rep_Error                    0x03   /*   1   T   App   Some error and condition number   */
#define   Cmd_Get_Firmware_Version     0x05   /*   0   T   GUI   Request the Version of the firmware   */
#define   Rep_Info_Firmware_Version    0x05   /*   2   T   App   Reply the Version of the firmware   */
/*      Power ?4.2                     */
#define   Cmd_Get_PLL_Settings         0x10   /*   0   T   GUI   Status request of the PLL   */
#define   Rep_Info_PLL_Settings        0x10   /*   5   T   App   PLL state   */
#define   Cmd_Get_Power_Mode           0x11   /*   0   T   GUI   Request the Power Mode settings   */
#define   Rep_Info_Power_Mode          0x11   /*   2   T   App   Reply Power Mode settings   */
#define   Cmd_Set_Power_Mode           0x12   /*   2   T   GUI   Set the Power Mode   */
#define   Cmd_Get_Periph_Gating        0x13   /*   0   T   GUI   Request the peripheral Gating set   */
#define   Rep_Info_Periph_Gating       0x13   /*   6   T   App   Reply the peripheral Gating set   */
#define   Cmd_Set_Periph_Gating        0x14   /*   6   T   GUI   Set the peripheral Gating   */
#define   Cmd_Set_PLL_Settings         0x15   /*   5   T   GUI   Set the PLL and clock divider */

#define   Cmd_Get_CPU_Clock            0x16   /*   0   S   GUI   Request CPU Clock State */
#define   Rep_Info_CPU_Clock           0x16   /*   1   S   App   Reply CPU Clock State */
#define   Cmd_Set_CPU_Clock            0x17   /*   1   S   GUI   Set CPU clock state */
#define   Cmd_Get_Backup_Data          0x18   /*   0   T   GUI   Request for Backup Data */
#define   Rep_Info_Backup_Data         0x18   /*   10  T   App   Reply for Backup Data */
#define   Cmd_Set_Backup_Data          0x19   /*   0   T   GUI   Set of Backup Data */
#define   Cmd_Get_RTC                  0x1A   /*   0   T   GUI   Request the RTC settings   */
#define   Rep_Info_RTC                 0x1A   /*   4   T   App   Reply the RTC settings   */
#define   Cmd_Set_RTC                  0x1B   /*   4   T   GUI   Set the RTC s,m,h,d,d,d,m,y   */
#define   Cmd_Get_RTC_Alarm            0x1C   /*   0   T   GUI   Request the RTC Alarm settings   */
#define   Rep_Info_RTC_Alarm           0x1C   /*   4   T   App   Reply the RTC Alarm settings   */
#define   Cmd_Set_RTC_Alarm            0x1D   /*   4   T   GUI   Set the RTC Alarm   */
#define   Cmd_Set_Stick_LED            0x1E   /*   1   T   GUI   Set the LED mode off, on, blink */
/*      Standalone ?4.3                     */
#define   Cmd_Get_SA                   0x20   /*   0   T   GUI   Request Stand alone features   */
#define   Rep_Info_SA                  0x20   /*   length   T   App   Reply Stand alone features   */
#define   Cmd_Set_SA                   0x21   /*   length   T   GUI   Set Stand alone features   */
#define   Cmd_Reset_SA                 0x22   /*   0   T   GUI   Reset/delete all Stand Alone Features   */
#define   Rep_Info_Reset_SA            0x22   /*   0   T   App   Reset/delete all Stand Alone Features done   */
/*      Flash ?4.4                     */
#define   Cmd_Flash_Reset              0x22   /*   0   T   GUI   Reset the Flash address   */
#define   Cmd_Protect_Flash            0x23   /*   1   T   GUI   Set/reset FLASH protection   */
#define   Cmd_Fill_FLASH               0x25   /*   0   T   GUI   Fill FLASH with numbers   */
#define   Cmd_Flash_Read               0x26   /*   length   T   GUI   Read flash (address, length)   */
#define   Rep_Flash_Data               0x26   /*   length   T   App   Reply with data from flash   */
#define   Cmd_Flash_Write              0x27   /*   length   T   GUI   Write to flash (address, length, data)   */
#define   Rep_Info_Flash_Write         0x27   /*   0   T   App   Write to flash finished   */
#define   Cmd_Erase_Flash              0x28   /*   8   T   GUI   Erase flash (address, length)   */
#define   Rep_Erase_Flash              0x28   /*   0   T   App   Erase flash (address, length)   */
/*      Application ?4.5                     */
#define   Cmd_Start_Appl               0x31   /*   1   S   GUI   Start Application Number */
#define   Cmd_Get_IRQ_Occ              0x33   /*   0   S   GUI   Request IRQ Occurrence 1-255 */
#define   Rep_Info_IRQ_Occ             0x33   /*   1   S   GUI   Reply IRQ Occurrence 1-255 */
#define   Cmd_Set_IRQ_Occ              0x34   /*   1   S   GUI   Set IRQ Occurrence 1-255 */
#define   Cmd_Get_ExeTime              0x35   /*   0   S   GUI   Request ExecTime */
#define   Rep_Info_ExeTime             0x35   /*   4   S   App   Reply ExecTime */
/*      USB ?4.5                     */
#define   Cmd_Get_USB                  0x40   /*   0   T   GUI   Status request of the USB enabled, Application and Enumeration   */
#define   Cmd_Enable_USB               0x45   /*   1   T   GUI   Start/Stop the USB   */
#define   Cmd_Get_VIDPID_Str           0x41   /*   0   T   GUI   Request of VID and PID   */
#define   Cmd_Get_Serial_Str           0x42   /*   0   T   GUI   Request of serial Nr string descriptor   */
#define   Cmd_Get_Prod_Str             0x43   /*   0   T   GUI   Request of product string descriptor   */
#define   Cmd_Get_Pwr_Def              0x44   /*   0   T   GUI   Request of Power definitions   */
#define   Cmd_Get_Version              0x46   /*   0   T   GUI   Request of Version descriptor   */
#define   Cmd_Enable_USB_APP           0x47   /*   1   T   GUI   Start/Stop the USB-Application (Mouse)   */
#define   Cmd_Get_Poll_Intervall       0x48   /*   0   T   GUI   Request the polling interval   */
#define   Cmd_Get_Config_Application   0x49   /*   0   T   GUI   Request the applications parameter   */
#define   Rep_Info_USB                 0x40   /*   1   T   App   Answer to status request and enumeration   */
#define   Rep_Info_VIDPID_str          0x41   /*   4   T   App   Answer to VID/PID request   */
#define   Rep_Info_Serial_Str          0x42   /*   Str Length   T   App   Answer to Serial String request   */
#define   Rep_Info_Prod_Str            0x43   /*   Str Length   T   App   Answer to Product String request   */
#define   Rep_Info_Pwr_Def             0x44   /*   2   T   App   Answer to Power definitions request   */
#define   Rep_Info_Version             0x46   /*   2   T   App   Answer to Version request   */
#define   Rep_Info_Poll_Intervall      0x48   /*   1   T   App   Reply the polling interval   */
#define   Rep_Info_Config_Application  0x49   /*   4   T   App   Reply the applications parameter   */
#define   Cmd_Set_Config_Application   0x4A   /*   4   T   GUI   Set the applications parameter   */

/*      Measurement ?4.6                     */
#define   Cmd_Get_Temp                 0x50   /*   0   T   GUI   Request Temperatur   */
#define   Rep_Info_Temp                0x50   /*   1   T   App   Request Temperatur   */
#define   Cmd_Get_VU1                  0x51   /*   0   T   GUI   Request State and value VU1   */
#define   Rep_Info_VU1                 0x51   /*   3   T   App   Reply State and value VU1   */
#define   Cmd_Enable_VU1               0x52   /*   1   T   GUI   Enable/Disable VU1   */
#define   Cmd_Get_Amb_Light            0x53   /*   0   T   GUI   Request State and value Sensor   */
#define   Rep_Info_Amb_Light           0x53   /*   3   T   App   Reply State and value sensor   */
#define   Cmd_Enable_Amb_Light         0x54   /*   1   T   GUI   Enable/Disable Sensor   */
#define   Cmd_Get_Trigger              0x55   /*   0   T   GUI   Request of trigger settings   */
#define   Rep_Info_Trigger             0x55   /*   1   T   App   Reply of trigger settings   */
#define   Cmd_Set_Trigger              0x56   /*   1   T   GUI   Set trigger settings   */
#define   Cmd_Get_Scanner              0x57   /*   0   T   GUI   Request Scanner State   */
#define   Rep_Info_Scanner             0x57   /*   1   T   App   Reply Scanner State   */
#define   Cmd_Enable_Scanner           0x58   /*   1   T   GUI   Enable/Disable Scanner and mode   */
#define   Cmd_Get_Meassurement         0x59   /*   0   T   GUI   Request the scanner data   */
#define   Rep_Info_Meassurement        0x59   /*   4   T   App   Reply the scanner data   */
#define   Cmd_Get_Spectrum             0x5A   /*   0   T   GUI   Request the state of Spectrum   */
#define   Rep_Info_Spectrum            0x5A   /*   1   T   App   Reply Spectrum State   */
#define   Cmd_Enable_Spectrum          0x5B   /*   1   T   GUI   Enable/Disable Spectrum   */
#define   Cmd_Get_Spectrum_Data        0x5C   /*   0   T   GUI   Request the Spectrum data   */
#define   Rep_Info_Spectrum_Data       0x5C   /*   128   T   App   Reply the Spectrum data   */
#define   Cmd_Get_Oversampling         0x5D   /*   0   T   GUI   Request the state Oversampling   */
#define   Rep_Info_Oversampling        0x5D   /*   1   T   App   Reply Overampling State   */
#define   Cmd_Enable_Oversampling      0x5E   /*   1   T   GUI   Enable/Disable Oversampling   */
/*      I2C ?4.7                     */
#define   Cmd_Get_I2C                  0x60   /*   0   T   GUI   Status request of the I2C enabled   */
#define   Rep_Info_I2C                 0x60   /*   1   T   App   I2C module state   */
#define   Cmd_I2C_Msg                  0x61   /*   length   T   GUI   Message to the I2C Module,Message to the GUI   */
#define   Rep_I2C_Msg                  0x61   /*   length   T   App   Message to the I2C Module,Message to the GUI   */
#define   Cmd_Get_I2C_Mode             0x62   /*   0   T   GUI   Request the mode of the I2C   */
#define   Rep_Info_I2C_Mode            0x62   /*   2   T   App   Reply I2C _Get Mode   */
#define   Cmd_Set_I2C_Mode             0x63   /*   2   T   GUI   Set the I2C mode   */
#define   Cmd_Enable_I2C               0x65   /*   1   T   GUI   Start/Stop the I2C   */

/*      CAN ?4.8                     */
#define   Cmd_Get_CAN                  0x70   /*   0   T   GUI   Status request of the CAN enabled   */
#define   Rep_Info_CAN                 0x70   /*   1   T   App   CAN module state   */
#define   Cmd_CAN_Msg                  0x71   /*   12  T  GUI container for CAN message */
#define   Rep_CAN_Msg                  0x71   /*   12   T   GUI, App   Message to the CAN Module,Message to the GUI   */
#define   Cmd_Get_CAN_Mode             0x72   /*   0   T   GUI   Request the mode of the CAN   */
#define   Rep_Info_CAN_Mode            0x72   /*   2   T   App   Reply CAN_Get Mode   */
#define   Cmd_Set_CAN_Mode             0x73   /*   2   T   GUI   Set the CAN mode   */
#define   Cmd_Enable_CAN               0x75   /*   1   T   GUI   Start/Stop the CAN   */

/*      IO ?4.9                     */
#define   Cmd_Get_IO_FktA              0x90   /*   0   T   GUI   Request of IO A function   */
#define   Rep_Info_IO_FktA             0x90   /*   8   T   App   Reply of IO A function   */
#define   Cmd_Set_IO_FktA              0x91   /*   8   T   GUI   Settings for IO A function   */
#define   Cmd_Get_IO_FktB              0x92   /*   0   T   GUI   Request of IO B function   */
#define   Rep_Info_IO_FktB             0x92   /*   8   T   App   Reply of IO B function   */
#define   Cmd_Set_IO_FktB              0x93   /*   8   T   GUI   Settings for IO B function   */
#define   Cmd_Get_IO_FktC              0x94   /*   0   T   GUI   Request of the IO function   */
#define   Rep_Info_IO_FktC             0x94   /*   8   T   App   Reply of IO C function   */
#define   Cmd_Set_IO_FktC              0x95   /*   8   T   GUI   Settings for IO C function   */
#define   Cmd_Get_IO_FktD              0x96   /*   0   T   GUI   Request of IO D function   */
#define   Rep_Info_IO_FktD             0x96   /*   8   T   App   Reply of IO D function   */
#define   Cmd_Set_IO_FktD              0x97   /*   8   T   GUI   Settings for IO D function   */

#define   Cmd_Get_ADC                  0x98   /*   1   T   GUI   Request ADC channel   */
#define   Rep_Info_ADC                 0x98   /*   2   T   App   Reply requested ADC channel   */

#define   Cmd_Get_EXTInt               0x99   /*   0   T   GUI   Request ExtInt settings   */
#define   Rep_Info_EXTInt              0x99   /*   4   T   App   Reply ExtInt settings   */
#define   Cmd_Set_EXTInt               0x9A   /*   4   T   GUI   Set ExtInt settings   */
#define   Cmd_Get_PORT                 0x9B   /*   0   T   GUI   Request Input portx   */
#define   Rep_Info_PORT                0x9B   /*   4   T   App   Reply Input portx   */
#define   Cmd_Set_PORT                 0x9C   /*   4   T   GUI   Set Output portx   */
#define   Cmd_Get_Alternate            0x9D   /*   0   T   GUI   Request Alternate functions   */
#define   Rep_Info_Alternate           0x9D   /*   4   T   App   Reply Alternate functions   */
#define   Cmd_Set_Alternate            0x9E   /*   4   T   GUI   Set Alternate functions   */

/*      UART/IRDA/RC ?4.10                     */
#define   Cmd_Get_UIR                  0xC0   /*   0   T   GUI   Request UIR state   */
#define   Rep_Info_UIR                 0xC0   /*   1   T   App   Reply UIR state   */
#define   Cmd_Enable_UIR               0xC1   /*   1   T   GUI   Enable/Disable UIR and Mode   */
#define   Cmd_Get_UIR_Data             0xC2   /*   0   T   GUI   Request Data from UIR   */
#define   Cmd_Info_UIR_Data            0xC2   /*   length   T   GUI   Reply Data from UIR   */

/* USB control */
#define   USB_Shape_Line               0x01
#define   USB_Shape_Triangle           0x02
#define   USB_Shape_Square             0x03
#define   USB_Shape_Hexagon            0x04
#define   USB_Shape_Octagon            0x05

#define   USB_Shape_Size4              0x01
#define   USB_Shape_Size8              0x02
#define   USB_Shape_Size32             0x03
#define   USB_Shape_Size64             0x04
#define   USB_Shape_Size128            0x05

#define   USB_Step_Size1               0x01
#define   USB_Step_Size2               0x02
#define   USB_Step_Size4               0x03
#define   USB_Step_Size8               0x04
#define   USB_Step_Size16              0x05
#define   USB_Step_Size32              0x06

#endif /* __TARGET_REF_H__ */
