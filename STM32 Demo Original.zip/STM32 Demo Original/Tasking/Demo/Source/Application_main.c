/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       application_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "eratosthenes.h"

TaskInfo ApplState = {FALSE, FALSE};

u8 Application_Number = 1;
u8 IRQ_Occurrence = 0;
u16 ExecutionTime = 0;
u16 ExecutionSize = 0;

//u32 IRQ_Counter = 0;

extern void Dhrystone (void);
extern void Eratosthenes (void);

/* pointer to test application */
void (*ApplicationRoutine)(void) = Dhrystone;

void Application(void)
{
   u32 StartTime = 0, StopTime = 0;
   u32 TBCounter = 0, TBCounterStart = 0;
   if (ApplState.enabled)
   {
      TIM_DeInit(TIM2);

      TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);

      TIM_OCStructInit(&TIM_OCInitStructure);

      /* Time base configuration */
      /* TIM2CLK = 8 MHz, Prescaler = 0x0, TIM2 counter clock = 32 MHz */
      /* CC1 update rate = TIM2 counter clock / (2* CCR4_Val) ~= 1k Hz (1. ms) */

      TIM_TimeBaseStructure.TIM_Period = 0x400 - (IRQ_Occurrence * 3); //0x100 low
      TIM_TimeBaseStructure.TIM_Prescaler = 0x01;
      TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
      TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
      TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

      /* Output Compare Toggle Mode configuration: Channel1 */
      TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Toggle;
      TIM_OCInitStructure.TIM_Channel = TIM_Channel_1;
      TIM_OCInitStructure.TIM_Pulse = 0x80; //0x7D00;//0x1FFF;
      TIM_OCInit(TIM2, &TIM_OCInitStructure);

      TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Disable);
//   IRQ_Counter = 0;
      TIM_ARRPreloadConfig(TIM2, ENABLE);
      TIM_GenerateEvent(TIM2, TIM_IT_CC1);
      /* Enable TIM2 IT */
      TIM_ITConfig(TIM2, TIM_IT_CC1, ENABLE);
      StartTime = TimeTick;
      TBCounterStart = SysTick_GetCounter();
      /* Enable TIM2 counter */
      TIM_Cmd(TIM2, ENABLE);

      /* run the Application() */
      ApplicationRoutine();

      TBCounter = SysTick_GetCounter();

      /* Disable TIM2 counter */
      TIM_Cmd(TIM2, DISABLE);
      if (TimeTick >= StartTime)
         StopTime = TimeTick - StartTime;
      else
         StopTime = TimeTick + 0xFFFFFFFF-StartTime;
      if (TBCounterStart > TBCounter)
         TBCounter =  TBCounterStart - TBCounter + StopTime * 4000; // 250�s units
      else
         TBCounter =  TBCounterStart + (4000 - TBCounter) + ((StopTime-1) * 4000); // 250�s units

      ExecutionTime = (u16)((u32)(TBCounter/300));//300 (1 = 0.25ms reelle Zeit : /400 (ms))
      ApplState.enabled = FALSE;
   }
}

void TestApplication(void)
{
   ReEntryProcess = Application;
   ReEntry.enabled = TRUE;
   switch (Application_Number) {
    case 1 :  /* disable */
              ApplState.enabled = FALSE;
              ReEntryProcess = Dummy;
              ReEntry.enabled = FALSE;
              break;
    case 2 :  /* run application 1 */
              ApplState.enabled = TRUE;
              ApplicationRoutine = Dhrystone;
              ExecutionSize = 4186;
              break;
    case 3 :  /* run application 2 */              
              ApplState.enabled = TRUE;
              ApplicationRoutine = Eratosthenes;
              ExecutionSize = 4012;
              break;
    case 4 :  /* run application 3 */                
              ApplState.enabled = TRUE;
              ApplicationRoutine = Eratosthenes;
              ExecutionSize = 1620;
              break;
    default : Application_Number = 1;
              ApplState.enabled = FALSE;
              ReEntryProcess = Dummy;
              ReEntry.enabled = FALSE;
              break;
   }
}

void CommAppl(void)
{
   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Start_Appl   : /* application application on/off and number */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           if (CommTask->Data[0] == TaskSwitchOff)
                           {
                              ApplState.enabled = FALSE;
                              ReEntryProcess = Dummy;
                              ReEntry.enabled = FALSE;
                           }
                           else
                           {
                              ApplState.enabled = TRUE;
                              Application_Number = CommTask->Data[0];
                              TestApplication();
                           }
                           break;
    case Cmd_Get_IRQ_Occ   : /* ask for IRQ settings */
                           protocol_SendFrame (Rep_Info_IRQ_Occ, (u8 *)&IRQ_Occurrence,1);
                           break;
    case Cmd_Set_IRQ_Occ   : /* set the IRQ settings */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           IRQ_Occurrence = CommTask->Data[0];
                           ApplState.enabled = TRUE;
                           break;
    case Cmd_Get_ExeTime   : /* get the clock mode */
                           SendTask->Data[1] = (u8)(ExecutionTime>>8);
                           SendTask->Data[0] = (u8)ExecutionTime;
                           SendTask->Data[3] = (u8)(ExecutionSize>>8);
                           SendTask->Data[2] = (u8)ExecutionSize;
                           protocol_SendFrame (Rep_Info_ExeTime, (u8 *)&SendTask->Data,4);
                           ApplState.enabled = TRUE;
                           break;
    default :             /* not implemented */
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}
