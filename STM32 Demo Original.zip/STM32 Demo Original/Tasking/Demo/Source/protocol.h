/********************************************************************
 * Project:    STM32-Stick
 * File:       protocol.h
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/04/9       HS  Initial revision
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include "stm32f10x_lib.h"
#include "TargetReference_13.h"

int protocol_SendError (u8 err);
int protocol_SendFrame (u8 msg, u8 *data, u8 len);
int protocol_DWSendFrame (u8 msg, u32 *data, u8 len);
int protocol_RevSendFrame (u8 msg, u8 *data, u8 len);
int protocol_u16SendFrame (u8 msg, u16 *data, u8 len);
int protocol_StateMachine(void);
void ErrorTransmission(void);
u8 CommInterpreter(void);
/*
** Serial Communication Frame
**
** The communication between target application and GUI has a simple structure containing
** message ID, data length and message data:
**
**   +--------+--------+--------+--------+--------+--------+- - - - -+--------+
**   |  0xFF  |   ID   | Length |  0xFF  |           Data            | Checks.|
**   +--------+--------+--------+--------+--------+--------+- - - - -+--------+
**
** - Message ID, 1 byte
** - Length, 1 word (little endian), number of following data bytes. The minimum length is 0, the maximum length is 255.
** - Data, if Length = 0, this part is missing
** - Checksum, 1 byte adding up all frame bytes including the Checksum must yield a value of Zero. If length = 0 the checksum is
**   discarded.
**
** The communication type is full duplex. In general, both communication parts can handle each message at
** any time.
**
*/
/* process parameters */
/* communication struct */

#endif   /* __PROTOCOL_H__ */
