/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : stm32f10x_it.c
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/08/2007
* Description        : Main Interrupt Service Routines.
*                      This file can be used to describe all the exceptions 
*                      subroutines that may occur within user application.
*                      When an interrupt happens, the software will branch 
*                      automatically to the corresponding routine.
*                      The following routines are all empty, user can write code 
*                      for exceptions handlers and peripherals IRQ interrupts.
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "main.h"
#include "uart.h"
#include "system.h"
#include "usb_lib.h"
#include "systick.h"
#include "measure_main.h"
#include "uir.h"
#include "can.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/  
//extern vu32 TimeTick; /* global counter */
extern void USB_Istr(void);
extern void CAN_isr(void);
extern void Dummy(void);

void (*RemoteRoutine)(void)=Dummy;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : NMIException
* Description    : This function handles NMI exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(2) NMIException(void)
#else
void NMIException(void)
#endif
{
}

/*******************************************************************************
* Function Name  : HardFaultException
* Description    : This function handles Hard Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(3) __noreturn__ HardFaultException(void)
#else
void HardFaultException(void)
#endif
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : MemManageException
* Description    : This function handles Memory Manage exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(4) __noreturn__ MemManageException(void)
#else
void MemManageException(void)
#endif
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : BusFaultException
* Description    : This function handles Bus Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(5) __noreturn__ BusFaultException(void)
#else
void BusFaultException(void)
#endif
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : UsageFaultException
* Description    : This function handles Usage Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(6) __noreturn__ UsageFaultException(void)
#else
void UsageFaultException(void)
#endif
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : DebugMonitor
* Description    : This function handles Debug Monitor exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(12) DebugMonitor(void)
#else
void DebugMonitor(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SVCHandler
* Description    : This function handles SVCall exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(11) SVCHandler(void)
#else
void SVCHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : PendSVC
* Description    : This function handles PendSVC exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(14) PendSVC(void)
#else
void PendSVC(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SysTickHandler
* Description    : This function handles SysTick Handler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(15) SysTickHandler(void)
#else
void SysTickHandler(void)
#endif
{
   systick_isr();
}

/*******************************************************************************
* Function Name  : WWDG_IRQHandler
* Description    : This function handles WWDG interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(16) __noreturn__ WWDG_IRQHandler(void)
#else
void WWDG_IRQHandler(void)
#endif
{
   while(1);
}

/*******************************************************************************
* Function Name  : PVD_IRQHandler
* Description    : This function handles PVD interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(17) PVD_IRQHandler(void)
#else
void PVD_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TAMPER_IRQHandler
* Description    : This function handles Tamper interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(18) TAMPER_IRQHandler(void)
#else
void TAMPER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : RTC_IRQHandler
* Description    : This function handles RTC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(19) RTC_IRQHandler(void)
#else
void RTC_IRQHandler(void)
#endif
{
   if(RTC_GetITStatus(RTC_IT_SEC) != RESET)
   {
      /* Clear the RTC Second interrupt */
      RTC_ClearITPendingBit(RTC_IT_SEC);

      /* Wait until last write operation on RTC registers has finished */
      RTC_WaitForLastTask();    
   }
}

/*******************************************************************************
* Function Name  : FLASH_IRQHandler
* Description    : This function handles Flash interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(20) FLASH_IRQHandler(void)
#else
void FLASH_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : RCC_IRQHandler
* Description    : This function handles RCC interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(21) RCC_IRQHandler(void)
#else
void RCC_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI0_IRQHandler
* Description    : This function handles External interrupt Line 0 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(22) EXTI0_IRQHandler(void)
#else
void EXTI0_IRQHandler(void)
#endif
{
   /*Interruptfunktin for Event Counter*/
   if(CounterState.enabled != FALSE)
   {
      if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13) == 0x01)
      {
        if(Counter_Gate == FALSE)
        {
            event_counter = 0;
            Counter_Gate = TRUE;
        }
      }
      else
      {
        Counter_Gate = FALSE;
      }
    
      if(Counter_Gate == TRUE)
      {
         event_counter++;
         if(event_counter == 0xFFFFFFFF)
            event_counter = 0;
      }
   }   
   /*Interrupt for Freq.*/
   if(ScanState.enabled != FALSE)
   {
      if(tim_set_null == 1)
      {
         TIM_SetCounter(TIM2,0);
         freq_time = 0;
         tim_set_null = 0;
      }
      else
      {
         freq_time = TIM_GetCounter(TIM2);
         if(freq_time == 0)
             freq_time = 0x2710;
         frequency = 0x2710/freq_time;
         tim_set_null = 1;
      }
    
   }

   EXTI_ClearFlag(EXTI_Line0);
}

/*******************************************************************************
* Function Name  : EXTI1_IRQHandler
* Description    : This function handles External interrupt Line 1 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(23) EXTI1_IRQHandler(void)
#else
void EXTI1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI2_IRQHandler
* Description    : This function handles External interrupt Line 2 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(24) EXTI2_IRQHandler(void)
#else
void EXTI2_IRQHandler(void)
#endif
{
   EXTI_ClearITPendingBit(EXTI_Line2);
}

/*******************************************************************************
* Function Name  : EXTI3_IRQHandler
* Description    : This function handles External interrupt Line 3 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(25) EXTI3_IRQHandler(void)
#else
void EXTI3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI4_IRQHandler
* Description    : This function handles External interrupt Line 4 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(26) EXTI4_IRQHandler(void)
#else
void EXTI4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel1_IRQHandler
* Description    : This function handles DMA Stream 1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(27) DMAChannel1_IRQHandler(void)
#else
void DMAChannel1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel2_IRQHandler
* Description    : This function handles DMA Stream 2 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(28) DMAChannel2_IRQHandler(void)
#else
void DMAChannel2_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel3_IRQHandler
* Description    : This function handles DMA Stream 3 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(29) DMAChannel3_IRQHandler(void)
#else
void DMAChannel3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel4_IRQHandler
* Description    : This function handles DMA Stream 4 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(30) DMAChannel4_IRQHandler(void)
#else
void DMAChannel4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel5_IRQHandler
* Description    : This function handles DMA Stream 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(31) DMAChannel5_IRQHandler(void)
#else
void DMAChannel5_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel6_IRQHandler
* Description    : This function handles DMA Stream 6 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(32) DMAChannel6_IRQHandler(void)
#else
void DMAChannel6_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel7_IRQHandler
* Description    : This function handles DMA Stream 7 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(33) DMAChannel7_IRQHandler(void)
#else
void DMAChannel7_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : ADC_IRQHandler
* Description    : This function handles ADC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(34) ADC_IRQHandler(void)
#else
void ADC_IRQHandler(void)
#endif
{
   /* Clear ADC1 JEOC pending interrupt bit */
   ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
}

/*******************************************************************************
* Function Name  : USB_HP_CAN_TX_IRQHandler
* Description    : This function handles USB High Priority or CAN TX interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(35) USB_HP_CAN_TX_IRQHandler(void)
#else
void USB_HP_CAN_TX_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USB_LP_CAN_RX0_IRQHandler
* Description    : This function handles USB Low Priority or CAN RX0 interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(36) USB_LP_CAN_RX0_IRQHandler(void)
#else
void USB_LP_CAN_RX0_IRQHandler(void)
#endif
{
   //RemoteRoutine();
   if(GetISTR() != 0)
       USB_Istr();
    else
       CAN_isr();

}

/*******************************************************************************
* Function Name  : CAN_RX1_IRQHandler
* Description    : This function handles CAN RX1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(37) CAN_RX1_IRQHandler(void)
#else
void CAN_RX1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : CAN_SCE_IRQHandler
* Description    : This function handles CAN SCE interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(38) CAN_SCE_IRQHandler(void)
#else
void CAN_SCE_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI9_5_IRQHandler
* Description    : This function handles External lines 9 to 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(39) EXTI9_5_IRQHandler(void)
#else
void EXTI9_5_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_BRK_IRQHandler
* Description    : This function handles TIM1 Break interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(40) TIM1_BRK_IRQHandler(void)
#else
void TIM1_BRK_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_UP_IRQHandler
* Description    : This function handles TIM1 overflow and update interrupt 
*                  request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(41) TIM1_UP_IRQHandler(void)
#else
void TIM1_UP_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_TRG_COM_IRQHandler
* Description    : This function handles TIM1 Trigger and commutation interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(42) TIM1_TRG_CCUP_IRQHandler(void)
#else
void TIM1_TRG_COM_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : This function handles TIM1 capture compare interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(43) TIM1_CC_IRQHandler(void)
#else
void TIM1_CC_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM2_IRQHandler
* Description    : This function handles TIM2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(44) TIM2_IRQHandler(void)
#else
void TIM2_IRQHandler(void)
#endif
{
   u32 wait_temp;
   u16 wait_rc = 0;
   u16 i,j;
      
   /*RC Record Enabled*/  
   if(UIR_State == RC_enable)
   {
      if (TIM_GetITStatus(TIM2, TIM_IT_CC3) != RESET)
      {
         TIM_SetCompare3(TIM2, 882);
        
        switch (CountMode)
        {
         case 0:
            break;
         case 0x01:
            /*first start bit*/
            if(Counter.ValueA >=20)
            {
               CountMode = 0x02;
               Counter.ValueA = 0x00;
               uart_com_buff.data[uart_com_buff.pos++] = 0x01;
               uart_com_buff.bit++;
            }
            else
            {  /*no valid first start bit*/
              break;
            }
            break;
         
         case 2:
            /*first part of Bit*/
            CountMode = 0x03;
            break;
         case 3:
            /*second part of Bit*/
            if((Counter.ValueA <= 15) & (Counter.ValueB >= 20))
            {
               uart_com_buff.data[uart_com_buff.pos++] = 0x01;
               CountMode = 0x02;
               uart_com_buff.bit++;
            }
            else if((Counter.ValueA >= 20) & (Counter.ValueB <= 15))
            {
               uart_com_buff.data[uart_com_buff.pos++] = 0x00;
               CountMode = 0x02;
               uart_com_buff.bit++;
            }
            else
            {  /*no valid bit*/
              break;
            }
            Counter.ValueA = 0x00;
            Counter.ValueB = 0x00;         
            break;
         default:
            break;
         }
         if(uart_com_buff.bit >=14)
         {
            EXTI_DeInit();
            TIM_Cmd(TIM2, DISABLE);
            
            wait_temp = SysTick_GetCounter();
            wait_rc = 0;
            while(wait_rc != 500) /*wait 500ms because of resend from RC*/
            {
               if((SysTick_GetCounter() - wait_temp) == 0)
                  wait_rc++;
            }
        
            /*Send Data To GUI*/
            SendTask->Data[0] = 0x49;                    /*I */
            for(i=(uart_com_buff.pos-14), j = 1;i < uart_com_buff.pos;i++, j++)
               SendTask->Data[j] = uart_com_buff.data[i];
            SendTask->Data[15] = 0x0D;                   /* <CR> */    
            
            protocol_SendFrame (Cmd_Info_UIR_Data, (u8 *)SendTask->Data, 16);
            rc_gui_send = TRUE;        
        
            CountMode = 0x00;   
            uart_com_buff.bit = 0;      
            EXTI_Init(&EXTI_InitStructure);
         }
      
         if(uart_com_buff.pos >=56)
         {
            uart_com_buff.ready = TRUE;
            TIM_Cmd(TIM2, DISABLE);
            EXTI_DeInit();
         }
        
      }
      TIM_ClearITPendingBit(TIM2, TIM_IT_CC3);
   }
   /*RC Replay Enabled*/
   else if(UIR_State == RC_play_enable)
   {
      if (TIM_GetITStatus(TIM2, TIM_IT_CC3) != RESET)
      {   
         TIM_SetCompare3(TIM2, 97);
      
      
         if((rc_output_pos == 28) | (rc_output_pos == 56) | (rc_output_pos == 84))  
         {
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
            GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
            GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
            GPIO_Init(GPIOA, &GPIO_InitStructure);  
                        
            wait_temp = SysTick_GetCounter();
            wait_rc = 0;
            while(wait_rc != 2000) /*wait 1000ms because of send new RC Message*/
            {
               if((SysTick_GetCounter() - wait_temp) == 0)
                  wait_rc++;
            }
         }
         if((rc_output_pos) >= (2 * uart_com_buff.pos))
         {
    
            rc_output_pos = 0;     
            TIM_Cmd(TIM2, DISABLE);
            TIM1_Cmd( DISABLE);
            TIM1_CtrlPWMOutputs(DISABLE);  
       }
               
       if(rc_output[rc_output_pos++] == 1)
       {
          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
          GPIO_Init(GPIOA, &GPIO_InitStructure);
       }
       else
       {
          GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
          GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
          GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
          GPIO_Init(GPIOA, &GPIO_InitStructure);
       }



         TIM_ClearITPendingBit(TIM2, TIM_IT_CC3);
      }
   
   }
   else
   {
      if (TIM_GetITStatus(TIM2, TIM_IT_CC1) != RESET)
      {
         TIM_SetCompare1(TIM2, 0x80);
         TIM_ClearITPendingBit(TIM2, TIM_IT_CC1);
      }
      if (TIM_GetITStatus(TIM2, TIM_IT_CC2) != RESET)
      {
         if (FFTState.enabled == TRUE)
         {
            TIM_SetCompare2(TIM2, 400);
            fr[FFT_Index++] = ADC_GetConversionValue(ADC1);
            ADC_Cmd(ADC1, ENABLE);
         }
         TIM_ClearITPendingBit(TIM2, TIM_IT_CC2);
      }
   }
}

/*******************************************************************************
* Function Name  : TIM3_IRQHandler
* Description    : This function handles TIM3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(45) TIM3_IRQHandler(void)
#else
void TIM3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM4_IRQHandler
* Description    : This function handles TIM4 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(46) TIM4_IRQHandler(void)
#else
void TIM4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C1_EV_IRQHandler
* Description    : This function handles I2C1 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(47) I2C1_EV_IRQHandler(void)
#else
void I2C1_EV_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C1_ER_IRQHandler
* Description    : This function handles I2C1 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(48) I2C1_ER_IRQHandler(void)
#else
void I2C1_ER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C2_EV_IRQHandler
* Description    : This function handles I2C2 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(49) I2C2_EV_IRQHandler(void)
#else
void I2C2_EV_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C2_ER_IRQHandler
* Description    : This function handles I2C2 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(50) I2C2_ER_IRQHandler(void)
#else
void I2C2_ER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SPI1_IRQHandler
* Description    : This function handles SPI1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(51) SPI1_IRQHandler(void)
#else
void SPI1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SPI2_IRQHandler
* Description    : This function handles SPI2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(52) SPI2_IRQHandler(void)
#else
void SPI2_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USART1_IRQHandler
* Description    : This function handles USART1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(53) USART1_IRQHandler(void)
#else
void USART1_IRQHandler(void)
#endif
{

   UART1_isr();
}

/*******************************************************************************
* Function Name  : USART2_IRQHandler
* Description    : This function handles USART2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(54) USART2_IRQHandler(void)
#else
void USART2_IRQHandler(void)
#endif
{
   UART2_isr();
}

/*******************************************************************************
* Function Name  : USART3_IRQHandler replaced by the UART.c implemented handler
* Description    : This function handles USART3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(55) USART3_IRQHandler(void)
#else
void USART3_IRQHandler(void)
#endif
{
  UART3_isr();
}

/*******************************************************************************
* Function Name  : EXTI15_10_IRQHandler
* Description    : This function handles External lines 15 to 10 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(56) EXTI15_10_IRQHandler(void)
#else
void EXTI15_10_IRQHandler(void)
#endif
{
   switch(CountMode)
   {
      case 0:
         Counter.ValueA = 0x00;
         Counter.ValueB = 0x00;   
         Counter.ValueA++;
         TIM_SetCounter(TIM2,0);
         TIM_Cmd(TIM2, ENABLE);    
         CountMode = 0x01;
         break;
      case 1: /*First Start Byte*/     
         Counter.ValueA++;
         break;
      case 2:
         /*first part of Bit*/
         Counter.ValueA++;
         break;
      case 3:
         /*second part of Bit*/
         Counter.ValueB++;
         break;
      default:
         EXTI_DeInit();
         break;
   }
   
   EXTI_ClearITPendingBit(EXTI_Line10);
   EXTI_ClearFlag(EXTI_Line10);

}

/*******************************************************************************
* Function Name  : RTCAlarm_IRQHandler
* Description    : This function handles RTC Alarm interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(57) RTCAlarm_IRQHandler(void)
#else
void RTCAlarm_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USBWakeUp_IRQHandler
* Description    : This function handles USB WakeUp interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(58) USBWakeUp_IRQHandler(void)
#else
void USBWakeUp_IRQHandler(void)
#endif
{
}

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
