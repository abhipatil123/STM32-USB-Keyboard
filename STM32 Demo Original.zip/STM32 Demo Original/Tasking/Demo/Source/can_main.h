/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       CAN_main.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


/* Define to prevent recursive inclusion ------------------------------------ */
#ifndef __CAN_MAIN_H
#define __CAN_MAIN_H

#include "can_protocol.h"


extern TaskInfo CANState;

#define Default_CAN_Mode

#endif /* __CAN_MAIN_H */
