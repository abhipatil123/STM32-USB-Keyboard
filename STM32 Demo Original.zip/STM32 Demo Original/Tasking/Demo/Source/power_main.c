/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       power_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "power_main.h"
#include "systick.h"
#include "hardware.h"

// Define NULL
#ifndef NULL
#define NULL (void *)0
#endif

#define PwrReg0 6
#define PwrReg1 ((0x0A<<2) + 1)
#define PwrReg2 ((4<<3) + 8 + 2)
#define PwrReg3 (2<<4)

TaskInfo PwrState;
TaskInfo LEDBlinkState = {TRUE, FALSE};
u8 PowerModes[2] = {0x01,0x01};
u8 GatingSet[6] = {0x11,0xFF,0x12,0x84,0x08,0x02};
u8 PLLSet[5] = {0x06,0x7D,0x04,0x0A,0x20};
u8 RegSet[5] = {0x06,0x7D,0x04,0x0A,0x20};
u8 RTCVal[4] = {0x01,0x36,0x69,0xA0};
u8 RTCAlarm[4] ={0,0,0,0};
u8 CPU_Clock_Selected = 0;
u16 LatencyMeasured = 0;


void All_PeriphClock_Disable(void)
{
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_ALL, DISABLE);
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_ALL, DISABLE);
}

void All_PeriphClock_Ensable(void)
{
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_ALL, ENABLE);
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_ALL, ENABLE);
}
void GPIO_Config_ALL_AIN(void)
{
   GPIO_InitTypeDef GPIO_InitStructure;

   /* Enable GPIOD and GPIOE clock */
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB 
                        | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD 
                        | RCC_APB2Periph_GPIOE | RCC_APB2Periph_AFIO, ENABLE);
  
  
   /* Disable the Serial Wire Jtag Debug Port SWJ-DP */
   GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE); 
  
   /* PA  */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
   /* PB  */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   /* PC  */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOC, &GPIO_InitStructure);
   /* PD  */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOD, &GPIO_InitStructure);
}
/*-----------------------------------------------------------------------------------
* Function Name  : GetPeripheralGating
* Description    : Get the current Clock Gating selection
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void GetPeripheralGating(void)
{
   vu32 APB2_Temp = 0, APB1_Temp = 0;
   /* Save the register */
   APB2_Temp = RCC->APB2ENR;
   GatingSet[0] = (u8)(APB2_Temp>>8);
   GatingSet[1] = (u8)APB2_Temp;
   /* Save the register */
   APB1_Temp = RCC->APB1ENR;
   GatingSet[2] = (u8)(APB1_Temp>>24);
   GatingSet[3] = (u8)(APB1_Temp>>16);
   GatingSet[4] = (u8)(APB1_Temp>>8);
   GatingSet[5] = (u8)APB1_Temp;
}
/*-----------------------------------------------------------------------------------
* Function Name  : SetPeripheralGating
* Description    : Set the decided Clock Gating selection
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void SetPeripheralGating(void)
{
   vu32 APB2_Temp = 0, APB1_Temp = 0;
   /* build register word */
   APB2_Temp = (u32)((GatingSet[0]<<8)+GatingSet[1]);
   /* Mask the allowed changes */
   APB2_Temp |= RCC_APB2ENR_Must;
   /* set APB2 Peripheral Clock */
   RCC->APB2ENR = APB2_Temp;
   /* build register word */
   APB1_Temp = (u32)((GatingSet[2]<<24)+(GatingSet[3]<<16)+(GatingSet[4]<<8)+GatingSet[5]);
   /* Mask the allowed changes */
   APB1_Temp |= RCC_APB1ENR_Must;
   /* Disable APB1 Peripheral Clock */
   RCC->APB1ENR = APB1_Temp;
}
/*-----------------------------------------------------------------------------------
* Function Name  : SetPLLSettings
* Description    : adjust the PLL and clock to the GUI commands
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void SetPLLSettings(void)
{
   u32 tmpreg = 0;
   if ((PLLSet[1] != RegSet[1])||(PLLSet[3] != RegSet[3]))
   {
      /* disable UART receive interrupt */
      USART_ITConfig(USART3, (USART_IT_RXNE),DISABLE);
      /* clear pending bits */
      USART_ClearITPendingBit(USART3,USART_IT_RXNE);

      RegSet[0] = PLLSet[0];
      if (PLLSet[1] == 0x79) PLLSet[1] = 0x39; // correct the USB divider
      RegSet[1] = PLLSet[1];
      RegSet[2] = PLLSet[2];
      RegSet[3] = PLLSet[3];
      RegSet[4] = PLLSet[4];

      tmpreg = PLLSet[3] | (u32)PLLSet[2]<<8 | (u32)PLLSet[1]<<16;

      /* Select HSE as system clock source */
      RCC_SYSCLKConfig(RCC_SYSCLKSource_HSE);

      RCC_PLLCmd(DISABLE);

      /* Store the new value */
      RCC->CFGR = tmpreg;

      RCC_PLLCmd(ENABLE);

      while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
      /* Select PLL as system clock source */
      RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

      /* Wait till PLL is used as system clock source */
      while(RCC_GetSYSCLKSource() != 0x08);
      /* reinit RS232 USRART3 */
      USART_Configuration();
      /* clear pending bits */
      USART_ClearITPendingBit(USART3,USART_IT_RXNE);
      /* enable UART receive interrupt */
      USART_ITConfig(USART3, (USART_IT_RXNE), ENABLE);
   }
}
/*-----------------------------------------------------------------------------------
* Function Name  : Enable_Exti
* Description    : Enable the external interrupts
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void Enable_Exti(void)
{
   EXTI_ClearITPendingBit(EXTI_Line2);
   EXTI_InitStructure.EXTI_Line = EXTI_Line2;
//   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Event;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
   EXTI_InitStructure.EXTI_LineCmd = ENABLE;
   EXTI_Init(&EXTI_InitStructure);
}
/*-----------------------------------------------------------------------------------
* Function Name  : Disable_Exti
* Description    : Disable the external interrupts
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void Disable_Exti(void)
{
   EXTI_ClearITPendingBit(EXTI_Line2);
   EXTI_InitStructure.EXTI_Line = EXTI_Line2;
//   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Event;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
   EXTI_InitStructure.EXTI_LineCmd = DISABLE;
   EXTI_Init(&EXTI_InitStructure);
}
/*-----------------------------------------------------------------------------------
* Function Name  : SetPowerMode
* Description    : Change the Power Mode
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void SetPowerMode(void)
{
   switch (PowerModes[1]) {
    case WakeUp_Set_ExtInt :   /* Set the System to wakeup external event */
                              EXTI_InitStructure.EXTI_LineCmd = ENABLE;
                              break;
    case WakeUp_Set_USART :    /* Set the System to wakeup USART event */
                              EXTI_InitStructure.EXTI_LineCmd = ENABLE;
                              break;
    case WakeUp_Set_RTCAlarm : /* Set the System to wakeup with RTC */
                              RTC_WaitForLastTask();
                              RTC_ITConfig(RTC_IT_ALR, ENABLE);
                              PWR_WakeUpPinCmd(ENABLE);
                              break;
    case WakeUp_Set_WakeupPin : /* Set the System to wakeup on WakeupPin */
                              PWR_WakeUpPinCmd(ENABLE);
                              break;
    case WakeUp_Set_Reset :   /* Set the System to wakeup on Reset */
                              EXTI_InitStructure.EXTI_LineCmd = ENABLE;
                              break;
    default :                 PWR_WakeUpPinCmd(ENABLE);
                              break;
   }

   if (PowerModes[0] != Power_Mode_Running) /* low power mode disable LED */
   {
      TimeTick = 0;
      GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_RESET);
   }
   switch (PowerModes[0]) {
    case Power_Mode_Sleep :   /* Set the System in Sleep Mode */
                              //GPIO_Config_ALL_AIN();
                              /* Disable the Jtag Debug Port SWJ-DP */
                              //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE); 
                              Enable_Exti();
                              //Systick_DeConfiguration();
                              SysTick_ITConfig(DISABLE);
                              All_PeriphClock_Disable();
                              __WFI();
                              //Systick_Configuration();
                              SysTick_ITConfig(ENABLE);
                              Disable_Exti();
                              //GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); 
                              //RCC_Configuration();
                              //GPIO_Configuration();
                              HW_ReConfig();
                              break;
    case Power_Mode_Stop :    /* Request to enter STOP mode with regulator in low power mode */
                            //  GPIO_Config_ALL_AIN();
                            //  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);
                              Enable_Exti();
                              /* Desable the SRAM and FLITF clock in Stop mode */ 
                            //  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM|RCC_AHBPeriph_FLITF, DISABLE);
                            //  All_PeriphClock_Disable();
                            //  RCC_SYSCLKConfig(RCC_SYSCLKSource_HSE);
                              PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
                            //  All_PeriphClock_Ensable();
                            //  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_SRAM|RCC_AHBPeriph_FLITF, ENABLE);
                            //  GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, DISABLE); 
                              Disable_Exti();
                              RCC_Configuration();
                            //  GPIO_Configuration();
                              break;
    case Power_Mode_Standby : /* Set the System in Standby Mode */
                              Enable_Exti();
                              PWR_EnterSTANDBYMode();
                              break;
    case Power_Mode_RTC_Alarm : /* Set the System in Standby Mode */
                              Enable_Exti();
                              PWR_EnterSTANDBYMode();
                              break;
    case Power_Mode_Running : Disable_Exti();
                              break;
    default :                 /* not implemented */
                              protocol_SendError (Err_NotImplemented);
                              break;
   }
}
/*-----------------------------------------------------------------------------------
* Function Name  : GetPowerMode
* Description    : Check the Power Mode
* Input          : None
* Output         : None
* Return         : None
-----------------------------------------------------------------------------------*/
void GetPowerMode(void)
{
   PowerModes[0] = Power_Mode_Running;
   PowerModes[1] = WakeUp_Set_ExtInt;
}

/*-----------------------------------------------------------------------------------*/

u32 temp = 0;
void CommPwr (void)
{
   u8 i = 0;
   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_PLL_Settings : /* GUI   Status request of the PLL Settings */
                           protocol_SendFrame (Rep_Info_PLL_Settings, (u8 *)PLLSet,5);
                           break;
    case Cmd_Get_Power_Mode : /* GUI   Status request of the Power Modes */
                           GetPowerMode();
                           protocol_SendFrame (Rep_Info_Power_Mode, (u8 *)PowerModes,2);
                           break;
    case Cmd_Set_Power_Mode     : /*   GUI   Set the Power Modes */
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           PowerModes[0] = CommTask->Data[0];
                           PowerModes[1] = CommTask->Data[1];
                           SetPowerMode();
                           break;
    case Cmd_Get_Periph_Gating  : /* GUI   Status request of the perriph Gating */
                           GetPeripheralGating();
                           protocol_SendFrame (Rep_Info_Periph_Gating, (u8 *)GatingSet,6);
                           break;
    case Cmd_Set_Periph_Gating      : /* GUI   Set the IP address */
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           for (i=0; i<6 ;i++)
                              GatingSet[i] = CommTask->Data[i];
                           SetPeripheralGating();
                           break;
    case Cmd_Set_PLL_Settings :
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           for (i=0; i<5 ;i++)
                              PLLSet[i] = CommTask->Data[i];
                           SetPLLSettings();
                           break;
    case Cmd_Get_CPU_Clock  : /* GUI   Status request of the CPU Clock set */
                           protocol_SendFrame (Rep_Info_CPU_Clock, (u8 *)&CPU_Clock_Selected,1);
                           break;
    case Cmd_Set_CPU_Clock      : /* GUI   Set the CPU Clock Set */
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           CPU_Clock_Selected = CommTask->Data[0];
                           break;
    case Cmd_Get_Backup_Data      : /* GUI   Request for  */
                           SendTask->Data[0] = BKP_ReadBackupRegister(BKP_DR1)>>8;
                           SendTask->Data[1] = BKP_ReadBackupRegister(BKP_DR1);
                           SendTask->Data[2] = BKP_ReadBackupRegister(BKP_DR2)>>8;
                           SendTask->Data[3] = BKP_ReadBackupRegister(BKP_DR2);
                           SendTask->Data[4] = BKP_ReadBackupRegister(BKP_DR3)>>8;
                           SendTask->Data[5] = BKP_ReadBackupRegister(BKP_DR3);
                           SendTask->Data[6] = BKP_ReadBackupRegister(BKP_DR4)>>8;
                           SendTask->Data[7] = BKP_ReadBackupRegister(BKP_DR4);
                           SendTask->Data[8] = BKP_ReadBackupRegister(BKP_DR5)>>8;
                           SendTask->Data[9] = BKP_ReadBackupRegister(BKP_DR5);
                           protocol_SendFrame (Rep_Info_Backup_Data, (u8 *)&SendTask->Data,10);
                           break;
    case Cmd_Set_Backup_Data      : /* GUI   Set the Backup Data */
                           SendTask->ReplyNew = FALSE;
                           BKP_WriteBackupRegister(BKP_DR1, (u16)(CommTask->Data[0]<<8) + CommTask->Data[1]);
                           BKP_WriteBackupRegister(BKP_DR2, (u16)(CommTask->Data[2]<<8) + CommTask->Data[3]);
                           BKP_WriteBackupRegister(BKP_DR3, (u16)(CommTask->Data[4]<<8) + CommTask->Data[5]);
                           BKP_WriteBackupRegister(BKP_DR4, (u16)(CommTask->Data[6]<<8) + CommTask->Data[7]);
                           BKP_WriteBackupRegister(BKP_DR5, (u16)(CommTask->Data[8]<<8) + CommTask->Data[9]);
                           break;
    case Cmd_Get_RTC :     /* GUI Set the IP address */
                           temp = RTC_GetCounter();
                           RTCVal[0]= (u8)temp;
                           RTCVal[1]= (u8)(temp>>8);
                           RTCVal[2]= (u8)(temp>>16);
                           RTCVal[3]= (u8)(temp>>24);
                           protocol_SendFrame (Rep_Info_RTC, (u8 *)&RTCVal,4);
                           break;
    case Cmd_Set_RTC      : /* GUI   Set the IP address */
                           for (i=0; i<4 ;i++)
                              RTCVal[i] = CommTask->Data[i];
                           RTC_WaitForLastTask();
                           RTC_SetCounter((u32)(RTCVal[3]<<24)+(u32)(RTCVal[2]<<16)+(u32)(RTCVal[1]<<8)+(u32)RTCVal[0]);
                           break;
    case Cmd_Get_RTC_Alarm :
                           protocol_SendFrame (Rep_Info_RTC_Alarm, (u8 *)&RTCAlarm,4);
                           break;
    case Cmd_Set_RTC_Alarm      : /* GUI   Set the IP address */
                           for (i=0; i<4 ;i++)
                              RTCAlarm[i] = CommTask->Data[i];
                           RTC_WaitForLastTask();
                           RTC_SetAlarm((u32)(RTCAlarm[3]<<24)+(u32)(RTCAlarm[2]<<16)+(u32)(RTCAlarm[1]<<8)+(u32)RTCAlarm[0]);
                           break;
    case Cmd_Set_Stick_LED : /* GUI Set the LED mode off, on, blink */
                           if (CommTask->Data[0] == LED_Off)
                           {
                              LEDBlinkState.enabled = FALSE;
                              GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_RESET);
                           }
                           else if (CommTask->Data[0] == LED_On)
                           {
                              LEDBlinkState.enabled = FALSE;
                              GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_SET);
                           }
                           else if (CommTask->Data[0] == LED_Blink_On)
                              LEDBlinkState.enabled = TRUE;
                           break;
    default :              /* not implemented */
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}
