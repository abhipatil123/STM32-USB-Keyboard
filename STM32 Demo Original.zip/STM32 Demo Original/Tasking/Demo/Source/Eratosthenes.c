/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       eratosthenes.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#include "stm32f10x_lib.h"
#include "system.h"
#include "eratosthenes.h"

/**
Array with 32 bit values where each bit represents a number. */
unsigned int aPrimes[PRIMES/BITPERELEMENT];
int *PaPrimes = (int *)&aPrimes;
unsigned int* testx;

void SetPrimePTR(void)
{
   /* set pointer in the alias area */
   PaPrimes = (int *)BITBAND_SRAM_BASE+((unsigned)(&aPrimes -(void *)BITBAND_SRAM_REF)<<3);
}

/**
* Reference functions replaced by macro SET_PRIME
void SET_PRIME(unsigned int i)
{
   // set content of the pointer at destination + offset
   *(PaPrimes + i) = 1;
}
*/
/**
* Reference functions replaced by macro CLR_PRIME
void CLR_PRIME(unsigned int i)
{
   // set content of the pointer at destination + offset
   *(PaPrimes + i) = 0;
}
*/
/**
* Reference functions replaced by macro GET_PRIME
unsigned int GET_PRIME(unsigned int i)
{
   return *(PaPrimes + i);
}
*/
/** Set all bits to 1. All numbers are primenumbers at the beginning. */
void InitPrime( void )
{
    unsigned int i;
    SetPrimePTR();
    for(i=0;i< PRIMES; i++)     
    {
        SET_PRIME(i);
    }
    CLR_PRIME(0);
    CLR_PRIME(1);
}

/** Implementing Sieve of Eratosthenes */
void SievePrime ( void )
{
   unsigned int i;
   unsigned int Index;
   /** set the basic pointer in the alias area */
   SetPrimePTR();
   #ifndef STM32
   for (i=2;i<PRIMES-1;i++)
   {
      Index = i;
      if (  GET_PRIME(Index) )
      {
         Index += i;
         while( Index < PRIMES )
         {
             CLR_PRIME(Index);
            Index += i;
         }
      }
   }
#else
   int *PaIndex1;
   int *PaIndex2;
   PaIndex1 = PaPrimes+2;
   for (i=2;i<PRIMES-1;i++)
   {
      PaIndex2 = PaIndex1;
      Index = i;
      if (  *PaIndex1 )
      {
         PaIndex2 += i;
         while( Index < PRIMES )
         {
            *PaIndex2=0;
            Index += i;
         }
      }
      PaIndex1++;
   }
#endif


}

/** loops of running the application in one call */
void Eratosthenes (void)
{
   u8 loops = Loops;

   for (loops = Loops; loops > 0; loops--)
   {
      InitPrime();
      SievePrime();
   }
}
