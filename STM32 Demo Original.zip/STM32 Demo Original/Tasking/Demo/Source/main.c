/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


#include "main.h"
#include "system.h"
#include "systick.h"
#include "hardware.h"
#include "UIR_main.h"
#include "USB_main.h"

#define countof(a)      (sizeof(a) / sizeof(*(a)))

#define RTCClockSource_LSE /** Use the external 32 KHz oscillator as RTC clock source */
/** global library structures */
   GPIO_InitTypeDef           GPIO_InitStructure;
   USART_InitTypeDef          USART_InitStructure;
   ADC_InitTypeDef            ADC_InitStructure;
   EXTI_InitTypeDef           EXTI_InitStructure;
   TIM1_TimeBaseInitTypeDef   TIM1_TimeBaseStructure;
   TIM1_OCInitTypeDef         TIM1_OCInitStructure;
   TIM_OCInitTypeDef          TIM_OCInitStructure;
   TIM_TimeBaseInitTypeDef    TIM_TimeBaseStructure;


/** main time tick */
   volatile vu32 TimeTick;

   u8 GUI_Presence = FALSE;

   unsigned int i = 0, j = 0;

void main (void)
{
#ifdef DEBUG
   /* enable debugging of the library structures */
   debug();
#endif
   /* Configure the system and RTC clocks */
   RCC_Configuration();
   RTC_Configuration();
   /* NVIC configuration */
   NVIC_Configuration();
   /* Systick configuration */
   Systick_Configuration();
   /* GPIO basic configuration */
   GPIO_Configuration();
   /* External interrupt configuration */
   EXTI_Configuration();
   /* ADC configuration */
   ADC_Configuration();
   /* Configure and enable USART3 */
   USART_Configuration();
   /* Watchdog configuration */
   WDG_Configuration();
   /* check the hardware configuration */
   Check_HW_Config();
   
   while(1)
   {

      if (CommInterpreter() != 0)
         CommTask->Process();
      if (ReEntry.enabled)
          ReEntryProcess();

      /* Toggle led1 connected to PB.05 pin */
      if (LEDBlinkState.enabled == TRUE)
      {
         if (TimeTick & 0x000200)
         {
            GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_SET);
            LEDBlinkState.process_ready = TRUE;
         }
         else
         {
            GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_RESET);
            LEDBlinkState.process_ready = FALSE;
         }
      }
   }
}


#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/

void assert_failed(u8* file, u32 line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
