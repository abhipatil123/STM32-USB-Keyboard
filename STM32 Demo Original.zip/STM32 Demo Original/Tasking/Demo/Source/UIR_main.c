/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       UIR_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


#include "system.h"
#include "UIR_main.h"
#include "measure_main.h"

// Define NULL
#ifndef NULL
#define NULL (void *)0
#endif



// Globals
uart_data uart_com_buff;
c_val Counter;

u8 UIR_State = 1;
u8 CountMode = 0;

short *rc_output;
u8 rc_output_pos;

bool rc_gui_send;
/*-----------------------------------------------------------------------------------*/
void UIRStop(void)
{
   USART_ITConfig(USART2, (USART_IT_RXNE), DISABLE);
   /* Diable USART2 */
   USART_Cmd(USART2, DISABLE);
   /* DeConfigure the USART3 IrDA mode */
   //USART_IrDAConfig(USART1, USART_IrDAMode_Normal);
   /* Disable the USART1 IrDA mode */
   USART_IrDACmd(USART1, DISABLE);
   USART_Cmd(USART1, DISABLE);
   
   /* DeConfigure USART2 Rx (PA3) as input floating */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
   /* DeConfigure USART2 Tx (PA2) as alternate function push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, DISABLE);
   /* DeConfigure USART1 Rx (PA10) as input floating */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
   /* DeConfigure USART1 Tx (PA9) as alternate function push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, DISABLE);
   
   TIM_Cmd(TIM2, DISABLE);
   TIM1_Cmd(DISABLE);
   EXTI_DeInit();
   
   UIR_State = UARTIRDAEC_disable;
}


void UIRStart(void)
{
   u16 i,j;

   
   if ((UIR_State == UART_enable) | (UIR_State == UART_IDRDA_enable))
   {
      /* Configure USART2 Rx (PA3) as input floating */
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      
      /* Configure USART2 Tx (PA2) as alternate function push-pull */
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
      
      /* USART2 configured as follow:
         - BaudRate = 9600 baud
         - Word Length = 8 Bits
         - One Stop Bit
         - No parity
         - Hardware flow control disabled (RTS and CTS signals)
         - Receive and transmit enabled
         - USART Clock disabled
         - USART CPOL: Clock is active low
         - USART CPHA: Data is captured on the middle
         - USART LastBit: The clock pulse of the last data bit is not output to the SCLK pin
      */
      USART_InitStructure.USART_BaudRate = 9600;
      USART_InitStructure.USART_WordLength = USART_WordLength_8b;
      USART_InitStructure.USART_StopBits = USART_StopBits_1;
      USART_InitStructure.USART_Parity = USART_Parity_No ;
      USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
      USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
      USART_InitStructure.USART_Clock = USART_Clock_Disable;
      USART_InitStructure.USART_CPOL = USART_CPOL_Low;
      USART_InitStructure.USART_CPHA = USART_CPHA_2Edge;
      USART_InitStructure.USART_LastBit = USART_LastBit_Disable;
      USART_Init(USART2, &USART_InitStructure);
      /* Enable the USART Receive interrupt: this interrupt is generated when the
               USART2 receive data register is not empty */
      USART_ITConfig(USART2, (USART_IT_RXNE), ENABLE);
      /* Enable USART2 */
      USART_Cmd(USART2, ENABLE);
   }
   if((UIR_State == IRDA_enable) | (UIR_State == UART_IDRDA_enable))
   {
      uart_com_buff.pos = 0;
      uart_com_buff.transmit = FALSE;
      uart_com_buff.receive = FALSE;
      uart_com_buff.ready = FALSE;
                  
      /* Configure USART1 Rx (PA10) as input floating */
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
    
      /* Configure USART1 Tx (PA9) as alternate function push-pull */
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
      /* USART1 configured as follow:
            - BaudRate = 9600 baud
            - Word Length = 8 Bits
            - One Stop Bit
            - No parity
            - Hardware flow control disabled (RTS and CTS signals)
            - Receive and transmit enabled
            - USART Clock disabled
            - USART CPOL: Clock is active low
            - USART CPHA: Data is captured on the middle
            - USART LastBit: The clock pulse of the last data bit is not output to the SCLK pin
         */
      USART_InitStructure.USART_BaudRate = 9600;
      USART_InitStructure.USART_WordLength = USART_WordLength_8b;
      USART_InitStructure.USART_StopBits = USART_StopBits_1;
      USART_InitStructure.USART_Parity = USART_Parity_No ;
      USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
      USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
      USART_InitStructure.USART_Clock = USART_Clock_Disable;
      USART_InitStructure.USART_CPOL = USART_CPOL_Low;
      USART_InitStructure.USART_CPHA = USART_CPHA_2Edge;
      USART_InitStructure.USART_LastBit = USART_LastBit_Disable;
      USART_Init(USART1, &USART_InitStructure);
      /* Enable the USART Receive interrupt: this interrupt is generated when the
               USART2 receive data register is not empty */
      USART_ITConfig(USART1, (USART_IT_RXNE), ENABLE);
         /* Configure the USART3 IrDA mode */
      USART_IrDAConfig(USART1, USART_IrDAMode_Normal);
         /* Enable the USART1 IrDA mode */
      USART_IrDACmd(USART1, ENABLE);
         
      USART_SetPrescaler(USART1,0x01);
         /* Enable USART2 */
      USART_Cmd(USART1, ENABLE);
   }
   if(UIR_State == RC_enable)
   {
      /* DeConfigure USART1 Rx (PA10) as input floating */
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
      GPIO_Init(GPIOA, &GPIO_InitStructure);
      
      /*just for test*/
      GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
      GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
      GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
      GPIO_Init(GPIOA, &GPIO_InitStructure);         
      
      /*Config Extern Interrupt*/
      EXTI_DeInit();
      GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource10);
      EXTI_ClearITPendingBit(EXTI_Line10);
      EXTI_InitStructure.EXTI_Line = EXTI_Line10;
      EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
      EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
      EXTI_InitStructure.EXTI_LineCmd = ENABLE;
      
      
      /*Config Timer 2*/
      TIM_DeInit(TIM2);
      TIM_InternalClockConfig(TIM2); /*timer clock 64mhz*/
   
      TIM_TimeBaseStructure.TIM_Period = 882;
      TIM_TimeBaseStructure.TIM_Prescaler = 64;       /*1us*/
      TIM_TimeBaseStructure.TIM_ClockDivision =TIM_CKD_DIV1;    
      TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;   
      TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
      
      
      TIM_SetCompare3(TIM2, 882);
      TIM_ITConfig(TIM2, TIM_IT_CC3, ENABLE);
      
      uart_com_buff.pos = 0;
      uart_com_buff.rc = TRUE;
      uart_com_buff.ready = FALSE;
      u8 CountMode = 0;
      uart_com_buff.bit = 0;
      rc_gui_send = FALSE;
      
      EXTI_Init(&EXTI_InitStructure);
      

   }  
   
   if(UIR_State == RC_play_enable)
   {
      if(uart_com_buff.rc == TRUE)
      {
         if(uart_com_buff.ready == TRUE)
         {
            if(uart_com_buff.pos !=0)
            {
               uart_com_buff.bit = 0;
               
               rc_output = &fr[0];
               
               /*GPIO Settings fop PA9*/
               GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
               GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
               GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//GPIO_Mode_Out_PP;
               GPIO_Init(GPIOA, &GPIO_InitStructure);
             
               
               /*Timer1 PWM Setting*/
               TIM1_DeInit();
               RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
               TIM1_InternalClockConfig();
               
               TIM1_TimeBaseStructure.TIM1_Prescaler = 16;
               TIM1_TimeBaseStructure.TIM1_CounterMode = TIM1_CounterMode_Up;
               TIM1_TimeBaseStructure.TIM1_Period = 103;
               TIM1_TimeBaseStructure.TIM1_ClockDivision = TIM1_CKD_DIV1;               
               TIM1_TimeBaseInit(&TIM1_TimeBaseStructure);

               TIM1_OCInitStructure.TIM1_OCMode = TIM1_OCMode_PWM2;
               TIM1_OCInitStructure.TIM1_OutputState = TIM1_OutputState_Enable;
               TIM1_OCInitStructure.TIM1_OutputNState = TIM1_OutputNState_Enable;
               TIM1_OCInitStructure.TIM1_Pulse = 52;
               TIM1_OCInitStructure.TIM1_OCPolarity = TIM1_OCPolarity_Low;
               TIM1_OCInitStructure.TIM1_OCNPolarity = TIM1_OCNPolarity_Low;
               TIM1_OCInitStructure.TIM1_OCIdleState = TIM1_OCIdleState_Set;
               TIM1_OCInitStructure.TIM1_OCNIdleState = TIM1_OCIdleState_Reset;
               TIM1_OC2Init(&TIM1_OCInitStructure);
               
               rc_output_pos = 0;
               
               /*Generate output Vector*/
               for(j=0,i=0;i<uart_com_buff.pos;i++)
               {
                  if(uart_com_buff.data[i] == 1)
                  {
                     rc_output[j++] = 0;
                     rc_output[j++] = 1;
                  }
                  else
                  {
                     rc_output[j++] = 1;
                     rc_output[j++] = 0;
                  }
               }
               
               TIM_SetCompare3(TIM2, 882);
               TIM_ITConfig(TIM2, TIM_IT_CC3, ENABLE);
               TIM_SetCounter(TIM2,0);
               
               /*Enable Time1 PWM*/
               TIM1_Cmd(ENABLE);  
               TIM1_CtrlPWMOutputs(ENABLE);  
               /*Enbale Time2*/
               TIM_Cmd(TIM2, ENABLE);
            }
         }
      }               
   }
}


/*-----------------------------------------------------------------------------------*/

void CommUIR (void)
{
   u8 i;
   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_UIR : /* GUI   Status request of the Eth enabled */
                           protocol_SendFrame (Rep_Info_UIR, (u8 *)UIR_State, 1);
                           break;
    case Cmd_Enable_UIR  : /* GUI   Start/Stop the Ethernet */
                           SendTask->ReplyNew = FALSE;
                           UIR_State = CommTask->Data[0] ;
                           if (UIR_State >= UART_enable)
                           {
                              UIRStart();
                           }
                           else
                           {
                              UIRStop();
                              if(uart_com_buff.rc == TRUE)
                              {
                                 if(uart_com_buff.pos !=0)
                                 {
                                    uart_com_buff.ready = TRUE;
                                    if(rc_gui_send == FALSE)
                                    {
                                       SendTask->Data[0] = 0x49;                    /*I */
                                       for(i=0;i<uart_com_buff.pos;i++)
                                          SendTask->Data[i+1] = uart_com_buff.data[i];
                                       SendTask->Data[uart_com_buff.pos+1] = 0x0D;                   /* <CR> */
                                       protocol_SendFrame (Cmd_Info_UIR_Data, (u8 *)SendTask->Data, uart_com_buff.pos+2);
                                       rc_gui_send = TRUE;
                                    }
                                 }
                              }
                           }
                           break;
    case Cmd_Get_UIR_Data      : /* GUI   Set the IP address */
                           SendTask->ReplyNew = FALSE;
                           break;
                           
    default :              //CommTask->RxError = TRUE;
                           protocol_SendError (Err_NotImplemented);
                           break;                 
    }
}
