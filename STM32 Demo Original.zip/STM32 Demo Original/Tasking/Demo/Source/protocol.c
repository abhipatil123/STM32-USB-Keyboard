/********************************************************************
 * Project:    STM32-Stick
 * File:       protocol.c
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2006/12/20      Gn  Initial revision
 *    Revision 1.1    2007/04/9       HS  Updated for STM32-Stick
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_lib.h"
#include "uart.h"
#include "system.h"

#define global extern   /* to declare external variables and functions      */

/* Private variables ---------------------------------------------------------*/
static u8 state=0;
static u8 command=0, length=0, checksum=0, temp_length=0;

TaskTypeDef CommTaskRaw, SendTaskRaw;
TaskTypeDef *CommTask = &CommTaskRaw, *SendTask = &SendTaskRaw;
u8 ErrorState = 0x00;
static u8 data[0x100];

/* function pointers to routines */
void (*CommRoutines[14])(void)={
   ErrorTransmission,      /* error handler */
   CommCtrl,               /* CMD_Control */
   CommPwr,                /* Power Control 0x1 */
   Dummy,                  /* CommStanAlone, 0x2 */
   CommAppl,               /* CMD_Application 0x3 */
   CommUSB,                /* CMD_USB 0x4 */
   CommMeasFFT,            /* CMD_ADC 0x5 */ /* CMD_FFT 0x6 */
   CommI2C,                /* CMD_I2C 0x6 */
   CommCAN,                /* CMD_CAN 0x7 */
   Dummy,                  /* CMD_PERF 0x8 */
   CommIO,                 /* CMD_GPIO 0x9 */
   Dummy,                  /* none */
   Dummy,                  /* none */
   CommUIR                 // CommUIR, /* 0xC */
};


/*******************************************************************************
* Function Name  : protocol_SendError
* Description    : Send an error frame to the GUI
* Input          : Error code
* Output         : None
* Return         : TRUE if successful, FALSE if send failed
*******************************************************************************/
int protocol_SendError (u8 err)
{
   return protocol_SendFrame (Rep_Error, &err, 1);
}
struct
   {
      u8 TypeStart;
      u8 Message;
      u8 Length;
      u8 TypeEnd;
      u8 Data[0xff+1];
   } Frame;
/*******************************************************************************
* Function Name  : protocol_SendFrame
* Description    : Send a frame to the GUI
* Input          : Frame information
* Output         : None
* Return         : TRUE if successful, FALSE if send failed
*******************************************************************************/
int protocol_SendFrame (u8 msg, u8 *data, u8 len)
{
   int i;
   char checksum=0;


   if (len >= sizeof(Frame.Data))
   {
     return FALSE;      /* Buffer overflow */
   }

   Frame.TypeStart = Frame.TypeEnd = MSG_FrameType_T;
   Frame.Message = msg;
   Frame.Length = len;

   if (len)
   {
      for (i=0; i<len; i++)
      {
         checksum -= *data;
         Frame.Data[i]=*data++;
      }
      Frame.Data[len++] = checksum;
   }

   len += sizeof(Frame.TypeStart)+sizeof(Frame.Message)+sizeof(Frame.Length)+sizeof(Frame.TypeEnd);

   return UART_SendData((u8 *) &Frame, len);
}
/* send data in 2byte exchanged (reversed) order */

int protocol_RevSendFrame (u8 msg, u8 *data, u8 len)
{
   int i, j;
   char checksum=0;
   /* make shure len is an even number */
   if (len%2)
      len++;


   if (len >= sizeof(Frame.Data))
   {
      return FALSE;      /* Buffer overflow */
   }

   Frame.TypeStart = Frame.TypeEnd = MSG_FrameType_T;
   Frame.Message = msg;
   Frame.Length = len;

   if (len)
   {
      for (i=0; i<len; i++)
      {
         j = (i/2)*2+(i+1)%2;
         Frame.Data[i]=*(data+j);
         checksum -= Frame.Data[i];
      }
      Frame.Data[len++] = checksum;
   }

   len += sizeof(Frame.TypeStart)+sizeof(Frame.Message)+sizeof(Frame.Length)+sizeof(Frame.TypeEnd);

   return UART_SendData((u8 *) &Frame, len);
}

/* input u16 output low byte */
int protocol_u16SendFrame (u8 msg, u16 *data, u8 len)
{
   int i;
   char checksum=0;


   if (len >= sizeof(Frame.Data))
   {
      return FALSE;      /* Buffer overflow */
   }

   Frame.TypeStart = Frame.TypeEnd = MSG_FrameType_T;
   Frame.Message = msg;
   Frame.Length = len;

   if (len)
   {
      for (i=0; i<len; i++)
      {
         Frame.Data[i]=(u8)*data++;
         checksum -= Frame.Data[i];
      }
      Frame.Data[len++] = checksum;
   }

   len += sizeof(Frame.TypeStart)+sizeof(Frame.Message)+sizeof(Frame.Length)+sizeof(Frame.TypeEnd);

   return UART_SendData((u8 *) &Frame, len);
}

int protocol_DWSendFrame (u8 msg, u32 *data, u8 len)
{
   int i;
   char checksum=0;
   u8 xtemp[4];
   u32 *ptemp = (u32 *)&xtemp;

   *ptemp = *data;

   if (len >= sizeof(Frame.Data))
   {
      return FALSE;      /* Buffer overflow */
   }

   Frame.TypeStart = Frame.TypeEnd = MSG_FrameType_T;
   Frame.Message = msg;
   Frame.Length = len;

   if (len)
   {
      for (i=0; i<len; i++)
      {
         checksum -= xtemp[i];
         Frame.Data[i]=xtemp[i];
      }
      Frame.Data[len++] = checksum;
   }

   len += sizeof(Frame.TypeStart)+sizeof(Frame.Message)+sizeof(Frame.Length)+sizeof(Frame.TypeEnd);

   return UART_SendData((u8 *) &Frame, len);
}

/*******************************************************************************
* Function Name  : protocol_StateMachine
* Description    : Process frames received from the GUI
* Input          : None
* Output         : None
* Return         : FALSE received a reset command (MSG_SWReset)
*******************************************************************************/
int protocol_StateMachine(void)
{
//   static u8 command=0, length=0, checksum=0, temp_length=0;
//   static u8 data[0x100];
   u8 ch;

   if (WWDG_GetFlagStatus() == SET)
   {
      state = 0;
      WWDG_ClearFlag();
   }
   if (!UART_ReadData (&ch))
   {
      return FALSE;
   }

   /* check the frame header */
   switch (state) {
         case 0:     if (ch == MSG_FrameType_T)                /* Get the initial byte */
                     {
                        state = 1;
                        checksum = ch;                         /* Initialize checksum */
                     }
                     break;
         case 1:     if (ch)
                     {
                        command = ch;                          /* Save the command */
                        state = 2;
                     }
                     else
                        state = 0;
                     break;
         case 2:     length = ch;                              /* Get the length byte */
                     temp_length = 0;
                     state = 3;
                     break;
         case 3:     if (ch == MSG_FrameType_T)                /* Get frame type */
                     {
                        if (!length)
                           state = 6;                          /* Message finished */
                        else
                        {
                           checksum = 0;                       /* Init checksum */
                           state = 4;                          /* Get data */
                        }
                     }
                     else
                        state = 0;
                     break;
         case 4:     data[temp_length++] = ch;                 /* Data receive state */
                     checksum += ch;                           /* Update checksum */
                     if (temp_length == length)
                        state = 5;
                     break;
         case 5:     checksum += ch;                           /* Update checksum */
                     if (!checksum)                            /* Check the data */
                     {
                        state = 6;
                     }
                     else
                     {
                        protocol_SendError (Err_Checksum);
                        state = 0;
                     }
                     break;
         case 6:     break;
         default:    state = 0;
                     break;
      }

   if (state == 6)
   {
      data_received = TRUE;
      command_received = TRUE;
      if (!length)
         data_received = FALSE;
      rx_error = FALSE;
      state = 0;
      int_ready = TRUE;
      return TRUE;
   }

   return FALSE;
}

void ErrorTransmission(void)
{
   protocol_SendError (Err_Unknown);
}

/* check the data and return the corresponding funktion pointer */
u8 CommInterpreter(void)
{
   u8 ReturnVal=0, i=0;
   if (protocol_StateMachine())
      {
         int_ready = FALSE;
         if (rx_error)
         {
            CommTask->RxError = TRUE;
            ErrorState = Err_Checksum;
         }
         else
         {
            if (command_received)
            {
               CommTask->Command = command;
               CommTask->CommandNew = TRUE;
               CommTask->DataLength = length;
               if ((command>>4) < 0x0d)
                  CommTask->Process = CommRoutines[(command>>4)+1];
               else
                  CommTask->Process = CommRoutines[0];
               ReturnVal = 1;
               command_received = FALSE;
            }
            else
               ReturnVal = 0;
         }
         if (data_received)
         {
            for (i=0;i<(CommTask->DataLength);i++)
               CommTask->Data[i] = data[i];
            ReturnVal = 2;
            data_received = FALSE;
         }
         else
            CommTask->DataLength = 0;
         return ReturnVal;
      }
      else
         ReturnVal = 0;
      if (CommTask->RxError == TRUE)
      {
         CommTask->Process = CommRoutines[0];
         CommTask->ReplyNew = FALSE;
         rx_error = FALSE;
         ReturnVal = 9;
      }
      return ReturnVal;
}
