/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       system.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#include "stm32f10x_lib.h"
#include "TargetReference_13.h"
#include "protocol.h"

// Define NULL
#ifndef NULL
#define NULL (void *)0
#endif

/* UASART control mecahnism */
//#define UARTControl
/* START control mecahnism */
//#define Control 1


extern u32 TxHead;
extern u32 TxTail;

extern u32 RxHead;
extern u32 RxTail;

extern u8 Setup_Data[4];
extern short fr[], fi[], loud[];
extern u16 FFT_Index;

/* function protoypes for command interpreter */
extern void Dummy (void);
extern void CommCtrl (void);
extern void CommPwr(void);
extern void CommAppl(void);
extern void CommMeasFFT(void);
extern void CommI2C(void);
extern void CommIO(void);
extern void CommUIR(void);
extern void CommUSB(void);
extern void CommCAN(void);
extern void echo (void);
/* function prototypes of communication */
extern u8 CommInterpreter(void);
extern void ErrorTransmission(void);
extern vu32 TimeTick;

/* TestApplication */
extern void Application(void);
extern void FFT (void);
/* pointer to Reentrant routines */
extern void (*ReEntryProcess)(void);

typedef struct
{
   bool CommandNew;           /* this is a command not serviced */
   bool ReplyNew;             /* this is a reply not serviced */
   bool RxError;              /* Flag for error in transmission */
   u8 Command;                /* command or reply number */
   u8 DataLength;             /* length of the data */
   u8 Data[0xff];             /* data for the command */
   void (*Process)(void);     /* pointer to the function */
   } TaskTypeDef;
/* process state struct */
typedef struct
{
   bool enabled;              /* enabled = 1 or disabeld task */
   bool process_ready;        /* flags the process holds new data */
   } TaskInfo;


   /* communication types */
extern TaskTypeDef *CommTask, *SendTask;
/* global task states */
extern TaskInfo ApplState;
extern TaskInfo LEDBlinkState;
extern TaskInfo FFTState;
extern TaskInfo USB_ENUM;
extern TaskInfo ReEntry;
extern TaskInfo VU1State;
extern TaskInfo AmbState;
extern TaskInfo ScanState;
extern TaskInfo CounterState;
extern TaskInfo OversamplingState;
extern TaskInfo FFTState;
extern TaskInfo PwrState;

extern u16 FFT_Index;
extern u8 GUI_Presence;

extern u8 ErrorState;
/* global timer counter */
extern vu32 TimeTick;
/* global library types */
extern GPIO_InitTypeDef          GPIO_InitStructure;
extern USART_InitTypeDef         USART_InitStructure;
extern ADC_InitTypeDef           ADC_InitStructure;
extern TIM_OCInitTypeDef         TIM_OCInitStructure;
extern TIM_TimeBaseInitTypeDef   TIM_TimeBaseStructure;
extern TIM1_TimeBaseInitTypeDef  TIM1_TimeBaseStructure;
extern TIM1_OCInitTypeDef        TIM1_OCInitStructure;
extern EXTI_InitTypeDef          EXTI_InitStructure;
/* globals */

#include "power_main.h"

#endif   /* __SYSTEM_H__ */
