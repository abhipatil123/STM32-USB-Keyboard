/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       I2C_protocol.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#ifndef _I2C_PROTOCOL_H_
#define _I2C_PROTOCOL_H_

#define I2C_ID_STATUS                           0
#define I2C_ID_CANSPY                           1
#define I2C_ID_I2CGENERATOR                     2

#define I2C_STATUS_FEATURE_SPY                  0x0001
#define CI2_STATUS_FEATURE_GENERATOR            0x0002
#define I2C_STATUS_APPLICATION                  "I2C-Monitor"
#define I2C_STATUS_CONTROLLER                   "STM32"

#define I2C_I2CSPY_FEATURE_RECORD               0x01
#define I2C_I2CSPY_FEATURE_LOOPBACK             0x02

#define I2C_I2CSPY_INFOMASK_ID                  0x1FFFFFFF
#define I2C_I2CSPY_INFOMASK_EXTENDED            0x20000000
#define I2C_I2CSPY_INFOMASK_REMOTEREQUEST       0x40000000
#define I2C_I2CSPY_INFOMASK_ERROR               0x80000000

#define I2C_I2CGENERATE_INFOMASK_ID             0x1FFFFFFF
#define I2C_I2CGENERATE_INFOMASK_EXTENDED       0x20000000
#define I2C_I2CGENERATE_INFOMASK_REMOTEREQUEST  0x40000000
#define I2C_I2CGENERATE_INFOMASK_SPARE          0x80000000

#define I2C_I2CSPY_ERROR_STUFF                  0x01
#define I2C_I2CSPY_ERROR_FORM                   0x02
#define I2C_I2CSPY_ERROR_ACK                    0x03
#define I2C_I2CSPY_ERROR_BIT1                   0x04
#define I2C_I2CSPY_ERROR_BIT0                   0x05
#define I2C_I2CSPY_ERROR_CRC                    0x06
#define I2C_I2CSPY_ERROR_DROPPEDFRAME           0x11
#define I2C_I2CSPY_ERROR_SPYBUFOVERRUN          0x12


#endif  // ifndef _I2C_PROTOCOL_H_
