/********************************************************************
 * Project:    STM32-Stick
 * File:       uart.c
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2006/12/20      Gn  Initial revision
 *    Revision 1.1    2007/04/9       HS  Updated for STM32-Stick
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#define global extern   /* to declare external variables and functions      */
#include "stm32f10x_lib.h"
#include "main.h"
#include "uart.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
#define countof(a)   (sizeof(a) / sizeof(*(a)))

#define TxBufferSize   0x200
#define RxBufferSize   0x200

/* Private variables ---------------------------------------------------------*/

static u8 TxBuffer[TxBufferSize];
u32 TxHead = 0;
u32 TxTail = 0;

static u8 RxBuffer[RxBufferSize];
u32 RxHead = 0;
u32 RxTail = 0;

/* Private function prototypes -----------------------------------------------*/
static void CircIdxInc (volatile u32 *p, u32 sz);
static u32 RxFree(void);
static u32 TxFree(void);
static void RxPut(u8 ch);
static void TxPut(u8 ch);
static u8 RxGet(void);
static u8 TxGet(void);

bool data_received = FALSE,
     command_received = FALSE,
     rx_error = FALSE,
     command_reply = FALSE,
     int_ready = FALSE;

/* Private functions ---------------------------------------------------------*/

static void CircIdxInc (volatile u32 *p, u32 sz)
{
   u32 idx = *p;

   if (++idx >= sz)
   {
      idx -= sz;
   }

   *p = idx;
}

static u32 RxFree(void)
{
   u32 RxFree = countof(RxBuffer) + RxTail - RxHead;

   if (RxFree > countof(RxBuffer))
   {
      RxFree -= countof(RxBuffer);
   }

   return RxFree;
 }

static u32 TxFree(void)
{
   u32 TxFree = countof(TxBuffer) + TxTail - TxHead;

   if (TxFree > countof(TxBuffer))
   {
      TxFree -= countof(TxBuffer);
   }

   return TxFree;
 }

static void RxPut(u8 ch)
{
   RxBuffer[RxHead] = ch;
   CircIdxInc (&RxHead, countof(RxBuffer));
}

static void TxPut(u8 ch)
{
   TxBuffer[TxHead] = ch;
   CircIdxInc (&TxHead, countof(TxBuffer));
}

static u8 RxGet(void)
{
   u8 ch = RxBuffer[RxTail];

   CircIdxInc (&RxTail, countof(RxBuffer));

   return ch;
}

static u8 TxGet(void)
{
   u8 ch = TxBuffer[TxTail];

   CircIdxInc (&TxTail, countof(TxBuffer));

   return ch;
}

/* Global functions ----------------------------------------------------------*/

/*******************************************************************************
* Function Name  : UART3_isr
* Description    : Interrupt service routine for the UART
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART3_isr(void)
{
   /* Implemented full duplex serial communication */

   if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)
   {
      if (RxFree())
      {
         /* Read one byte from the receive data register */
         RxPut(USART_ReceiveData(USART3));
      }

      /* Clear the USART3 Receive interrupt */
      USART_ClearITPendingBit(USART3, USART_IT_RXNE);
   }

   if(USART_GetITStatus(USART3, USART_IT_TXE) != RESET)
   {
      if(TxTail != TxHead)
      {
         /* Write one byte to the transmit data register */
         USART_SendData(USART3, TxGet());
      }

      if (TxTail == TxHead)
      {
         USART_ITConfig(USART3, USART_IT_TXE, DISABLE);
      }

      /* Clear the USART3 transmit interrupt */
      USART_ClearITPendingBit(USART3, USART_IT_TXE);
   }
}

/*******************************************************************************
* Function Name  : UART_Stop
* Description    : Configurate the UART
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART_Stop(void)
{
   USART_DeInit(USART3);
   USART_Cmd(USART3, DISABLE);

   TxHead = TxTail = RxHead = RxTail = 0;
}

/*******************************************************************************
* Function Name  : UART_ReadData
* Description    : Read a byte from the UART
* Input          : Pointer to a character buffer
* Output         : Data byte
* Return         : TRUE if successful, FALSE if no data available
*******************************************************************************/
int UART_ReadData (u8 *ch)
{
   if(RxTail != RxHead)
   {
      *ch = RxGet();
      return TRUE;
   }
   return FALSE;
}

/*******************************************************************************
* Function Name  : UART_SendData
* Description    : Send a string to the UART
* Input          : Pointer to the data string to send
* Output         : None
* Return         : TRUE if successful, FALSE if failed
*******************************************************************************/
int UART_SendData (u8 *str, u32 len)
{
   if (TxFree() <= len) return FALSE;

   USART_ITConfig(USART3, USART_IT_TXE, DISABLE);

   while (len--) TxPut(*str++);

   USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
   return TRUE;
}

