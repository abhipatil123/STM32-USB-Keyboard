/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       io_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gx
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#include "stm32f10x_lib.h"
#include "system.h"

u32 tempreg = 0;

u8  IO_config_A[8],
    IO_config_B[8],
    IO_config_C[8],
    IO_config_D[8],
    ACTIV_IO_config_A[8] = {0,0,0,0,0,0,0,0},           /* containing configuration data */
    ACTIV_IO_config_B[8] = {0,0,0,0,0,0,0,0},           /* containing configuration data */
    ACTIV_IO_config_C[8] = {0,0,0,0,0,0,0,0},           /* containing configuration data */
    ACTIV_IO_config_D[8] = {0,0,0,0,0,0,0,0},           /* containing configuration data */
    Port_In[7],
    Port_Out[7],
    ACTIVE_ExtInt_Cfg[4] = {0,0,0,0},
    ACTIVE_Alternate[6] = {0,0,0,0};

u8 adc_init_done = 0x00;
u16 LastADValue;

u8 temp_tst[4];


void IO_Configuration_B(void)
{
   /**IO Configuration for PortB*/
   u8 i;
   
   /* reseting Pins */
   GPIOB->CRL &= ~0xFFF00FFF; 
   GPIOB->CRH &= ~0xFFFF0000;
  
  
   tempreg = IO_config_B[0] | (u32)(IO_config_B[1]<<8) | (u32)(IO_config_B[2]<<16) | (u32)(IO_config_B[3]<<24);
   tempreg &= 0xFFF00FFF; 
   GPIOB->CRL |= tempreg;
   
   tempreg &= 0xFFFF0000;
   tempreg = IO_config_B[4] | (u32)(IO_config_B[5]<<8) | (u32)(IO_config_B[6]<<16) | (u32)(IO_config_B[7]<<24);
   
   GPIOB->CRH |= tempreg;
   
   for(i = 0;i < 8;i++)
   {
      if((IO_config_B[i] & 0x03) == 0x00)
      {
         if((IO_config_B[i] & 0x0C) == 0x08)
         {
                           
            GPIOB->ODR  = (GPIOB->ODR & ~(0x01 << i*2))  | (0x01 << i*2);   
         }  
         else
         {
            GPIOB->ODR  = (GPIOB->ODR & ~(0x01 << i*2));
         }
      }
      if((IO_config_B[i] & 0x30) == 0x00)
      {
         if((IO_config_B[i] & 0xC0) == 0x80)
         {
             GPIOB->ODR  = (GPIOB->ODR & ~(0x02 << i*2))  | (0x02 << i*2);   
         }
         else
         {
            GPIOB->ODR  = (GPIOB->ODR & ~(0x02 << i*2));
         }
      }          
   }   
   
}


void Get_IO_Configuration_B(void)
{
   u8 i;
   
   /**Get IO Configuration for PortB*/
   ACTIV_IO_config_B[0] = (u8)GPIOB->CRL;
   ACTIV_IO_config_B[1] = (GPIOB->CRL >> 8) & 0x0F;
   ACTIV_IO_config_B[2] = (GPIOB->CRL >> 16) & 0xF0;
   ACTIV_IO_config_B[3] = (u8)(GPIOB->CRL >> 24);
   ACTIV_IO_config_B[4] = GPIOB->CRH & 0x00;
   ACTIV_IO_config_B[5] = (GPIOB->CRH >> 8) & 0x00; 
   ACTIV_IO_config_B[6] = (u8)(GPIOB->CRH >> 16);
   ACTIV_IO_config_B[7] = (u8)(GPIOB->CRH >> 24);

   
   for(i = 0;i < 8;i++)
   {
      if((ACTIV_IO_config_B[i] & 0x03) > 0x01)
      {
         ACTIV_IO_config_B[i] &= 0xFD;    /*only for GUI*/
      }
      else
      {
         if((ACTIV_IO_config_B[i] & 0x0C) == 0x08)
         {
            if((GPIOB->ODR & (0x01 << i*2)) == 0x00)
            {
               ACTIV_IO_config_B[i] |= 0x0C;
            }
         }   
      }
      if((ACTIV_IO_config_B[i] & 0x30) > 0x10)
      {
         ACTIV_IO_config_B[i] &= 0xDF;    /*only for GUI*/
      }
      else
      {
         if((ACTIV_IO_config_B[i] & 0xC0) == 0x80)
         {
            if((GPIOB->ODR & (0x02 << i*2)) == 0x00)
            {
               ACTIV_IO_config_B[i] |= 0xC0;
            }
         }
      }          
   }
}


void IO_Configuration_C(void)
{
   /*IO Configuration for PortC*/
   u8 i;
   
   for (i = 0; i < 8; i++)
   {
      ACTIV_IO_config_C[i] = IO_config_C[i];
   }
  
   /* reseting Pins */
   GPIOC->CRL &= ~0xFFF0FFFF; 
   GPIOC->CRH &= ~0x00FFFFFF;  
  

   tempreg = IO_config_C[0]|(u32)(IO_config_C[1]<<8)|(u32)(IO_config_C[2]<<16)|(u32)(IO_config_C[3]<<24);
   tempreg &= 0xFFF0FFFF;
   GPIOC->CRL |= tempreg;
   
   tempreg = IO_config_C[4]|(u32)(IO_config_C[5]<<8)|(u32)(IO_config_C[6]<<16)|(u32)(IO_config_C[7]<<24);
   tempreg &= 0x00FFFFFF;
   GPIOC->CRH |= tempreg;
   
   for(i = 0;i < 8;i++)
   {
      if((IO_config_C[i] & 0x03) == 0x00)
      {
         if((IO_config_C[i] & 0x0C) == 0x08)
         {             
            GPIOC->ODR  = (GPIOC->ODR & ~(0x01 << i*2))  | (0x01 << i*2);   
         } 
         else
         {
            GPIOC->ODR  = (GPIOC->ODR & ~(0x01 << i*2));
         }
      }
      if((IO_config_C[i] & 0x30) == 0x00)
      {
         if((IO_config_C[i] & 0xC0) == 0x80)
         {
             GPIOC->ODR  = (GPIOC->ODR & ~(0x02 << i*2))  | (0x02 << i*2);   
         }
         else
         {
            GPIOC->ODR  = (GPIOC->ODR & ~(0x02 << i*2));
         }
      }          
   }     
}


void Get_IO_Configuration_C(void)
{
   u8 i;
   
   /**Get IO Configuration for PortB*/
   ACTIV_IO_config_C[0] = (u8)GPIOC->CRL;
   ACTIV_IO_config_C[1] = (u8)(GPIOC->CRL >> 8);
   ACTIV_IO_config_C[2] = (GPIOC->CRL >> 16) & 0xF0;
   ACTIV_IO_config_C[3] = (u8)(GPIOC->CRL >> 24);
   ACTIV_IO_config_C[4] = (u8)GPIOC->CRH;
   ACTIV_IO_config_C[5] = (u8)(GPIOC->CRH >> 8); 
   ACTIV_IO_config_C[6] = (u8)(GPIOC->CRH >> 16);
   ACTIV_IO_config_C[7] = (GPIOC->CRH >> 24) & 0x00;

   
   for(i = 0;i < 8;i++)
   {
      if((ACTIV_IO_config_C[i] & 0x03) > 0x01)  
      {
         ACTIV_IO_config_C[i] &= 0xFD;    /*only for GUI*/
      }
      else
      {
         if((ACTIV_IO_config_B[i] & 0x0C) == 0x08)
         {
            if((GPIOC->ODR & (0x01 << i*2)) == 0x00)
            {
               ACTIV_IO_config_B[i] |= 0x0C;
            }
         }     
      }
      if((ACTIV_IO_config_C[i] & 0x30) > 0x10)
      {      
         ACTIV_IO_config_C[i] &= 0xDF;    /*only for GUI*/
      }
      else
      {
         if((ACTIV_IO_config_B[i] & 0xC0) == 0x80)
         {
            if((GPIOC->ODR & (0x02 << i*2)) == 0x00)
            {
               ACTIV_IO_config_B[i] |= 0xC0;
            }
         }     
      }
   
   }
}


   
void CheckPorts(void)
{
   u8 i;

   
   for(i=0;i<6;i++)
      Port_In[i]=0;
      
    
   for(i=0; i < 8; i++)
   {
      if((GPIOA->CRL & ((u32)0x3 << i*4)) != 0x00)
         Port_In[0] |= (u8)GPIOA->ODR & ((u8)0x01 << i); 
      else
         Port_In[0] |= (u8)GPIOA->IDR & ((u8)0x01 << i);

      if((GPIOA->CRH & ((u32)0x3<<i*4)) != 0x00)
         Port_In[1] |= ((u8)(GPIOA->ODR>>8)) & ((u8)0x01 << i);
      else
         Port_In[1] |= ((u8)(GPIOA->IDR>>8)) & ((u8)0x01 << i);
   }   

   
   for(i=0; i < 8; i++)
   {
      if((GPIOB->CRL & ((u32)0x3<<i*4)) != 0x00)
         Port_In[2] |= (u8)GPIOB->ODR & (0x01 << i); 
      else
         Port_In[2] |= (u8)GPIOB->IDR & (0x01 << i);
    
      if((GPIOB->CRH & ((u32)0x3<<i*4)) != 0x00)
         Port_In[3] |= ((u8)(GPIOB->ODR>>8)) & (0x01 << i);
      else
         Port_In[3] |= ((u8)(GPIOB->IDR>>8)) & (0x01 << i);
   }
  
  
   for(i=0; i < 8; i++)
   {
      if((GPIOC->CRL & ((u32)0x3<<i*4)) != 0x00)
         Port_In[4] |= (u8)GPIOC->ODR & (0x01 << i); 
      else
         Port_In[4] |= (u8)GPIOC->IDR & (0x01 << i);
   
      if((GPIOC->CRH & ((u32)0x3<<i*4)) != 0x00)
         Port_In[5] |= ((u8)(GPIOC->ODR>>8)) & (0x01 << i);
      else
         Port_In[5] |= ((u8)(GPIOC->IDR>>8)) & (0x01 << i);
   }  


   
}
u32 temp_odr;
void SetPorts(void)
{
   u8 i;
   temp_odr = GPIOB->ODR;
   
   for(i=0; i < 8; i++)
   {
      if((GPIOB->CRL & ((u32)0x3<<i*4)) != 0x00)
      {
         temp_odr &= ~((u8)0x01 << i);
         temp_odr |= Port_Out[2] & ((u8)0x01 << i);
      }
      if((GPIOB->CRH & ((u32)0x3<<i*4)) != 0x00)
      {
         temp_odr &= ~((u16)0x01 << (i+8));
         temp_odr |= (Port_Out[3] & ((u8)0x01 << (i))) << 8;
      }
   }
   GPIOB->ODR = (u32)temp_odr;  
   
   temp_odr = GPIOC->ODR;
   for(i=0; i < 8; i++)
   {
      if((GPIOC->CRL & ((u32)0x3<<i*4)) != 0x00)
      {
         temp_odr &= ~((u8)0x01 << i);
         temp_odr |= Port_Out[4] & ((u8)0x01 << i);
      }
      if((GPIOC->CRH & ((u32)0x3<<i*4)) != 0x00)
      {
         temp_odr &= ~((u16)0x01 << (i+8));
         temp_odr |= (Port_Out[5] & ((u8)0x01 << (i))) << 8;
      }
   } 
   GPIOC->ODR = (u32)temp_odr;  

}



void ADC_init(void)
{
   /**Init ADC1*/
   ADC_DeInit(ADC1);
   ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
   ADC_InitStructure.ADC_ScanConvMode = ENABLE;
   ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
   ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
   ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
   ADC_InitStructure.ADC_NbrOfChannel = 1;
   ADC_Init(ADC1, &ADC_InitStructure);
   
   adc_init_done = 0x01;
}


u16 GetADC(u8 channel)
{
   /*Get ADC Value from channel*/
   u16 value;
   
   switch (channel)
   {
      case 8:
         if((GPIOB->CRL & 0xF) != 0x00)
            return 0;
         break;
      case 9:
         if((GPIOB->CRL & 0xF0) != 0x00)
            return 0;
         break;
      case 10:
         if((GPIOC->CRL & 0xF) != 0x00)
            return 0;      
         break;
      case 11:
         if((GPIOC->CRL & 0xF0) != 0x00)
            return 0;   
         break;   
      case 12:
         if((GPIOC->CRL & 0xF00) != 0x00)
            return 0;         
         break;
      case 13:
         if((GPIOC->CRL & 0xF000) != 0x00)
            return 0;           
         break;
      case 15:
         if((GPIOC->CRL & 0xF00000) != 0x00)
            return 0;        
         break;
      default:
         return 0;
   }
   
   ADC_RegularChannelConfig(ADC1, channel,  1, ADC_SampleTime_55Cycles5);
                          
   ADC_Cmd(ADC1, ENABLE);
   ADC_SoftwareStartConvCmd(ADC1, ENABLE);
   
   while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
   value =  ADC_GetConversionValue(ADC1);
   
   ADC_ClearFlag(ADC1,ADC_FLAG_EOC);
   ADC_Cmd(ADC1, DISABLE);
   
   return value;
}

void CommIO (void)
{
   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_IO_FktA :  break;
    case Cmd_Set_IO_FktA :  break;
    
    case Cmd_Get_IO_FktB : /* GUI   Status request of the IO settings */

                           Get_IO_Configuration_B();
                           protocol_SendFrame (Rep_Info_IO_FktB, (u8 *)ACTIV_IO_config_B,8);

                           break;
    case Cmd_Set_IO_FktB :     /* 3 GUI Settings for the IOs (In/out,ADC,PWM) */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;  /* none */
                           CommTask->DataLength = 0;
                           IO_config_B[0] = CommTask->Data[0];
                           IO_config_B[1] = CommTask->Data[1];
                           IO_config_B[2] = CommTask->Data[2];
                           IO_config_B[3] = CommTask->Data[3];
                           IO_config_B[4] = CommTask->Data[4];
                           IO_config_B[5] = CommTask->Data[5];
                           IO_config_B[6] = CommTask->Data[6];
                           IO_config_B[7] = CommTask->Data[7];
                           IO_Configuration_B();/* Call IO-function */
                           break;
    case Cmd_Get_IO_FktC : /* GUI   Status request of the IO settings */
                           Get_IO_Configuration_C();
                           protocol_SendFrame (Rep_Info_IO_FktC, (u8 *)ACTIV_IO_config_C,8);

                           break;
    case Cmd_Set_IO_FktC :     /* 3 GUI Settings for the IOs (In/out,ADC,PWM) */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;  /* none */
                           CommTask->DataLength = 0;
                           IO_config_C[0] = CommTask->Data[0];
                           IO_config_C[1] = CommTask->Data[1];
                           IO_config_C[2] = CommTask->Data[2];
                           IO_config_C[3] = CommTask->Data[3];
                           IO_config_C[4] = CommTask->Data[4];
                           IO_config_C[5] = CommTask->Data[5];
                           IO_config_C[6] = CommTask->Data[6];
                           IO_config_C[7] = CommTask->Data[7];
                           IO_Configuration_C();/* Call IO-function */
                           break;
    case Cmd_Get_ADC :     /* 0   GUI   Get ADC */
                           if(adc_init_done == 0)
                           {
                              ADC_init();
                           }
                           LastADValue = GetADC(CommTask->Data[0]);
                           SendTask->Data[0] = CommTask->Data[0];//(u8)(LastADValue>>8);
                           SendTask->Data[1] = (u8)LastADValue;
                           SendTask->Data[2] = (u8)(LastADValue>>8);
                           protocol_SendFrame (Rep_Info_ADC, (u8 *)SendTask->Data,3);
                           break;
                           
    case Cmd_Get_EXTInt :  break;
    case Cmd_Set_EXTInt :  break;
    
    case Cmd_Get_PORT :    /* 0   GUI   Request Input ports */
                           CheckPorts();
                           protocol_SendFrame (Rep_Info_PORT, (u8 *)Port_In,6);
                           break;
    case Cmd_Set_PORT :    /* 1   GUI   Set Output ports */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;  /* none */
                           CommTask->DataLength = 0;
                           Port_Out[0] = CommTask->Data[0];
                           Port_Out[1] = CommTask->Data[1];
                           Port_Out[2] = CommTask->Data[2];
                           Port_Out[3] = CommTask->Data[3];
                           Port_Out[4] = CommTask->Data[4];
                           Port_Out[5] = CommTask->Data[5];
                           SetPorts();
                           break;
                           
    case Cmd_Get_Alternate :  break;
    case Cmd_Set_Alternate :  break;
    
    default :
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}
