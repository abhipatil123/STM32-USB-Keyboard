/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       ComCtrl.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#define global extern   /* to declare external variables and functions      */
#include "system.h"


/* Private variables ---------------------------------------------------------*/
//   UART_InitTypeDef UART_InitStructure;
//   WDG_InitTypeDef WDG_InitStructure;
   ErrorStatus OSC4MStartUpStatus;
   void WDG_CONFIGURATION(void);

   /* Reentrant Process control */
   TaskInfo ReEntry = {FALSE, FALSE};
   void (*ReEntryProcess)(void) = Dummy;

   u8 Setup_Data[4] = {HardwareVersion,0,0,0};

   TaskInfo TransparentUARTState = {TRUE, FALSE};

   u8 state=0, command=0, length=0, checksum=0, temp_length=0;


/* Dummy function should not be called */
void Dummy (void)
{
}
u16 temp_ctl;
void CommCtrl (void)
{

   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_SWReset   : /* forces reset on the device */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           NVIC_GenerateSystemReset();
                           break;
    case Cmd_Get_Setup   : /* replys the hw-Identification */
                           protocol_SendFrame (Rep_Info_Setup, (u8 *)Setup_Data, 3);
                           break;
    case Cmd_GUI_present   : /* states the GUI is present */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           CommTask->DataLength = 0;
                           GUI_Presence = TRUE;
                           break;
    case Cmd_Get_Firmware_Version   : /* replys the firmware-Identification */
                           temp_ctl = FW_Version;
                           protocol_DWSendFrame (Rep_Info_Firmware_Version, (u32 *)&temp_ctl, 2);
                           break;
    default :              /* no valid command */
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}

void WDG_CONFIGURATIONx(void)
{
   /* Configure the WDG to generate a system reset each 4.2s */
   /* Enable WWDG and set counter value to 0x7F, WWDG timeout = 4 ms * 64 = 262 ms */
   // WWDG_Enable(0x7F);
   //  WWDG_EnableIT();
   IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
   /* IWDG counter clock: 32KHz(LSI) / 32 = 1KHz */
   IWDG_SetPrescaler(IWDG_Prescaler_8);
   /* Set counter reload value to 349 */
   IWDG_SetReload(349);
   /* Reload IWDG counter */
   IWDG_ReloadCounter();
   /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
   IWDG_Enable();
}
