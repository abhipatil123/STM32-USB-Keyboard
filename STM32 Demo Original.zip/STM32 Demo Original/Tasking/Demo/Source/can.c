/********************************************************************
 * Project:    STM32-Stick
 * File:       can.c
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2006/12/20      Gn  Initial revision
 *    Revision 1.1    2007/04/9       HS  Updated for STM32-Stick
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "can.h"
#include "time48.h"


/* Private typedef -----------------------------------------------------------*/
typedef unsigned long long u64;

#define global extern     /* to declare external variables and functions      */

/* Private variables ---------------------------------------------------------*/
ucan_msg_t ucan_msg;
u8 CAN_Mode = Prot_CAN_Mode_LoopSilent;
TaskInfo CANState = {FALSE, FALSE};
static u64 CAN_StartTimerValue = 0LL;

volatile u16 cangenerate_countdown = 0;     // Timer
volatile u16 cangenerate_repeat = 0;        // Reload value


void CAN_ProtocolInit(void)
{
   cangenerate_repeat = 0;
}

/*******************************************************************************
* Function Name  : TIMER_SystTickInit
* Description    : Return the current SysTick elapsed time in microseconds
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
u64 TIMER_ElapsedTime(void)
{
   return (TimeTick * 1000LL) + (SysTick_GetCounter() / 4);
}


/*******************************************************************************
* Function Name  : CAN_Start
* Description    : Start CAN
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CAN_Start(void)
{
   if (CANState.enabled)
   {
      return;
   }

   CAN_InitTypeDef        CAN_InitStructure;
   CAN_FilterInitTypeDef  CAN_FilterInitStructure;
    
    
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
   AFIO->MAPR &= ~0x6000;
   AFIO->MAPR |= 0x4000;   /*Remap Can to PB8 and PB9*/
    
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN,ENABLE);
    
   /* CAN register init */
   CAN_DeInit();
   CAN_StructInit(&CAN_InitStructure);

   /* CAN cell init */
   CAN_InitStructure.CAN_TTCM=DISABLE;
   CAN_InitStructure.CAN_ABOM=DISABLE;
   CAN_InitStructure.CAN_AWUM=DISABLE;
   CAN_InitStructure.CAN_NART=DISABLE;
   CAN_InitStructure.CAN_RFLM=DISABLE;
   CAN_InitStructure.CAN_TXFP=DISABLE;
   CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
   CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;
   CAN_InitStructure.CAN_BS1=CAN_BS1_8tq;
   CAN_InitStructure.CAN_BS2=CAN_BS2_7tq;
   CAN_InitStructure.CAN_Prescaler= 20;

   switch (CAN_Mode)
   {
      case Prot_CAN_Mode_Normal:
                  CAN_InitStructure.CAN_Mode=CAN_Mode_Normal;
                  break;
      case Prot_CAN_Mode_Silent:
                  CAN_InitStructure.CAN_Mode=CAN_Mode_Silent;
                  break;
      case Prot_CAN_Mode_Loopback:
                  CAN_InitStructure.CAN_Mode=CAN_Mode_LoopBack;
                  break;
      case Prot_CAN_Mode_LoopSilent:
                  CAN_InitStructure.CAN_Mode=CAN_Mode_Silent_LoopBack;
                  break;
      default :
                  break;
   }

   CAN_Init(&CAN_InitStructure);

   /* CAN filter init */
   CAN_FilterInitStructure.CAN_FilterNumber=1;
   CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;
   CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;
   CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000;
   CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;
   CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000;
   CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;
   CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO0;
   CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;
   CAN_FilterInit(&CAN_FilterInitStructure);

   /* CAN FIFO0 message pending interrupt enable */
   CAN_ITConfig(CAN_IT_FMP0, ENABLE);

   CANState.enabled = TRUE;

   CAN_StartTimerValue = TIMER_ElapsedTime();

   CAN_ProtocolInit();
}

/*******************************************************************************
* Function Name  : CAN_Stop
* Description    : Stop CAN
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CAN_Stop(void)
{
   if (!CANState.enabled)
   {
      return;
   }

   CAN_DeInit();

   /* disable interrupt handling */
   CAN_ITConfig(CAN_IT_FMP0, DISABLE);

   CANState.enabled = FALSE;
}

/*******************************************************************************
* Function Name  : Send_UCAN_frame
* Description    : Send UCAN frame
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void Send_UCAN_frame (u8 ucan_id, u8 *ucan_data, u16 ucan_len)
{
   int i;
   u8 len = 0;                                // Data length
   u8 data[64];                               // Data buffer
   u8 checksum = 0;                           // Checksum

   data[len++]  = ucan_id;                    // UCAN ID
   data[len++]  = (u8)ucan_len;               // UCAN Length l
   data[len++]  = (u8)(ucan_len>>8);          // UCAN Length h

   for (i = 0; i < ucan_len; i++)
   {
      data[len++] = ucan_data[i];             // UCAN Data
   }

   for (i = 0; i < len; i++)
   {
      checksum -= data[len];                  // Calculate Checksum
   }

   data[len++] = checksum;                    // UCAN Checksum

   protocol_SendFrame (Rep_CAN_Msg, data, len);
}

/*******************************************************************************
* Function Name  : Message_to_UART
* Description    : Send UCAN message
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void Send_UCAN_StatusMessage(u16 appl_func, char *appl_name, char *ctrl_name)
{
   int i;
   u8 len = 0;                                // Data length
   u8 data[42];                               // Data buffer, size 2 + 20 + 20

   data[len++]  = (u8)(appl_func);            // Application functionality
   data[len++]  = (u8)(appl_func>>8);

   for (i=0; i < 20; i++)
   {
      data[len++] = (u8) *appl_name;           // Application name
      if (*appl_name) 
         appl_name++;
   }

   for (i=0; i < 20; i++)
   {
      data[len++] = (u8) *ctrl_name;           // Controller name
      if (*ctrl_name) 
         ctrl_name++;
   }

   Send_UCAN_frame (CAN_ID_STATUS, data, len);
}

/*******************************************************************************
* Function Name  : Message_to_UART
* Description    : Send UCAN message
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void Message_to_UART(CanRxMsg *CanMsg)
{
   int i;
   u32 id;                                   // CAN ID
   u8 len = 0;                               // Data length
   u8 data[16];                              // Data buffer, size max 4 (id) + 8 (DLC) + 2 (time)

   id = CanMsg->StdId;                       // Std ID 11-bit (StdId ranges from 0 to 0x7FF)
   if (CanMsg->IDE == CAN_ID_EXT)
   {
      id |= (CanMsg->ExtId << 11);            // Ext ID 29-bit (ExtId ranges from 0 to 0x3FFFF)
      id |= CAN_CANSPY_INFOMASK_EXTENDED;     // Set extended ID flag
   }

   if(CanMsg->RTR !=0) 
   {
      id |= CAN_CANSPY_INFOMASK_REMOTEREQUEST;
   }
   data[len++]  = (u8)(id);                   // CAN ID
   data[len++]  = (u8)(id>>8);
   data[len++]  = (u8)(id>>16);
   data[len++]  = (u8)(id>>24);

   data[len++]  = (u8)CanMsg->DLC;            // Frame length

   for (i=0; i < CanMsg->DLC; i++)
   {
      data[len++] = CanMsg->Data[i];
   }

   data[len++] = (u8)(ucan_msg.timestamp);   // UCAN timestamp
   data[len++] = (u8)(ucan_msg.timestamp>>8);

   Send_UCAN_frame (ucan_msg.ucan_id, data, len);
}

/*******************************************************************************
* Function Name  : TimeFlDiff
* Description    : Calculate elapsed time between start/end, convert to float
* Input          : None
* Output         : None
* Return         : Elapsed time in 5/11 float format
*******************************************************************************/
u64 current_tst;
static u16 TimeFlDiff(void)
{
   u16 difftime[3]={0,0,0};
   u64 elapsed_time, current_time;

   current_time = TIMER_ElapsedTime();
   elapsed_time = current_time - CAN_StartTimerValue;
    current_tst = elapsed_time;
   CAN_StartTimerValue = current_time;

   difftime[0] = elapsed_time & 0xffff; elapsed_time >>= 16;
   difftime[1] = elapsed_time & 0xffff; elapsed_time >>= 16;
   difftime[2] = elapsed_time & 0xffff; elapsed_time >>= 16;

   if (elapsed_time)
   {
      return 0;     /* Overflow */
   }

   return Time48_ToFloat(difftime);
}

/*******************************************************************************
* Function Name  : CAN_isr
* Description    : Interrupt service routine for the CAN
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CAN_isr(void)
{
   static CanRxMsg RxCanMsg;         /* Buffer for receive messages */

   RxCanMsg.StdId=0x00;
   RxCanMsg.ExtId=0x00;
   RxCanMsg.IDE=0;
   RxCanMsg.DLC=0;
   RxCanMsg.FMI=0;
   RxCanMsg.Data[0]=0x00;
   RxCanMsg.Data[1]=0x00;

   CAN_Receive(CAN_FIFO0, &RxCanMsg);

   if ((ucan_msg.canspy_record)||(ucan_msg.can_generator))
   {
      ucan_msg.timestamp = TimeFlDiff();
      Message_to_UART(&RxCanMsg);
   }
   ucan_msg.can_generator = 0;
}


/*******************************************************************************
* Function Name  : RecvMsg_Status
* Description    : Process incoming CAN "Status" message
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RecvMsg_Status(void)
{
   Send_UCAN_StatusMessage ((CAN_STATUS_FEATURE_SPY | CAN_STATUS_FEATURE_GENERATOR),
                             CAN_STATUS_APPLICATION, CAN_STATUS_CONTROLLER);
}

/*******************************************************************************
* Function Name  : RecvMsg_CANSpy
* Description    : Process incoming CAN "CAN Spy" message
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RecvMsg_CANSpy(u8 *data)
{
   ucan_msg.ucan_spy_cmd = data[3];

   if (ucan_msg.ucan_spy_cmd & CAN_CANSPY_FEATURE_RECORD)
   {
      ucan_msg.canspy_record = 1;      /* turn on CAN recording */
   }
   else
   {
      ucan_msg.canspy_record = 0;      /* turn off CAN recording */
   }

}

/*******************************************************************************
* Function Name  : RecvMsg_CANGenerator
* Description    : Process incoming CAN "CAN generator" message
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RecvMsg_CANGenerator(u8 *data)
{
   static u16 i = 0;
   u8 count = 0;
   u32 info;

   if (ucan_msg.ucan_checksum != 0)
   {
      // drop frame, checksum error
   }

   cangenerate_countdown = FALSE;                       // Disable CAN generator

   info = ((u32) data[3]) | (((u32) data[4]) << 8) |
          (((u32) data[5]) << 16) | (((u32) data[6]) << 24);

   if (info & CAN_CANSPY_INFOMASK_EXTENDED)
   {
      ucan_msg.can_msg.IDE = CAN_ID_EXT;                // Ext ID 29-bit
      ucan_msg.can_msg.ExtId = (info >> 11) & 0x3ffff;  // ExtId ranges from 0 to 0x3FFFF
      ucan_msg.can_msg.StdId = info & 0x7ff;            // StdId ranges from 0 to 0x7FF
   }
   else
   {
      ucan_msg.can_msg.StdId = CAN_ID_STD;              // Std ID 11-bit
      ucan_msg.can_msg.ExtId = 0;                       // ExtId not used
      ucan_msg.can_msg.StdId = info & 0x7ff;            // StdId ranges from 0 to 0x7FF
   }

   ucan_msg.can_msg.DLC = data[7];
   ucan_msg.remoterequest = (info & CAN_CANGENERATE_INFOMASK_REMOTEREQUEST) ? 1 : 0;
   ucan_msg.can_msg.RTR=CAN_RTR_DATA;

   // CAN data
   for (i = 0; i < 8; i++)
   {
      ucan_msg.can_msg.Data[i] = (i < ucan_msg.can_msg.DLC) ? data[8+i] : 0;
   }
   
   if(info & CAN_CANSPY_INFOMASK_REMOTEREQUEST)
   {
      ucan_msg.can_msg.RTR = 0x02;
   }  
      
   if (ucan_msg.can_msg.DLC)
   {
      // CAN time
      i = 8 + ucan_msg.can_msg.DLC;
      ucan_msg.time = ((u16) data[i]) | (((u16) data[i+1]) << 8);

      if (ucan_msg.time)
      {
         // Let timer handle all transmits, start the first transmit within 1 ms
         cangenerate_repeat = ucan_msg.time;       // Repeat time
         cangenerate_countdown = 1;                // Enable CAN generator
      }
      else
      {
         // Just transmit once
         CAN_Transmit(&ucan_msg.can_msg);
      }
   }
}
