/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       hardware.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "hardware.h"
 
 /*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
   /* RCC system reset(for debug purpose) */
   RCC_DeInit();

   /* Enable HSE */
   RCC_HSEConfig(RCC_HSE_Bypass);

   /* Wait till HSE is ready */
   while(RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET);

   /* Flash 2 wait state */
   *(vu32 *)0x40022000 = 0x02;

   /* HCLK = SYSCLK */
   RCC_HCLKConfig(RCC_SYSCLK_Div1);

   /* PCLK2 = HCLK */
   RCC_PCLK2Config(RCC_HCLK_Div1);

   /* PCLK1 = HCLK/2 */
   RCC_PCLK1Config(RCC_HCLK_Div2);

   /* Flash 2 wait state */
   FLASH_SetLatency(FLASH_Latency_2);

   /* Enable Prefetch Buffer */
   FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

/* Select USBCLK source */
   RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_Div1);

   /* PLLCLK = 4MHz * 16 = 64 MHz */
   RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_16);

   /* Enable PLL */
   RCC_PLLCmd(ENABLE);

   /* Wait till PLL is ready */
   while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);

   /* Select PLL as system clock source */
   RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

   /* Wait till PLL is used as system clock source */
   while(RCC_GetSYSCLKSource() != 0x08);

   /* Enable Peripheral clocks */
   RCC_APB1PeriphClockCmd(RCC_APB1ENR_Must | RCC_APB1Periph_TIM3, ENABLE);
   RCC_APB2PeriphClockCmd(RCC_APB2ENR_Must, ENABLE);

   RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA, ENABLE);
//   RCC_ClockSecuritySystemCmd(ENABLE);
/* !!! how to get rid of the NMI ? */

   /* Enable Voltage detector */
   PWR_PVDLevelConfig(PWR_PVDLevel_2V5);
   PWR_PVDCmd(ENABLE);

   /* Enable write access to Backup domain */
   PWR_BackupAccessCmd(ENABLE);

   /* Clear Tamper pin Event(TE) pending flag */
   BKP_ClearFlag();
}

/*******************************************************************************
* Function Name  : RTC_Configuration
* Description    : Configures RTC clock source and prescaler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RTC_Configuration(void)
{
   /* RTC clock source configuration */
   /* Enable the LSE OSC */
   RCC_LSEConfig(RCC_LSE_ON);
   /* Disable the LSI OSC */
   RCC_LSICmd(DISABLE);
   /* Select the RTC Clock Source */
   RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
   /* Enable the RTC Clock */
   RCC_RTCCLKCmd(ENABLE);
   /* Wait till LSE is ready */
   while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);

   /* RTC configuration */
   /* Wait for RTC APB registers synchronisation */
   RTC_WaitForSynchro();

   /* Enable the RTC Alarm interrupt */
//   RTC_ITConfig(RTC_IT_ALR, ENABLE);

   /* Set the RTC time base to 1s */
   RTC_SetPrescaler(32767); //31999
   while(RTC_GetFlagStatus(RTC_FLAG_RTOFF) == RESET);
}
/*******************************************************************************
* Function Name  : EXTI_Configuration
* Description    : Configures EXTI Line9 and Line17(RTC Alarm).
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EXTI_Configuration(void)
{
   /* Connect EXTI Line2 to PB.2 */
   GPIO_EXTILineConfig(GPIO_PortSourceGPIOB, GPIO_PinSource2);

   /* Configure EXTI Line2 to generate an event on rising edge */
   EXTI_ClearITPendingBit(EXTI_Line2);
   EXTI_InitStructure.EXTI_Line = EXTI_Line2;
//   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Event;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
   EXTI_InitStructure.EXTI_LineCmd = DISABLE;
   EXTI_Init(&EXTI_InitStructure);
}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
   NVIC_InitTypeDef NVIC_InitStructure;
#define VECT_TAB_FLASH

#ifdef  VECT_TAB_FLASH
   /* Set the Vector Table base location at 0x08000000 */
   NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#else  /* VECT_TAB_RAM  */
   /* Set the Vector Table base location at 0x20000000 */
   NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#endif
   /* Configure one bit for preemption priority */
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
   /* Enable the USART3 Interrupt */

   NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);
/*
   NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
   NVIC_Init(&NVIC_InitStructure);
*/
   NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 15;
   NVIC_Init(&NVIC_InitStructure);

   NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /* Enable the RTC Interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 4;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   NVIC_InitStructure.NVIC_IRQChannel = ADC_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 5;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /* Enable CAN interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN_RX0_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /*Enable ext interrup 0*/
   NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 6;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /*Enable ext interrup 10*/
   NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 6;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /* Enable the USART2 Interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 6;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /* Enable the USART1 Interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 6;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   /*Enable the Timer1 Interrupt*/
   NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 6;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);
}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : configure GPIO.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
   /* Configure PB.00, PB.01, PB.05 Output push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOB, &GPIO_InitStructure);

   /* Configure USART3 Rx (PB11) as input floating */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOB, &GPIO_InitStructure);

   /* Configure PB2 as input floating (EXTI Line2) */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOB, &GPIO_InitStructure);

#ifdef Control
   /* Configure PC13 as input floating (startup-control) */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOC, &GPIO_InitStructure);

   while (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_13) != Bit_SET);
#endif

   /* Configure USART3 Tx (PB10) as alternate function push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
   GPIO_Init(GPIOB, &GPIO_InitStructure);

   /* Configure PC.04 (ADC Channel14) as analog input */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOC, &GPIO_InitStructure);

   /* Configure USB PullUp (PD2) as opend drain */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOD, &GPIO_InitStructure);
   GPIO_ResetBits(GPIOD, GPIO_Pin_2);
}
/*******************************************************************************
* Function Name  : USART_Configuration
* Description    : configure GPIO.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void USART_Configuration(void)
{
/* USART1 configured as follow:
         - BaudRate = 115200 baud
         - Word Length = 8 Bits
         - One Stop Bit
         - No parity
         - Hardware flow control disabled (RTS and CTS signals)
         - Receive and transmit enabled
         - USART Clock disabled
         - USART CPOL: Clock is active low
         - USART CPHA: Data is captured on the middle
   - USART LastBit: The clock pulse of the last data bit is not output to the SCLK pin
   */
   USART_Cmd(USART3, DISABLE);
   TxHead = TxTail = RxHead = RxTail = 0;
   USART_InitStructure.USART_BaudRate = 115200;
   USART_InitStructure.USART_WordLength = USART_WordLength_8b;
   USART_InitStructure.USART_StopBits = USART_StopBits_1;
   USART_InitStructure.USART_Parity = USART_Parity_No ;
   USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
   USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
   USART_InitStructure.USART_Clock = USART_Clock_Disable;
   USART_InitStructure.USART_CPOL = USART_CPOL_Low;
   USART_InitStructure.USART_CPHA = USART_CPHA_2Edge;
   USART_InitStructure.USART_LastBit = USART_LastBit_Disable;

   USART_Init(USART3, &USART_InitStructure);

   /* Disable the USART Transmit interrupt. It will be enabled by the UART_SendData routine.
      This interrupt is generated when the USART3 transmit data register is empty */
   USART_ITConfig(USART3, USART_IT_TXE, DISABLE);
   /* Enable the USART Receive interrupt: this interrupt is generated when the
      USART3 receive data register is not empty */
   USART_ITConfig(USART3, (USART_IT_RXNE), ENABLE);

   /* Enable USART3 */
   USART_Cmd(USART3, ENABLE);
}
/*******************************************************************************
* Function Name  : WDG_Configuration
* Description    : configure GPIO.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void WDG_Configuration(void)
{
   /* WWDG clock counter = (PCLK1/4096)/8 = 244 Hz (~4 ms)  */
   WWDG_SetPrescaler(WWDG_Prescaler_8);
   /* Set Window value to 0x41 */
   WWDG_SetWindowValue(0x41);
   /* Clear EWI flag */
   WWDG_ClearFlag();
   /* Enable EW interrupt */
}
/*******************************************************************************
* Function Name  : ADC_Configuration
* Description    : configure GPIO.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ADC_Configuration(void)
{
   /* ADC1 Configuration ------------------------------------------------------*/
   ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
   ADC_InitStructure.ADC_ScanConvMode = DISABLE;
   ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
   ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
   ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
   ADC_InitStructure.ADC_NbrOfChannel = 1;
   ADC_Init(ADC1, &ADC_InitStructure);

   /* ADC1 Regular Channel14 Configuration */
   ADC_RegularChannelConfig(ADC1, ADC_Channel_14, 1, ADC_SampleTime_13Cycles5);

   /* Enable ADC1 */
   ADC_Cmd(ADC1, ENABLE);

   /* Start ADC1 Software Conversion */
   ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
/*******************************************************************************
* Function Name  : Setup_HW_Config
* Description    : configure GPIO according the extension board.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Setup_HW_Config(void)
{
   switch (Setup_Data[1]) {
    case Ext_PatchBrd :
                            break;
    case Ext_BluetoothBrd :
                            break;
    case Ext_IOBrd :        /* Configure PC.04 (ADC Channel14) as analog input */
                            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_4;
                            GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
                            GPIO_Init(GPIOC, &GPIO_InitStructure);
                            break;
    case Ext_SensorBrd :
                            break;
    case Ext_None :
    default :
                            break;
   }

}
/*******************************************************************************
* Function Name  : Check_HW_Config
* Description    : check hardware extension board.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Check_HW_Config(void)
{
   u8 i = 0;
   vu16 DataValue;
   /* check the identification voltage of the board */
   if (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC))
      DataValue = ADC_GetConversionValue(ADC1);
   if (DataValue < Thres_Ext_None)
      Setup_Data[1] = Ext_None;
   else if (DataValue > Thres_Ext_PatchBrd)
      Setup_Data[1] = Ext_PatchBrd;
   else if (DataValue > Thres_Ext_BluetoothBrd)
      Setup_Data[1] = Ext_BluetoothBrd;
   else if (DataValue > Thres_Ext_IOBrd)
      Setup_Data[1] = Ext_IOBrd;
   else if (DataValue > Thres_Ext_SensorBrd)
      Setup_Data[1] = Ext_SensorBrd;
   else
      Setup_Data[1] = Ext_Unknown;
   Setup_HW_Config();
   /* insert hardware version number */
   Setup_Data[0] = (u8)HW_Version; /* Hardware Version of the Stick */
   Setup_Data[2] = 0;              /* until the hardware version of the board is read */
   protocol_SendFrame (Rep_Initial_String, (u8 *)Target_Initial_String, Target_Initial_String_Length);
}

/*******************************************************************************
* Function Name  : HW_ReConfig
* Description    : check hardware extension board.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void HW_ReConfig(void)
{
   RCC_APB1PeriphClockCmd(RCC_APB1ENR_Must | RCC_APB1Periph_TIM3, ENABLE);
   RCC_APB2PeriphClockCmd(RCC_APB2ENR_Must, ENABLE);

   RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA, ENABLE);
   
   GPIO_Configuration();
   Setup_HW_Config();
}
