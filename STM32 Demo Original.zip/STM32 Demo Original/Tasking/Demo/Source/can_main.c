/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       CAN_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "can_main.h"
#include "can.h"

/*******************************************************************************
* Function Name  : CAN_ProcessMessage
* Description    : Process CAN messages received from the GUI
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void CommCAN (void)
{
   u8 ch;
   u16 count;

   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_CAN:  /* Status request of the CAN enabled */
                        ch = CANState.enabled ? TaskSwitchOn : TaskSwitchOff;
                        protocol_SendFrame (Rep_Info_CAN, &ch, 1);
                        break;

    case Cmd_CAN_Msg:  /* Message to the CAN Module */
                        ucan_msg.ucan_id = CommTask->Data[0];
                        ucan_msg.ucan_data_length = CommTask->Data[1] + (CommTask->Data[2]<<8);
                        ucan_msg.ucan_checksum = 0;

                        for (count = 0; count < ucan_msg.ucan_data_length; count++)
                        {
                           ucan_msg.ucan_checksum += CommTask->Data[count];
                        }

                        // command structure of UCAN
                        switch (ucan_msg.ucan_id) {
                            case CAN_ID_STATUS:
                                                RecvMsg_Status();
                                                break;
                            case CAN_ID_CANSPY:
                                                RecvMsg_CANSpy(CommTask->Data);
                                                break;
                            case CAN_ID_CANGENERATOR:
                                                RecvMsg_CANGenerator(CommTask->Data);
                                                break;
                            default:           // unsupported ID
                                                break;
                           }
                        break;

    case Cmd_Get_CAN_Mode: /* Request the mode of the CAN */
                        protocol_SendFrame (Rep_Info_CAN_Mode, (u8 *) &CAN_Mode, 1);
                        break;

    case Cmd_Set_CAN_Mode: /* Set the CAN mode */
                        if(CANState.enabled == FALSE)
                            break;
                        CAN_Mode = CommTask->Data[0];
                        CAN_Stop();
                        CAN_Start();
                        break;

    case Cmd_Enable_CAN:   /* Start/Stop the CAN */
                        switch (CommTask->Data[0]) {
                            case TaskSwitchOn:
                                                CAN_Stop();
                                                CAN_Start();
                                                break;
                            case TaskSwitchOff:
                                                CAN_Stop();
                                                break;
                            default:
                                                break;
                           }
                        break;
    default:            /* not implemented */
                        protocol_SendError (Err_NotImplemented);
                        break;
   }
}

//****************************************************************************
