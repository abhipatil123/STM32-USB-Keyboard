/********************************************************************
 * Project:    STM32-Stick
 * File:       time48.c
 *
 * System:     Cortex M3
 * Compiler:   TASKING
 *
 * Date:       2007-04-9
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the STM32-Stick Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in Thumb mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2006/12/20      Gn  Initial revision
 *    Revision 1.1    2007/04/9       HS  Updated for STM32-Stick
 *
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"

// convert 48-bit time to float
//
// Floating time is encoded in 2 bytes together forming a little endian
// word. 5 msb bits are the (2-base) exponent, 11 lsb bits are the mantissa.
// For exponent=0 the mantissa is to be taken as-is, for exponent>0 the
// mantissa is treated as having an implicit added leading '1'.
//
// time = 48-bit time in u16[3] array, least significant in [0]
// returns -> time as 5/11 non-normalized float

u16 Time48_ToFloat(u16 *time)
{
   u16 timeword;
   // On a desktop this function would read:
   //
   //     uint64_t time;
   //     uint16_t result;
   //
   //     if (time > 0x800)
   //     {
   //         uint16_t exp = 1;
   //         while (time >= 0x1000)
   //         {
   //             ++exp;
   //             time >>= 1;
   //         }
   //         result = (exp << 11) | (time & 0x7FF);
   //     }
   //     else
   //     {
   //         result = time;
   //     }
   //
   // For performance reasons and the lack of a 64-bit datatype
   // the code below uses a different hand-encoded tree approach.
   //
   // Just to be complete this is how to decode this
   // format on a desktop:
   //
   //     uint16_t floattime;
   //     uint64_t result;
   //
   //     if (floattime & 0xF800)
   //     {
   //         result = (floattime & 0x07FF) | 0x0800;
   //         result <<= (floattime >> 11) - 1;
   //     }
   //     else
   //     {
   //         result = floattime;
   //     }
   //

   if (time[2])
   {
       timeword = time[2];

      if (timeword & 0xFF00)
      {
         if (timeword & 0xFC00)
         {
            // overflow, just return maximum value
            return 0xFFFF;
         }
         else // 0x0300
         {
            if (timeword & 0x0200)
            {
               return (31u << 11) | (((timeword << 2) | (time[1] >> 14)) & 0x7FF);
            }
            else // 0x0100
            {
               return (30u << 11) | (((timeword << 3) | (time[1] >> 13)) & 0x7FF);
            }
         }
      }
      else // 0x00FF
      {
         if (timeword & 0x00F0)
         {
            if (timeword & 0x00C0)
            {
               if (timeword & 0x0080)
               {
                  return (29u << 11) | (((timeword << 4) | (time[1] >> 12)) & 0x7FF);
               }
               else // 0x0040
               {
                  return (28u << 11) | (((timeword << 5) | (time[1] >> 11)) & 0x7FF);
               }
            }
            else // 0x0030
            {
               if (timeword & 0x0020)
               {
                  return (27u << 11) | (((timeword << 6) | (time[1] >> 10)) & 0x7FF);
               }
               else // 0x0010
               {
                  return (26u << 11) | (((timeword << 7) | (time[1] >> 9)) & 0x7FF);
               }
            }
         }
         else // 0x000F
         {
            if (timeword & 0x000C)
            {
               if (timeword & 0x0008)
               {
                  return (25u << 11) | (((timeword << 8) | (time[1] >> 8)) & 0x7FF);
               }
               else // 0x0004
               {
                  return (24u << 11) | (((timeword << 9) | (time[1] >> 7)) & 0x7FF);
               }
            }
            else // 0x0003
            {
               if (timeword & 0x0002)
               {
                  return (23u << 11) | (((timeword << 10) | (time[1] >> 6)) & 0x7FF);
               }
               else // 0x0001
               {
                  return (22u << 11) | ((time[1] >> 5) & 0x7FF);
               }
            }
         }
      }
   }
   else if (time[1])
   {
      timeword = time[1];

      if (timeword & 0xFF00)
      {
         if (timeword & 0xF000)
         {
            if (timeword & 0xC000)
            {
               if (timeword & 0x8000)
               {
                  return (21u << 11) | ((timeword >> 4) & 0x7FF);
               }
               else // 0x4000
               {
                  return (20u << 11) | ((timeword >> 3) & 0x7FF);
               }
            }
            else // 0x3000
            {
               if (timeword & 0x2000)
               {
                  return (19u << 11) | ((timeword >> 2) & 0x7FF);
               }
               else // 0x1000
               {
                  return (18u << 11) | ((timeword >> 1) & 0x7FF);
               }
            }
         }
         else // 0x0F00
         {
            if (timeword & 0x0C00)
            {
               if (timeword & 0x0800)
               {
                  return (17u << 11) | (timeword & 0x7FF);
               }
               else // 0x0400
               {
                  return (16u << 11) | (((timeword << 1) | (time[0] >> 15)) & 0x7FF);
               }
            }
            else // 0x0300
            {
               if (timeword & 0x0200)
               {
                  return (15u << 11) | (((timeword << 2) | (time[0] >> 14)) & 0x7FF);
               }
               else // 0x0100
               {
                  return (14u << 11) | (((timeword << 3) | (time[0] >> 13)) & 0x7FF);
               }
            }
         }
      }
      else // 0x00FF
      {
         if (timeword & 0x00F0)
         {
            if (timeword & 0x00C0)
            {
               if (timeword & 0x0080)
               {
                  return (13u << 11) | (((timeword << 4) | (time[0] >> 12)) & 0x7FF);
               }
               else // 0x0040
               {
                  return (12u << 11) | (((timeword << 5) | (time[0] >> 11)) & 0x7FF);
               }
            }
            else // 0x0030
            {
               if (timeword & 0x0020)
               {
                  return (11u << 11) | (((timeword << 6) | (time[0] >> 10)) & 0x7FF);
               }
               else // 0x0010
               {
                  return (10u << 11) | (((timeword << 7) | (time[0] >> 9)) & 0x7FF);
               }
            }
         }
         else // 0x000F
         {
            if (timeword & 0x000C)
            {
               if (timeword & 0x0008)
               {
                  return (9u << 11) | (((timeword << 8) | (time[0] >> 8)) & 0x7FF);
               }
               else // 0x0004
               {
                  return (8u << 11) | (((timeword << 9) | (time[0] >> 7)) & 0x7FF);
               }
            }
            else // 0x0003
            {
               if (timeword & 0x0002)
               {
                  return (7u << 11) | (((timeword << 10) | (time[0] >> 6)) & 0x7FF);
               }
               else // 0x0001
               {
                  return (6u << 11) | ((time[0] >> 5) & 0x7FF);
               }
            }
         }
      }
   }
   else
   {
      timeword = time[0];

      if (timeword & 0xF800)
      {
         if (timeword & 0xE000)
         {
            if (timeword & 0x8000)
            {
               return (5u << 11) | ((timeword >> 4) & 0x7FF);
            }
            else if (timeword & 0x4000)
            {
               return (4u << 11) | ((timeword >> 3) & 0x7FF);
            }
            else // 0x2000
            {
               return (3u << 11) | ((timeword >> 2) & 0x7FF);
            }
         }
         else // 0x1800
         {
            if (timeword & 0x1000)
            {
               return (2u << 11) | ((timeword >> 1) & 0x7FF);
            }
            else // 0x0800
            {
               return (1u << 11) | (timeword & 0x7FF);
            }
         }
      }
      else // 0x07FF
      {
         // as the format is not normalized this can
         // all be handled with exp=0
         // note: exp=0 has NO implicit leading '1'
         return timeword;
      }
   }
}

