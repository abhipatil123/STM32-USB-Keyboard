/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       meassure_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#include "system.h"
#include "FFTfunc.h"
#include "measure_main.h"


TaskInfo VU1State;
TaskInfo AmbState;
TaskInfo ScanState;
TaskInfo OversamplingState;
TaskInfo FFTState;
TaskInfo CounterState;

short fr[N_SAMPLE], fi[N_SAMPLE], loud[N_SAMPLE/2];
u16 FFT_Index = 0;
u32 event_counter;
u32 frequency;
u16 freq_time;
u8 tim_set_null;
u8 FFT_Port;
u8 TriggerSource;

bool Counter_Gate;

void START_ADCs (void)
{
   /* ADC1 Configuration ------------------------------------------------------*/
   ADC_DeInit(ADC1);
   ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
   ADC_InitStructure.ADC_ScanConvMode = ENABLE;
   ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
   ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
   ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
   ADC_InitStructure.ADC_NbrOfChannel = 1;
   ADC_Init(ADC1, &ADC_InitStructure);


   /* ADC1 Regular Channel14 Configuration */
   ADC_RegularChannelConfig(ADC1, ADC_Channel_8,  1, ADC_SampleTime_55Cycles5);
   /* Enable Vrefint channel17 */
   ADC_TempSensorVrefintCmd(ENABLE);
   /* Enable ADC1 */
   ADC_Cmd(ADC1, ENABLE);
}

void AmbStop(void)
{
   /* Configure PB.00 (ADC Channel8) as input */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   /* reset PB1 for voltage source usage */
   GPIO_WriteBit(GPIOB, GPIO_Pin_1, Bit_RESET);
   AmbState.enabled = FALSE;
}
void VU1Stop(void)
{
   /* Configure PC.00 (ADC Channel10) as input */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
   GPIO_Init(GPIOC, &GPIO_InitStructure);
   VU1State.enabled = FALSE;
}
/*-----------------------------------------------------------------------------------*/
void VU1Start(void)
{
   /* Configure PC.00 (ADC Channel10) as analog input */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOC, &GPIO_InitStructure);

   START_ADCs ();

   FFT_Index = 0;
   /* Start ADC1 Software Conversion */
   ADC_SoftwareStartConvCmd(ADC1, ENABLE);

   VU1State.enabled = TRUE;
}

void AmbStart(void)
{
   /* Configure PB.00 (ADC Channel8) as analog input */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   /* reset PB1 for voltage source usage */
   GPIO_WriteBit(GPIOB, GPIO_Pin_1, Bit_RESET);

   START_ADCs ();

   FFT_Index = 0;
   /* Start ADC1 Software Conversion */
   ADC_SoftwareStartConvCmd(ADC1, ENABLE);
   AmbState.enabled = TRUE;
}

void ScanStart(void)
{
   EXTI_DeInit();

   GPIO_EXTILineConfig(GPIO_PortSourceGPIOC,GPIO_PinSource0);

   EXTI_ClearITPendingBit(EXTI_Line0);
   EXTI_InitStructure.EXTI_Line = EXTI_Line0;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
   EXTI_InitStructure.EXTI_LineCmd = ENABLE;
   EXTI_Init(&EXTI_InitStructure);


   /*Init Timer*/
   TIM_DeInit(TIM2);
   TIM_InternalClockConfig(TIM2);

   TIM_TimeBaseStructure.TIM_Period = 0xFFFF;
   TIM_TimeBaseStructure.TIM_Prescaler = 6400;       /*Sample rate 1ms*/
   TIM_TimeBaseStructure.TIM_ClockDivision =TIM_CKD_DIV1;
   TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
   TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);


   TIM_SetCounter(TIM2,0);

   frequency =0;
   tim_set_null = 1;
   TIM_Cmd(TIM2, ENABLE);
   EXTI_Init(&EXTI_InitStructure);

   ScanState.enabled = TRUE;
}
void ScanStop(void)
{
   EXTI_DeInit();

   TIM_DeInit(TIM2);

   ScanState.enabled = FALSE;
}
void CounterStart(void)
{
   EXTI_DeInit();

   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
   GPIO_Init(GPIOC, &GPIO_InitStructure);
   
   GPIO_EXTILineConfig(GPIO_PortSourceGPIOC,GPIO_PinSource0);

   EXTI_ClearITPendingBit(EXTI_Line0);
   EXTI_InitStructure.EXTI_Line = EXTI_Line0;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
   EXTI_InitStructure.EXTI_LineCmd = ENABLE;
   EXTI_Init(&EXTI_InitStructure);

   event_counter = 0;
   CounterState.enabled = TRUE;
   Counter_Gate = FALSE;
}
void CounterStop(void)
{
   EXTI_DeInit();
   CounterState.enabled = FALSE;
}
void OversamplingStart(void)
{

   OversamplingState.enabled = TRUE;
}
/*-----------------------------------------------------------------------------------*/
void FFT (void)
{
   int i=0;
   if (FFTState.enabled)
   {
      if (FFTState.process_ready == FALSE)
      {
         wave(fi,0,0,0);               // set fi to 0
         if(FFT_Port == 3)
         {
            Norming (fr, 1, 1);        // correct to the analog world
         }
         else
         {
            Norming (fr, 3, 2);        // correct to the analog world
         }
         window(fr);
         fft(fr, fi);
         loudness(loud, fr, fi);
         FFTState.process_ready = FALSE;
         FFTState.enabled = FALSE;
         ReEntryProcess = Dummy;
         ReEntry.enabled = FALSE;
      }
      else
      {
         /* data are on the line */
//         if (SendTask->Process == 0)
         {
            FFTState.enabled = TRUE;
            /* TIM1 counter disable */
            TIM_Cmd(TIM2, ENABLE);

            while (FFT_Index < N_SAMPLE);
            FFT_Index = 0;

            /* TIM1 counter disable */
            TIM_Cmd(TIM2, DISABLE);
            FFTState.process_ready = FALSE;
         }
      }
   }
}

void FFTStart(void)
{
   /* Configure TIM1_CH1 (PA8) as alternate function push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
   GPIO_Init(GPIOA, &GPIO_InitStructure);

   /* TIM1 configuration ------------------------------------------------------*/
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
   TIM_DeInit(TIM2);
   TIM_TimeBaseStructure.TIM_Period = 400; //0x100 low
   if(FFT_Port == 3)
      TIM_TimeBaseStructure.TIM_Prescaler = 10;
   else
      TIM_TimeBaseStructure.TIM_Prescaler = 25;
   TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
   TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
   TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

   /* Output Compare Toggle Mode configuration: Channel1 */
   TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Toggle;
   TIM_OCInitStructure.TIM_Channel = TIM_Channel_1;
   TIM_OCInitStructure.TIM_Pulse = 0x80; //0x7D00;//0x1FFF;
   TIM_OCInit(TIM2, &TIM_OCInitStructure);

   TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Disable);
   TIM_ARRPreloadConfig(TIM2, ENABLE);

   TIM_SetCompare2(TIM2, 400);
   TIM_GenerateEvent(TIM2, TIM_IT_CC2);
   TIM_ITConfig(TIM2, TIM_IT_CC2, ENABLE);



   /* ADC1 configuration ------------------------------------------------------*/
   ADC_DeInit(ADC1);
   ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
   ADC_InitStructure.ADC_ScanConvMode = DISABLE;
   ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
   ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2;
   ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
   ADC_InitStructure.ADC_NbrOfChannel = 1;
   ADC_Init(ADC1, &ADC_InitStructure);

   /* ADC1 regular channel11 configuration */
   if(FFT_Port == 3)
      ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_13Cycles5);
   else
      ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 1, ADC_SampleTime_13Cycles5);

   /* Enable ADC1 external trigger */
   ADC_ExternalTrigConvCmd(ADC1, ENABLE);

   /* Enable ADC1 */
   ADC_Cmd(ADC1, ENABLE);

   /* Enable ADC1 reset calibaration register */
   ADC_ResetCalibration(ADC1);
   /* Check the end of ADC1 reset calibration register */
   while(ADC_GetResetCalibrationStatus(ADC1));

   /* Start ADC1 calibaration */
   ADC_StartCalibration(ADC1);
   /* Check the end of ADC1 calibration */
   while(ADC_GetCalibrationStatus(ADC1));


   /* TIM1 counter enable */
   TIM_Cmd(TIM2, ENABLE);

   FFTState.enabled = TRUE;
   while (FFT_Index < N_SAMPLE);
   FFT_Index = 0;

   /* TIM1 counter disable */
   TIM_Cmd(TIM2, DISABLE);
   ADC_ITConfig(ADC1, ADC_IT_EOC, DISABLE);

   FFTState.enabled = TRUE;
   FFTState.process_ready = FALSE;
//   SendTask->Process = 2;
   ReEntryProcess = FFT;
   ReEntry.enabled = TRUE;
}

/*-----------------------------------------------------------------------------------*/


void CommMeasFFT (void)
{
   u16 i = 0;
   s32 value = 0;

   CommTask->CommandNew = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_Temp : /* GUI   Status request of the Temp enabled */
                           ADC_TempSensorVrefintCmd(ENABLE);
                           ADC_RegularChannelConfig(ADC1, ADC_Channel_16,  1, ADC_SampleTime_239Cycles5);
                           ADC_Cmd(ADC1, ENABLE);
                           ADC_SoftwareStartConvCmd(ADC1, ENABLE);
                           while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
                           value =  ADC_GetConversionValue(ADC1);

                           value = (1480-(value*3300)/4095)/2+50;
                           ADC_ClearFlag(ADC1,ADC_FLAG_EOC);
                           ADC_Cmd(ADC1, DISABLE);

                           SendTask->DataLength = 1;
                           if(value > 100)
                              value = 100;
                           if(value < 0)
                              value = 0;

                           protocol_SendFrame (Rep_Info_Temp, (u8 *)&value,1);
                           break;
    case Cmd_Get_VU1 : /* GUI   Status request of the VU enabled */
                           SendTask->Data[0] = (u8)VU1State.enabled+1;
                           SendTask->Data[2] = 0x00;
                           SendTask->Data[1] = 0x00;
                           if(VU1State.enabled == TRUE)
                           {
                              ADC_RegularChannelConfig(ADC1, ADC_Channel_10,  1, ADC_SampleTime_55Cycles5);
                              ADC_Cmd(ADC1, ENABLE);
                              ADC_SoftwareStartConvCmd(ADC1, ENABLE);
                              while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
                              value =  ADC_GetConversionValue(ADC1);
                              ADC_ClearFlag(ADC1,ADC_FLAG_EOC);
                              ADC_Cmd(ADC1, DISABLE);

                              SendTask->Data[2] = (u8)(value>>8);
                              SendTask->Data[1] = (u8)value;
                           }
                           protocol_SendFrame (Rep_Info_VU1, (u8 *)&SendTask->Data,3);
                           break;
    case Cmd_Enable_VU1  : /* GUI   Start/Stop the VU */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOn)
                           {
                              if (VU1State.enabled == FALSE)
                                 VU1Start();
                           }
                           else
                           {
                              VU1Stop();
                           }
                           break;
    case Cmd_Get_Amb_Light : /* GUI   Status request of the Ambi enabled */
                           SendTask->Data[0] = (u8)AmbState.enabled+1;
                           SendTask->Data[2] = 0x00;
                           SendTask->Data[1] = 0x00;
                           if (AmbState.enabled == TRUE)
                           {
                              ADC_RegularChannelConfig(ADC1, ADC_Channel_8,  1, ADC_SampleTime_55Cycles5);
                              ADC_Cmd(ADC1, ENABLE);
                              ADC_SoftwareStartConvCmd(ADC1, ENABLE);
                              while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
                              value =  ADC_GetConversionValue(ADC1);
                              ADC_ClearFlag(ADC1,ADC_FLAG_EOC);

                              value = (value << 1)-0x400;  /*scaling +ofset*/
                              ADC_Cmd(ADC1, DISABLE);
                              SendTask->Data[2] = (u8)(value>>8);
                              SendTask->Data[1] = (u8)value;
                           }
                           protocol_SendFrame (Rep_Info_Amb_Light, (u8 *)&SendTask->Data,3);
                           break;
    case Cmd_Enable_Amb_Light  : /* GUI   Start/Stop the Ethernet */
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOn)
                           {
                              AmbStart();
                           }
                           else
                           {
                              AmbStop();
                           }
                           break;
    case Cmd_Get_Trigger : /*  */
                           protocol_SendFrame (Rep_Info_Trigger, (u8 *)&TriggerSource,1);
                           break;
    case Cmd_Set_Trigger : /* */
                           TriggerSource = SendTask->Data[0];
                           break;
    case Cmd_Get_Scanner : /* */
                           protocol_SendFrame (Rep_Info_Scanner, (u8 *)(ScanState.enabled+1),1);
                           break;
    case Cmd_Enable_Scanner  : /*  */
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == 0x02)
                           {
                              /*stop lightmeter*/
                              AmbStop();
                              /*stop Voltmeter*/
                              VU1Stop();
                              /*stop counter */
                              CounterStop();

                              ScanStart();
                           }
                           else if(CommTask->Data[0] == 0x04)
                           {
                              /*stop lightmeter*/
                              AmbStop();
                              /*stop Voltmeter*/
                              VU1Stop();
                              /*stop scanner*/
                              ScanStop();

                              CounterStart();
                           }
                           else
                           {
                              ScanStop();
                              CounterStop();

                              AmbStart(); /*start lightmeter*/
                              VU1Start(); /*start voltmeter*/
                           }
                           break;
    case Cmd_Get_Meassurement : /* */
                           if(CounterState.enabled !=FALSE)
                           {
                              protocol_DWSendFrame (Rep_Info_Meassurement, &event_counter,4);
                           }
                           else if(ScanState.enabled !=FALSE)
                           {
                              protocol_DWSendFrame (Rep_Info_Meassurement, &frequency,4);
                           }
                           else
                           {
                              value = 0;
                              protocol_DWSendFrame (Rep_Info_Meassurement, (u32*)&value,4);
                           }
                           break;
    case Cmd_Get_Oversampling : /* */
                           protocol_SendFrame (Rep_Info_Oversampling, (u8 *)(OversamplingState.enabled+1),1);
                           break;
    case Cmd_Enable_Oversampling  : /* */
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOn)
                           {
                              OversamplingStart();
                           }
                           else
                           {
                              OversamplingState.enabled = FALSE;
                           }
                           break;
    case Cmd_Get_Spectrum : /* */
                           protocol_SendFrame (Rep_Info_Spectrum, (u8 *)(FFTState.enabled+1),1);
                           break;
    case Cmd_Get_Spectrum_Data : /* */
                           if(FFTState.process_ready==FALSE)
                           {
                              if(FFTState.enabled==FALSE)
                              {
                                 FFTState.process_ready = TRUE;
                                 FFTState.enabled = TRUE;
                                 ReEntryProcess = FFT;
                                 ReEntry.enabled = TRUE;
                              }
                           }
                           protocol_u16SendFrame (Rep_Info_Spectrum_Data, (u16 *)loud,128);
                           break;
    case Cmd_Enable_Spectrum  : /* */
                           SendTask->ReplyNew = FALSE;
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOff)
                           {
                              TIM_Cmd(TIM2, DISABLE);
                              FFTState.enabled = FALSE;
                           }
                           else
                           {
                              FFT_Port = CommTask->Data[0];
                              FFTStart();

                           }
                           break;
    default :              /* not implemented */
                           protocol_SendError (Err_NotImplemented);
                           break;
    }
}
