/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       UIR.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/


#include "system.h"
#include "UIR.h"
#include "systick.h"
//#include "measure_main.h"

/*******************************************************************************
* Function Name  : UART1_isr
* Description    : Interrupt service of the USART1 module.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART1_isr(void)
{
/**UART1 IRDA Receiver Routine*/
   u8 i;
   if(UIR_State == UART_IDRDA_enable)
   {/*UARTIRDA Enabled*/    
      if((uart_com_buff.transmit == TRUE) & (uart_com_buff.ready == FALSE))
      {/*Direction change*/
         if(SendTask->Process == 0)
         {
            SendTask->ReplyNew = TRUE;
            SendTask->Command = Cmd_Info_UIR_Data; /*   App   Subnet mask settings */
            SendTask->DataLength = uart_com_buff.pos+2;
            SendTask->Data[0] = 0x54;                     /* T */
            for(i=0;i<uart_com_buff.pos;i++)
               SendTask->Data[i+1] = uart_com_buff.data[i];
            SendTask->Data[uart_com_buff.pos+1] = 0x0D;   /* <CR> */                      
            
            uart_com_buff.pos = 0;                        /*reset buffer*/
         }
      }
   
      uart_com_buff.transmit = FALSE;
      uart_com_buff.receive = TRUE;
      uart_com_buff.ready = FALSE;
       
      uart_com_buff.data[uart_com_buff.pos++] = USART_ReceiveData(USART1);
      USART_SendData(USART2,uart_com_buff.data[uart_com_buff.pos-1]);
       
      if(uart_com_buff.pos >= 64)
      {/*Buffer full, send*/   
         if(SendTask->Process == 0)
         {
            SendTask->ReplyNew = TRUE;
            SendTask->Command = Cmd_Info_UIR_Data; /*   App   Subnet mask settings */
            SendTask->DataLength = 66;
            SendTask->Data[0] = 0x52;                    /* R */
            for(i=0;i<64;i++)
               SendTask->Data[i+1] = uart_com_buff.data[i];
            SendTask->Data[65] = 0x0D;                   /* <CR> */    
             
            uart_com_buff.receive = FALSE;
            uart_com_buff.ready = TRUE;
            uart_com_buff.pos = 0;                       /*reset buffer*/
         }
      }
      Timer_Send = 0;
   }

   USART_ClearITPendingBit(USART1,USART_IT_RXNE);
}

/*******************************************************************************
* Function Name  : UART2_isr
* Description    : Interrupt service of the USART2 module.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UART2_isr(void)
{
/**UART2 Interrup for IRDA*/
   u8 i;
   if(UIR_State == UART_IDRDA_enable)
   {/*UARt IRDA Enabled*/    
      if((uart_com_buff.receive == TRUE) & (uart_com_buff.ready == FALSE))
      {/*direction change*/
         if(SendTask->Process == 0)
         {
//            SendTask->Command = Cmd_Info_UIR_Data; /*   App   Subnet mask settings */
//            SendTask->DataLength = uart_com_buff.pos+2;
            SendTask->Data[0] = 0x52;
            for(i=0;i<uart_com_buff.pos;i++)
               SendTask->Data[i+1] = uart_com_buff.data[i];
            SendTask->Data[uart_com_buff.pos+1] = 0x0D;                      
            protocol_SendFrame (Cmd_Info_UIR_Data, (u8 *)&SendTask->Data, uart_com_buff.pos+2);
            uart_com_buff.pos = 0;
         }
      }
   
      uart_com_buff.transmit = TRUE;
      uart_com_buff.receive = FALSE;
      uart_com_buff.ready = FALSE;
        
      uart_com_buff.data[uart_com_buff.pos++] = USART_ReceiveData(USART2);
      USART_SendData(USART1,uart_com_buff.data[uart_com_buff.pos-1]);
        
      if(uart_com_buff.pos >= 64)
      {/*buffer full*/
         if(SendTask->Process == 0)
         {
 //           SendTask->ReplyNew = TRUE;
//            SendTask->Command = Cmd_Info_UIR_Data; /*   App   Subnet mask settings */
            SendTask->DataLength = 66;
            SendTask->Data[0] = 0x54;
            for(i=0;i<64;i++)
               SendTask->Data[i+1] = uart_com_buff.data[i];
            SendTask->Data[65] = 0x0D;
            protocol_SendFrame (Cmd_Info_UIR_Data, (u8 *)&SendTask->Data, 66);
            uart_com_buff.transmit = FALSE;      
            uart_com_buff.ready = TRUE;
            uart_com_buff.pos = 0;
         }
      }
      Timer_Send = 0;
   }
   
   USART_ClearITPendingBit(USART2,USART_IT_RXNE);
}

/*-----------------------------------------------------------------------------------*/
