/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       usb_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

#include "system.h"
#include "usb_lib.h"
#include "usb_main.h"
#include "usb_desc.h"


TaskInfo USBState = {FALSE, FALSE};
TaskInfo USB_ApplState = {FALSE, FALSE};
TaskInfo USB_ENUM = {FALSE, FALSE};
u8 USB_AppConfig[4] = {0xFF,0,0,0}; // Intervall, shape, size, step
u16 USBApplIndex = 0;
u8 USBApplSideIndex = 0;
u32 USBApplTime;


/*******************************************************************************
* Function Name  : USB_Cable_Config.
* Description    : Software Connection/Disconnection of USB Cable.
* Input          : NewState: new state.
* Output         : None.
* Return         : None
*******************************************************************************/

static u8 UnicodeToAscii( u8* Source, u8 *Destination)
{
   u8 Length;
   u8 Bytes;
   Bytes = *Source;
   /* Set pointer to first character */
   Source+=2; Bytes -=2;
   Length = (Bytes/2)-1;

   while ( Bytes > 0 )
   {
      *Destination++ = *Source;
      Source+=2;
      Bytes -=2;
   }
   *Destination = 0; /* Create a 0 terminated string */
   return Length +1;
}

void USB_Cable_Config (FunctionalState NewState)
{
   if (NewState != DISABLE)
   {
      GPIO_SetBits(GPIOD, GPIO_Pin_2);
   }
   else
   {
      GPIO_ResetBits(GPIOD, GPIO_Pin_2);
}
}

void USBStart (void)
{
   u32 tmpreg = 0;
   u8 PLLSet[5];
   /* switch to 48 MHz */

   /* disable UART receive interrupt */
   USART_ITConfig(USART3, (USART_IT_RXNE),DISABLE);
   /* clear pending bits */
   USART_ClearITPendingBit(USART3,USART_IT_RXNE);

   PLLSet[1] = 0x69;
   PLLSet[2] = 0x05;
   PLLSet[3] = 0x0A;

   //tmpreg &= (CFGR_HPRE_Reset_Mask | CFGR_PPRE2_Reset_Mask | CFGR_PPRE1_Reset_Mask);
   tmpreg = PLLSet[3] | (u32)PLLSet[2]<<8 | (u32)PLLSet[1]<<16;

   /* Select HSE as system clock source */
   RCC_SYSCLKConfig(RCC_SYSCLKSource_HSE);

   RCC_PLLCmd(DISABLE);

   /* Store the new value */
   RCC->CFGR = tmpreg;

   RCC_PLLCmd(ENABLE);

   while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
   /* Select PLL as system clock source */
   RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

   /* Wait till PLL is used as system clock source */
   while(RCC_GetSYSCLKSource() != 0x08);
   /* reinit RS232 USRART3 */
   USART_Configuration();
   /* clear pending bits */
   USART_ClearITPendingBit(USART3,USART_IT_RXNE);
   /* enable UART receive interrupt */
   USART_ITConfig(USART3, (USART_IT_RXNE), ENABLE);

   /* Select USBCLK source */
   RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_Div1);

   USB_Init();
   USBState.enabled = TRUE;
}

void USBStop(void)
{
   u32 tmpreg = 0;
   // 0x39
   // 0x04
   // 0x0A
   /* reset the clocks */
}

void USBApplStart(void)
{
   USB_ApplState.enabled = TRUE;
   ReEntry.enabled = TRUE;
   ReEntryProcess = USBAppl;
}
void USBApplStop(void)
{
   USB_ApplState.enabled = FALSE;
   ReEntry.enabled = FALSE;
   ReEntryProcess = Dummy;
}

/* generate mouse message data */
void USBAppl (void)
{
   u8 newpos[4] = {0,0,0,0};
   
       /*newpos[0]=0x00;
       newpos[1]=0x00;
       newpos[2]=0x81;
       newpos[3]=0x00;
       newpos[4]=0x00;
       newpos[5]=0x00;
       newpos[6]=0x00;
       newpos[7]=0x00;*/
       u8 StepSize;
   u8 maxlength;  

   if (TimeTick > USBApplTime)
   {
      maxlength = 0x01<<(USB_AppConfig[2]+1);
      if (USB_AppConfig[3] == 0) 
         USB_AppConfig[3] = 1;
      StepSize = 0x01<<(USB_AppConfig[3]-1); // stepsize
      switch (USB_AppConfig[1]) {
       case USB_Shape_Line    :  /* 0 or 128 no movement, FF-126 / 127 max speed */
                                 USBApplIndex += StepSize;            // increment stepsize
                                 if (USBApplIndex > maxlength)        // check overrun
                                 {
                                    USBApplSideIndex++;
                                    if (USBApplSideIndex > 1)
                                       USBApplSideIndex = 0;
                                    USBApplIndex = 0;
                                 }
                                 switch (USBApplSideIndex) {
                                  case 0 : /* side a */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 0;
                                           break;
                                  case 1 : /* side b */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 0;
                                           break;
                                  default : /* error */
                                           USBApplSideIndex = 0;
                                           break;
                                  }
                                 break;
       case USB_Shape_Triangle:  /* */
                                 USBApplIndex += StepSize;            // increment stepsize
                                 if (USBApplIndex > maxlength)        // check overrun
                                 {
                                    USBApplSideIndex++;
                                    if (USBApplSideIndex > 2)
                                       USBApplSideIndex = 0;
                                    USBApplIndex = 0;
                                 }
                                 switch (USBApplSideIndex) {
                                  case 0 : /* side a */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 0;
                                           break;
                                  
                                  case 1 : /* side b */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 2 : /* side c */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  default : /* error */
                                           USBApplSideIndex = 0;
                                           break;
                                  }
                                 break;
       case USB_Shape_Square  :  /* */
                                 USBApplIndex += StepSize;            // increment stepsize
                                 if (USBApplIndex > maxlength)        // check overrun
                                 {
                                    USBApplSideIndex++;
                                    if (USBApplSideIndex > 3)
                                       USBApplSideIndex = 0;
                                    USBApplIndex = 0;
                                 }
                                 switch (USBApplSideIndex) {
                                  case 0 : /* side a */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 0;
                                           break;
                                  case 1 : /* side b */  
                                           newpos[1] = 0;
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 2 : /* side c */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 0;
                                           break;
                                  case 3 : /* side d */  
                                           newpos[1] = 0;
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  default : /* error */
                                           USBApplSideIndex = 0;
                                           break;
                                  }
                                 break;
       case USB_Shape_Hexagon :  /* */
                                 USBApplIndex += StepSize;            // increment stepsize
                                 if (USBApplIndex > maxlength)        // check overrun
                                 {
                                    USBApplSideIndex++;
                                    if (USBApplSideIndex > 5)
                                       USBApplSideIndex = 0;
                                    USBApplIndex = 0;
                                 }
                                 
                                 switch (USBApplSideIndex) {
                                  case 0 : /* side a */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 0;
                                           break;
                                  case 1 : /* side b */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  case 2 : /* side c */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  case 3 : /* side d */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 0;
                                           break;
                                  case 4 : /* side e */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 5 : /* side f */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 1*StepSize;
                                           break;
                                  default : /* error */
                                           USBApplSideIndex = 0;
                                           break;
                                  }
                                 break;
       case USB_Shape_Octagon :  /* */
                                 USBApplIndex += StepSize;            // increment stepsize
                                 if (USBApplIndex > maxlength)        // check overrun
                                 {
                                    USBApplSideIndex++;
                                    if (USBApplSideIndex > 7)
                                       USBApplSideIndex = 0;
                                    USBApplIndex = 0;
                                 }
                                 
                                 switch (USBApplSideIndex) {
                                  case 0 : /* side a */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 0;
                                           break;
                                  case 1 : /* side b */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 2 : /* side c */  
                                           newpos[1] = 0;
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 3 : /* side d */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 1*StepSize;
                                           break;
                                  case 4 : /* side e */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = 0;
                                           break;
                                  case 5 : /* side f */  
                                           newpos[1] = (s8)(-1*StepSize);
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  case 6 : /* side e */  
                                           newpos[1] = 0;
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  case 7 : /* side f */  
                                           newpos[1] = 1*StepSize;
                                           newpos[2] = (s8)(-1*StepSize);
                                           break;
                                  default : /* error */
                                           USBApplSideIndex = 0;
                                           break;
                                  }
                                 break;
       default                :  /* */
                                 USB_AppConfig[1] = 0;
                                 break;
       }
      /*copy new position info in ENDP1 Tx Packet Memory Area*/
      UserToPMABufferCopy(newpos, GetEPTxAddr(ENDP1), 4);
      /* enable endpoint for transmission */
      SetEPTxValid(ENDP1);
      USBApplTime = TimeTick + USB_AppConfig[0];
   }

}

void CommUSB (void)
{
   u8 i = 0;
   u32 temp;

   CommTask->CommandNew = FALSE;
   //SendTask->Target = FALSE;
   switch (CommTask->Command) {
    case Cmd_Get_USB : /* GUI   Status request of the USB enabled, Application and Enumeration */
                           if (USBState.enabled)
                              temp = (USBState.enabled+1) | (((!USB_ENUM.process_ready)+1)<<4);
                           else
                              temp = 0x11;
                           protocol_DWSendFrame (Rep_Info_USB, &temp,1);
                           break;
    case Cmd_Get_VIDPID_Str : /* GUI   Request of VID and PID */
                           protocol_RevSendFrame (Rep_Info_VIDPID_str, (u8 *)&HID_DeviceDescriptor[8],4);
                           break;
    case Cmd_Get_Serial_Str : /* GUI Request of serial Nr string descriptor */
                           SendTask->DataLength = UnicodeToAscii((u8 *)HID_StringSerial,SendTask->Data);
                           protocol_SendFrame (Rep_Info_Serial_Str, (u8 *)&SendTask->Data,SendTask->DataLength);
                           break;
    case Cmd_Get_Prod_Str : /* GUI Request of product string descriptor */
                           SendTask->DataLength = UnicodeToAscii((u8 *)HID_StringProduct,SendTask->Data);
                           protocol_SendFrame (Rep_Info_Prod_Str, (u8 *)&SendTask->Data,SendTask->DataLength);
                           break;
    case Cmd_Get_Pwr_Def : /* GUI Request of Power definitions */
                           protocol_SendFrame (Rep_Info_Pwr_Def, (u8 *)&HID_ConfigDescriptor[7],2);
                           break;
    case Cmd_Enable_USB  : /* GUI   Start/Stop the USB */
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOn)
                           {
                              if (USBState.enabled == FALSE)
                                 USBStart();
                              i = 0;
                           }
                           else
                           {
                              USBStop();
                              USBState.enabled = FALSE;
                              USB_ENUM.process_ready = FALSE;
                              ReEntryProcess = Dummy;
                           }
                           break;
    case Cmd_Get_Version : /* GUI Request of Version descriptor */
                           protocol_RevSendFrame (Rep_Info_Version, (u8 *)&HID_DeviceDescriptor[12],2);
                           break;
    case Cmd_Enable_USB_APP  : /* GUI Start/Stop the USB-Application (Mouse) */
                           CommTask->Command = Cmd_Idle;  /* none */
                           if (CommTask->Data[0] == TaskSwitchOn)
                           {
                              if (USB_ApplState.enabled == FALSE)
                                 USBApplStart();
                           }
                           else
                           {
                              USBApplStop();
                              USB_ApplState.enabled = FALSE;
                           }
                           break;
    case Cmd_Get_Poll_Intervall : /* GUI Request the polling interval */ // !!!
                           protocol_SendFrame (Rep_Info_Poll_Intervall,(u8 *)&HID_DeviceDescriptor[1],1);
                           break;
    case Cmd_Get_Config_Application : /* GUI Request the applications parameter */
                           protocol_SendFrame (Rep_Info_Config_Application, (u8 *)USB_AppConfig,4);
                           break;
    case Cmd_Set_Config_Application     : /*   GUI Set the applications parameter */
                           CommTask->Command = Cmd_Idle;/* Answer to status request */
                           USB_AppConfig[0] = CommTask->Data[0];
                           USB_AppConfig[1] = CommTask->Data[1];
                           USB_AppConfig[2] = CommTask->Data[2];
                           USB_AppConfig[3] = CommTask->Data[3];
                           break;
    default :              protocol_SendError (Err_NotImplemented);
                           break;
    }
}
