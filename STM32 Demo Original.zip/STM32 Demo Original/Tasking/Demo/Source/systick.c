/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       systick.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

/* Includes ------------------------------------------------------------------*/
#include "system.h"
#include "systick.h"
#include "can.h"
#include "uir_main.h"

u16 Timer_Send = 0;

/*******************************************************************************
* Function Name  : SysTick_Configuration
* Description    : Configures the SysTick module.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Systick_Configuration(void)
{
   /* SysTick end of count event each 1ms with input clock equal to 4MHz (HCLK/8) */
   SysTick_SetReload(4000);
   /* Enable SysTick interrupt */
   SysTick_ITConfig(ENABLE);
   /* Enable the SysTick Counter */
   SysTick_CounterCmd(SysTick_Counter_Enable);
}

void Systick_DeConfiguration(void)
{
   /* SysTick end of count event each 1ms with input clock equal to 4MHz (HCLK/8) */
   SysTick_SetReload(4000);
   /* Enable SysTick interrupt */
   SysTick_ITConfig(DISABLE);
   /* Enable the SysTick Counter */
   SysTick_CounterCmd(SysTick_Counter_Disable);
}
/*******************************************************************************
* Function Name  : SysTick_isr
* Description    : Interrupt service of the SysTick module.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void systick_isr(void)
{
   u8 i;
   
   TimeTick++;
   Timer_Send++;
   
   if(UIR_State == UART_IDRDA_enable)
   {/*UARTIRDA Enabled*/    
      if (Timer_Send >= 0x401)  /*every second*/
      {
         if(((uart_com_buff.receive == TRUE) | (uart_com_buff.transmit == TRUE)) & (uart_com_buff.ready == FALSE) )
         {/*if data not send yet*/
            if(SendTask->Process == 0)
            {
               SendTask->Data[0] = 0x54;                    /* T */
               if(uart_com_buff.receive == TRUE)
                  SendTask->Data[0] = 0x52;                 /* R */
               for(i=0;i<uart_com_buff.pos;i++)
                  SendTask->Data[i+1] = uart_com_buff.data[i];
               SendTask->Data[uart_com_buff.pos+1] = 0x0D;  /* <CR> */                      
               protocol_SendFrame (Cmd_Info_UIR_Data, (u8 *)&SendTask->Data, uart_com_buff.pos+2);
               uart_com_buff.pos = 0;                       /*reset buffer*/
               uart_com_buff.transmit = FALSE;
               uart_com_buff.receive = FALSE;
               uart_com_buff.ready = FALSE;
            }
         }         
      }
   }
   if (cangenerate_countdown)
   {
      if (!--cangenerate_countdown)
      {
         CAN_Transmit(&ucan_msg.can_msg);
         ucan_msg.can_msg.ExtId >>= 3;
         ucan_msg.can_msg.StdId >>= 21;
         
         cangenerate_countdown = cangenerate_repeat;
      }
   }
}
