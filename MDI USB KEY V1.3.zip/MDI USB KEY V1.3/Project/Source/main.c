/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *	Project:    	MDI USB Keyboard
	\file 		main.c	
	\brief 	This file contains infinite while loop to check for keypressed and send USB HID Scan code to Host system.
			Initialization codes such as clock,GPIO,interrupt intializations are made in hardware.c file
			USB HID keyboard descriptors are declared in usb_desc.c and usb_desc.h
			Functions for checking keystate and sending USB HID Key report are in usb_main.c file.
			Function prototypes are declared in system.h
			Common data types used for the STM32F10x firmware library is defined in stm32f10x_type.h
*                      
*	\ Date:    		   2016
* 	\Author:   		  Ace Designers Ltd
*	\Version: 		   v1.3
*	\Changes made: 	 8Mhz External crystal is used as input to PLL and USB operation is working.
				First two row pins PB3 and PB4 are enabled as GPIO and keys are working.
				All key characters are sent including shift key characters.
				Errors reported are solved.
 ********************************************************************/

#include "main.h"
#include "system.h"
#include "systick.h"
#include "hardware.h"
#include "USB_main.h"
#include "stm32f10x_lib.h"
#include "cortexm3_macro.h"


#define countof(a)      (sizeof(a) / sizeof(*(a)))

//#define RTCClockSource_LSE /** Use the external 32 KHz oscillator as RTC clock source */

/** global library structures */
GPIO_InitTypeDef   GPIO_InitStructure;

void NO_PROCESS();
static vu32 TimingDelay; //static variable to to keep track of delay to be decremented.
extern bool bShiftScan;

void main (void)
{
	u8 prevK=0, key = 0;
	int iCount=0;
#ifdef DEBUG
   /* enable debugging of the library structures */
   debug();
#endif
   /* Configure the system clocks */
   RCC_Configuration();
   
   /* NVIC configuration */
   NVIC_Configuration();
   
   //SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
   
   /*systick timer configuraion*/
   SysTick_SetReload(9000);
   
   /*enable systick timer*/
   SysTick_ITConfig(ENABLE);
 
   /* GPIO basic configuration */
   GPIO_Configuration();
  
   /* start USB initialization*/
   USBStart();

	/* Introduce delay after power ON */
	/* During this delay, the Shift LED is made ON, after delay LED is switched OFF 	*/
	
    //GPIO_WriteBit(GPIOB, GPIO_Pin_0, Bit_SET);
	GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_SET);
	Delay(21000);
    GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
	       
	while(1)
	{      
	
		key = keystate(); //Checks if key is pressed and returns SCAN code of key pressed
		if(key!=0) //If key is pressed
		{			
	        prevK = key;	//Store key pressed value
			USBAppl(key);  //if pressed go to USBAppl func to send the key pressed
	        
	        //Provide Continuous scrolling
	        //LArow , RArow , DArow , UArow , PGUP , PGDN , CAN characters 
			if((key == 0X4F) || (key == 0X50) || (key == 0X51) 
			 || (key == 0X52) || (key == 0X4B) || (key == 0X4E) || (key == 0X2A))
			{
			   //Check if same key is pressed, if true give delay 
		       //and send keycode continuosly until key is released.
     			if((keystate() == prevK))
     			{
     				Delay(100);
     				while(keystate()==prevK){
     				    USBAppl(key);
     				}
     			}
     	    }
     	    else if(key == 0x01) //If Shift key is pressed
     	    {
     	        while(keystate()){
    				NO_PROCESS(); //Hex code 01 is used as dummy code, hence no value is sent
    			}
    	    }
 		    else //To avoid continuous scrolling for other keys
    	    {
    	        if((keystate() == prevK)) 
     			{
   			        while(keystate()){
   						USBAppl(0); 
   					}         			     
    			}
    		    else if(bShiftScan)//If previously shiftscancode is sent
    		    {
 			        bShiftScan = 0;
   					while(keystate()){
   						USBAppl(0); 
   					} 
       			}
    	    }
		}
	    else //If no key is pressed
	    {
	       USBAppl(0);
	    }
	}
}              

/*************************************************************************************//**
	\brief 	Introduce delay time in ms.
	\param	nTime - Delay time required in ms
*/
void Delay(u32 nTime) //Delay in ms
{
  /* Enable the SysTick Counter */
  SysTick_CounterCmd(SysTick_Counter_Enable);
  
  TimingDelay = nTime;

  while(TimingDelay != 0);

  /* Disable SysTick Counter */
  SysTick_CounterCmd(SysTick_Counter_Disable);
  /* Clear SysTick Counter */
  SysTick_CounterCmd(SysTick_Counter_Clear);
}
/************************************************ Function End  *******************/

/*************************************************************************************//**
	//\brief 	Called every 1ms by systick timer. 
	//		static varTimingDelay is initialised with delay time required when Delay() is called
	//		varTimingDelay is then decremented every 1ms till it becomes '0'.
	
*/
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}


void NO_PROCESS()
{}
/************************************************ Function End  *******************/
          
#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/

void assert_failed(u8* file, u32 line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/




