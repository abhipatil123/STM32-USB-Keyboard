/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       usb_main.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
	Project:    	MDI USB Keyboard
	\file 		usb_main.c	
	\brief
		Here USB Enumeration is started in function USBStart()
		keystate() and GetKey() functions are used check which key is pressed
		USBAppl() is used to send the scan code of key pressed to Host system
		
		Keys are arranged in 8x8 matrix. All rows and columns are having pullup resistor
		internally.  Active low (0) is sent to each row line one after the other, and at that
		time all the 8 cloumn lines are read.  If any particular key is pressed in that row, 
		active low is read.  Thus exact location of the key pressed is identified.  
		We have lookup table for scan code.  Depending on which key is pressed, the scan code
		of that key is sent to PC.  Same key is used for representing two scan code and the
		selection is done by shift key. Hence there are two scan code table.  One table is for
		keys with shift key in off condition, and other table is for keys with shift key in ON 
		condition.
*	 \Date:       2016
* 	\Author:     Ace Designers Ltd
 ********************************************************************/

#include "system.h"
#include "usb_lib.h"
#include "usb_main.h"
#include "usb_desc.h"
#include "main.h"

#define DEBOUNCE_DELAY  32
#define DEBOUNCE_DELAY_HALF  25

bool bShiftKey=0; 		  	//Indicates if shift key is pressed or not
u8 ikeyPressed;              //Holds the scan code of key pressed
unsigned int row=0;		  	//Row number of key pressed		
unsigned int col=0;		  	//Column number of key pressed	
static unsigned char mod=0x00;	 //To check if modifier key is to be sent
bool keyscan=0;	          	// Indicates if key is pressed or not
bool bShiftScan = 0;		//Indicates if shiftscancode was sent previously

/**< USB hid Scan codes for the keys pressed (without Shift being pressed) */
unsigned char scancode[8][8] = {
/* P, 		N, 		D, 		7, 		8, 		9,	 		L AROW,	 	NOKEY 		*/
0x13, 	0x11, 	0x07, 	0x24, 	0x25, 	0x26, 		0x50, 		0x00, 
/* Z,		Y,		X,		4,		5, 		6,	 		D AROW,		F12 	*/
0x1D, 	0x1C, 	0x1B, 	0x21, 	0x22, 	0x23, 		0x51,		0x45,
/* K, 		I, 		R, 		1, 		2, 		3,			TOGGLE,		F1 	*/
0x0E, 	0x0C, 	0x15, 	0x1E, 	0x1F, 	0x20,		0x29,		0x3A,
/* T, 		S, 		M, 		-, 		0,		.,			KEY,			F2 	*/	   
0x17, 	0x16, 	0x10, 	0x2D, 	0x27,	0x37,		0x00,		0x3B,
/*O, 		G, 		F, 		SPACE,	=,		EOB,			NOKEY,		F3 */ 
0x12, 	0x0A, 	0x09, 	0x2C, 	0x2E,	0x33,		0x00,		0x3C,
/*POS, 	PROG, 	OFFSET, 	ALTER, 	INSERT, 	DEL,			NOKEY,		F4 		*/
0x41, 	0x42, 	0x40, 	0x4D, 	0x49, 	0x4C,		0x00,		0x3D,  		
/* SYSTEM,	MSG,		HELP(?),	CANCEL,	SHIFT,	ENTER,		NOKEY,		F5		*/
0x43,	0x3F, 	0x38, 	0x2A,	0x01, 	0x28, 		0x00, 		0x3E,
/*PGUP,	UPAROW, 	PAGEDN, 	RAROW, 	MODE(HM),	RESET, 		NOKEY, 		F11,     	*/
0x4B,	0x52, 	0x4E, 	0x4F, 	0x4A, 	0x00, 		0x00, 		0x44
};	
 
/**< USB HID Scan codes for the keys pressed (Shift being pressed) */	  
unsigned int shiftscancode[8][8] = {
/* 	Q, 		E, 		A,  		7,		(,  		),			LAROW,	 	NOKEY		*/
	0x14, 	0x08, 	0x04, 	0x24, 	0x26, 	0x27, 		0x50, 		0x00, 
/* 	W, 		V, 		U, 		4, 		[, 		],	  		DAROW,		F12	*/
	0x1A, 	0x19, 	0x18, 	0x21, 	0x2F, 	0x30, 		0x51,		0x45,
/* 	H, 		B, 		J, 		1, 		<, 		>,			TOG(ESC),		F1	*/
	0x0B, 	0x05,	0x0D,	0x1E, 	0x36, 	0x37,		0x29,		0x3A,
/* 	T, 		ScrShot(`), 	C, 		+, 		*,		/,			KEY,			F2		*/
	0x17, 	0x35, 	0x06, 	0x2E, 	0x25,	0x38,		0x00,		0x3B,
/*	L,  		G,		F, 		SPACE, 	', 		#,			NOKEY,		F3	*/
	0x0F,  	0x0A, 	0x09, 	0x2C,	0x34,	0x20,		0x00,		0x3C,
/*	POS, 		PROG, 	OFFSET, 	ALTER, 	INSERT, 	DEL,			NOKEY,		F4 		*/
	0x41, 	0x42, 	0x40, 	0x4D, 	0x49, 	0x4C,		0x00,		0x3D,  		
/* 	SYSTEM,	MSG,		HELP(?),	CANCEL,	SHIFT,	ENTER,		NOKEY,		F5		*/
	0x43,	0x3F, 	0x38, 	0x2A,	0x01, 	0x28, 		0x00, 		0x3E,
/*	PGUP,		UPAROW, 	PAGEDN, 	RAROW, 	MODE(HM),	RESET, 		NOKEY, 		F11,     	*/
	0x4B,	0x52, 	0x4E, 	0x4F, 	0x4A, 	0x00, 		0x00, 		0x44
};	

/*******************************************************************************
* Function Name  : USB_Cable_Config.
* Description    : Software Connection/Disconnection of USB Cable.
* Input          : NewState: new state.
* Output         : None.
* Return         : None
*******************************************************************************/
void USB_Cable_Config (FunctionalState NewState)
{
   if (NewState != DISABLE)
   {
     GPIO_SetBits(GPIOD, GPIO_Pin_2);
   }
   else
   {
      GPIO_ResetBits(GPIOD, GPIO_Pin_2);
   }
}

/*******************************************************************************
* Function Name  : USBStart.
* Description    : USB Enumeration start.
* Input          : None.
* Output         : None.
* Return         : None
*******************************************************************************/
void USBStart (void)
{
   
   USB_Init();
}

/*******************************************************************************
* Function Name  : USBAppl.
* Description    : Create USB HID report and send to PC.
* Input          : Scan code of key to be sent.
* Output        : None.
* Return         : None
*******************************************************************************/
int USBAppl(u8 keys)
{
	u8 hid_report[8];  
	
	if(keys==0x01)  //If shift key is pressed
    {
        Delay(30);
        if(keys==0x01)
        {
			if(bShiftKey)       
            {
              bShiftKey=0;
              GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
          
            }
            else
            {  
                bShiftKey=1;
                GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_SET);
            }            
            return 1;
        }
    }
    	
	/* Key press data is stored in an array according to USB keyboard input report format */
       if(keys!=0)
       {
           hid_report[2]=keys; //Scan code of key pressed
       }
       else
       {
            hid_report[2]=0;
       } 
		hid_report[0]=mod;	//Modifier Value
		hid_report[1]=0x00;
		//hid_report[2]=keys;	
		hid_report[3]=0x00;
		hid_report[4]=0x00;
		hid_report[5]=0x00;
		hid_report[6]=0x00;
		hid_report[7]=0x00;
		 
      /*copy key press data info in ENDP1 Tx Packet Memory Area*/
      UserToPMABufferCopy(hid_report, GetEPTxAddr(ENDP1), 8);
      /* enable endpoint for transmission */
      SetEPTxValid(ENDP1);
      
     //If Shift key is pressed previously turn led off		
     if(keys!=0)
     { 
    	if(bShiftKey)       
        {
            bShiftKey=0;
            GPIO_WriteBit(GPIOA, GPIO_Pin_8, Bit_RESET);
        }
     }
     return 1;
}

/*******************************************************************************
* Function Name  : keystate.
* Description    :   This function checks which key is pressed and returns the scan code of it.
			Getkey() is called to check which col key is pressed
* Input          : None.
* Return         : Scan code of key pressed
*******************************************************************************/     
u8 keystate(void)
{
	//Make all rows pins active(1) intially and then make each row '0' one by one
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_6, Bit_SET);
	GPIO_WriteBit(GPIOB, GPIO_Pin_7, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_9, Bit_SET);
    GPIO_WriteBit(GPIOA, GPIO_Pin_14, Bit_SET);
  
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, Bit_RESET);// row1 pin is grounded
    //Delay(15);
    row=0;
    keyscan=GetKey(); //Check if key is pressed
    if(keyscan){
       return (KeyPressScanCode()); //Return Scan code of key pressed
    }
    else ikeyPressed=0;
              
    GPIO_WriteBit(GPIOB, GPIO_Pin_3, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_RESET);// row2 pin is grounded
    //Delay(15);
    row=1;
    keyscan=GetKey();
     if(keyscan){
       return (KeyPressScanCode());
    }
    else ikeyPressed=0;
   
    GPIO_WriteBit(GPIOB, GPIO_Pin_4, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_RESET);// row3 pin is grounded
	// Delay(15);
    row=2;
    keyscan=GetKey();
     if(keyscan){
        return (KeyPressScanCode());
    }
    else ikeyPressed=0;
   
    GPIO_WriteBit(GPIOB, GPIO_Pin_5, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_6, Bit_RESET);// row4 pin is grounded
    //Delay(15);
    row=3;
    keyscan=GetKey();
    if(keyscan){
        return (KeyPressScanCode());
    }
    else ikeyPressed=0;
     
	GPIO_WriteBit(GPIOB, GPIO_Pin_6, Bit_SET); 
	GPIO_WriteBit(GPIOB, GPIO_Pin_7, Bit_RESET);// row5 pin is grounded
    //Delay(15);
    row=4;
    keyscan=GetKey(); 
    if(keyscan){
        return (KeyPressScanCode());
    }
    else ikeyPressed=0;
                   
    GPIO_WriteBit(GPIOB, GPIO_Pin_7, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_RESET);// row6 pin is grounded
    //Delay(15);
    row=5;
    keyscan=GetKey();
    if(keyscan){
        return (KeyPressScanCode());
    }
    else ikeyPressed=0;
   
    GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_SET);
    GPIO_WriteBit(GPIOB, GPIO_Pin_9, Bit_RESET);// row7 pin is grounded
	// Delay(15);
    row=6;
    keyscan=GetKey();
    if(keyscan){
        return (KeyPressScanCode());
    }
    else ikeyPressed=0;
   
    GPIO_WriteBit(GPIOB, GPIO_Pin_9, Bit_SET);
    GPIO_WriteBit(GPIOA, GPIO_Pin_14, Bit_RESET);// row8 pin is grounded
    //Delay(15);
    row=7;
    keyscan=GetKey();
    
	if(keyscan){
      return (KeyPressScanCode());
    }
    else ikeyPressed=0;
	
    return ikeyPressed;
    
} 
/*******************************************************************************
* Function Name  : GetKey.
* Description    : Detects if key is pressed and which column key is pressed.
* Input          : None.
* Output        : 'col' var is updated with the column key pressed .
* Return         : true if key press is detected else false
*******************************************************************************/
u8 GetKey()
{
    if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12)==0) //Read col 1
	{
		//key press detected
		if((row>=0) && (row<=4) || (row==7))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12)==0)
		{
		  //If key press detected return true and update column no	
		  col=0;    
		  return 1;   
		}
	}
            
    else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==0)//Read col 2
	{
	   if((row>=0) && (row<=4) || (row==7))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==0)
		{
			col=1;
			return 1;
		}
	}
    
    else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==0)//Read col 3
	{
	   if((row>=0) && (row<=4) || (row==7))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
  
	  if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14)==0)
		{
			col=2;
			return 1;
		}
	}
    
    else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)//Read col 4
	{
		if((row>=0) && (row<=4) || (row==7))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)==0)
		{
			col=3;
			return  1;
		}
	}
	else if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6)==0)//Read col 5
	{
		if((row>=0) && (row<=4))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6)==0)
		{
		  col=4;    
		  return 1;   
		}
	}
            
    else if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_7)==0)//Read col 6
	{
		if((row>=0) && (row<=4))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_7)==0)
		{
			col=5;
			return 1;
		}
	}
    
    else if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8)==0)//Read col 7
	{
	    if((row>=0) && (row<=4))
		  Delay(DEBOUNCE_DELAY_HALF);	//Give debounce delay and check again
		else
		   Delay(DEBOUNCE_DELAY);
  
	  if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_8)==0)
		{
			col=6;
			return 1;
		}
	}
    
    else if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9)==0)//Read col 8
	{
		Delay(DEBOUNCE_DELAY);
		if(GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_9)==0)
		{
			col=7;
			return  1;
		}
	}
    else      
       return 0;
    return 0;
}

/*******************************************************************************
* Function Name  : KeyPressScanCode.
* Description    : returns scan code of key pressed.
* Input          : None.
* Output        : None.
* Return         : returns scan code of key pressed.
*******************************************************************************/
u8 KeyPressScanCode()
{
	if(bShiftKey) //Check if shift key is pressed
	{
	    bShiftScan = 1;
		ikeyPressed = shiftscancode[row][col];	//Store scan code value
		
		//To provide alernate character for same usb hid scan code 
		//( , ) , [ , ] , < , > ,  # , ' characters 
		if((ikeyPressed==0x26) || (ikeyPressed==0x27) || (ikeyPressed==0x2E)|| (ikeyPressed==0x25)|| 
    		(ikeyPressed==0x36)|| (ikeyPressed==0x37)|| (ikeyPressed==0x20) || ((row == 6) && (col == 2))) 
    	{
            mod = 0x02;	//0x02 is Modifier value for Shift key
        }
        else
            mod = 0x00;
    }
	else
	{
		ikeyPressed = scancode[row][col];
		if((row == 6) && (col == 2))   //help key(?)
             mod = 0x02;
        else
            mod = 0x00;
    }
	return ikeyPressed;
}
