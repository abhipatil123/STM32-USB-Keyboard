/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       hardware.c
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
	\file 		hardware.c	
	\brief	Clock, NVIC(Interrupt), GPIO intializations are made here
	
*	 \Date:       2016
* 	\Author:     Ace Designers Ltd
 ********************************************************************/

#include "system.h"
#include "hardware.h"
#include "stm32f10x_rcc.h"

ErrorStatus HSEStartUpStatus;
RCC_ClocksTypeDef RCC_ClocksStatus;

 /*******************************************************************************
* Function Name  : RCC_Configuration
* Description      : Configures the different system clocks.
* Input             : None
* Output          : None
* Return           : None
*******************************************************************************/
void RCC_Configuration(void)    
{     
    // 8MHz frequency from external crystal is used as input to PLL
    
    /* RCC system reset(for debug purpose) */
   RCC_DeInit();

   /* Enable HSE */
   RCC_HSEConfig(RCC_HSE_ON);
    
   /* Wait till HSE is ready */
 //  while(RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET);
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if(HSEStartUpStatus == SUCCESS)
  {
    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1); //Internal APB2 clock

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);	//Internal APB1 clock

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* PLLCLK = 8MHz * 6 = 48 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_6);	

    /* Enable PLL */ 
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {
    }

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while(RCC_GetSYSCLKSource() != 0x08)
    {
    }
  }
   
	/* Select USBCLK source */
   RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_Div1);
   
   /* Enable Peripheral clocks */
   RCC_APB1PeriphClockCmd(RCC_APB1ENR_Must, ENABLE);
   RCC_APB2PeriphClockCmd(RCC_APB2ENR_Must, ENABLE);
   
     /* Enable USB clock */
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
   
   
   RCC_GetClocksFreq(&RCC_ClocksStatus);

}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output        : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
   NVIC_InitTypeDef NVIC_InitStructure;
#define VECT_TAB_FLASH

#ifdef  VECT_TAB_FLASH
   /* Set the Vector Table base location at 0x08000000 */
   NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#else  /* VECT_TAB_RAM  */
   /* Set the Vector Table base location at 0x20000000 */
   NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#endif
   /* Configure one bit for preemption priority */
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  
   /* Enable USB low priority interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN_RX0_IRQChannel;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : configure GPIO.
* Input          : None
* Output        : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
	//Make all unused pins as output
    GPIO_StructInit(&GPIO_InitStructure);
    
   //Register for alternate mapping of GPIO's
   //JTAG and SWD Debug modes are disabled 
   AFIO->MAPR = 0X4000000; //To Release PB3/PB4 pins as GPIO
   	
   /* Configure PB.00, PB.01, PB.05 Output push-pull */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
   //PA8 (Shift Led) Output push-pull
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOA, &GPIO_InitStructure);

   /* Configure USB PullUp (PD2) as Out Push pull mode */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOD, &GPIO_InitStructure);
   GPIO_ResetBits(GPIOD, GPIO_Pin_2);
   
   /* Configure Columns pins (SL1-SL4) PortB 15,12,13,14 as Input Pull-Up*/
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
    //Congigure Column pins (SL5-SL8) Port C 6,7,8,9 as Input Pull-Up
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
   GPIO_Init(GPIOC, &GPIO_InitStructure);
  
   //Configure Row pins (RL3-RL7) PB3-PB9  as Output-Drain mode
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
   //Configure Row pins (RL8)-PA14 as Output Drain Mode
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14; 
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_Init(GPIOA, &GPIO_InitStructure);

   //Configure Row pins (RL1-RL2) PB3-PB4  as Output-Drain mode
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_Init(GPIOB, &GPIO_InitStructure);
   
}


