/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       system.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************/
 
#ifndef __SYSTEM_H__
#define __SYSTEM_H__

#include "stm32f10x_lib.h"

// Define NULL
#ifndef NULL
#define NULL (void *)0
#endif

/* function protoypes */
extern void USBStart(void); 	//Function for USB Initialization
extern u8 keystate(void);		//To check if Key is pressed or not and returns scan code of key pressed
extern u8 GetKey(void);			//To check which column key has been pressed
extern void Delay(vu32 ntime);	//Function to call delay in ms

/* global library types */
extern GPIO_InitTypeDef          GPIO_InitStructure;
/* globals */


/* CFGR register bit mask */                               
#define CFGR_PLL_Mask            ((u32)0xFFC0FFFF)
#define CFGR_PLLMull_Mask        ((u32)0x003C0000)
#define CFGR_PLLSRC_Mask         ((u32)0x00010000)
#define CFGR_PLLXTPRE_Mask       ((u32)0x00020000)
#define CFGR_SWS_Mask            ((u32)0x0000000C)
#define CFGR_SW_Mask             ((u32)0xFFFFFFFC)
#define CFGR_HPRE_Reset_Mask     ((u32)0xFFFFFF0F)
#define CFGR_HPRE_Set_Mask       ((u32)0x000000F0)
#define CFGR_PPRE1_Reset_Mask    ((u32)0xFFFFF8FF)
#define CFGR_PPRE1_Set_Mask      ((u32)0x00000700)
#define CFGR_PPRE2_Reset_Mask    ((u32)0xFFFFC7FF)
#define CFGR_PPRE2_Set_Mask      ((u32)0x00003800)
#define CFGR_ADCPRE_Reset_Mask   ((u32)0xFFFF3FFF)
#define CFGR_ADCPRE_Set_Mask     ((u32)0x0000C000)

#endif   /* __SYSTEM_H__ */
