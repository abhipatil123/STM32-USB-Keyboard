/********************************************************************
 * Project:    Tasking-STM32-Stick
 * File:       hardware.h
 *
 * System:     Cortex ARMv7 32 Bit (STM32FRT)
 * Compiler:   Tasking Altuim VX Toolchain v2.01
 *
 * Date:       2007-08-20
 * Author:     Application@Hitex.de
 *
 * Rights:     Hitex Development Tools GmbH
 *             Greschbachstr. 12
 *             D-76229 Karlsruhe
 ********************************************************************
 * Description:
 *
 * This file is part of the Tasking Example chain
 * The code is based on usage of the STmicro library functions
 * This is a small implementation of different features
 * The application runs in ARM mode with high optimization level.
 *
 ********************************************************************
 * History:
 *
 *    Revision 1.0    2007/08/20      Gn
 *    Initial revision
 ********************************************************************
 * This is a preliminary version.
 *
 * WARRANTY:  HITEX warrants that the media on which the SOFTWARE is
 * furnished is free from defects in materials and workmanship under
 * normal use and service for a period of ninety (90) days. HITEX entire
 * liability and your exclusive remedy shall be the replacement of the
 * SOFTWARE if the media is defective. This Warranty is void if failure
 * of the media resulted from unauthorized modification, accident, abuse,
 * or misapplication.
 *
 * DISCLAIMER:  OTHER THAN THE ABOVE WARRANTY, THE SOFTWARE IS FURNISHED
 * "AS IS" WITHOUT WARRANTY OF ANY KIND. HITEX DISCLAIMS ALL OTHER WARRANTIES,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 * NEITHER HITEX NOR ITS AFFILIATES SHALL BE LIABLE FOR ANY DAMAGES ARISING
 * OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE, INCLUDING DAMAGES FOR
 * LOSS OF PROFITS, BUSINESS INTERRUPTION, OR ANY SPECIAL, INCIDENTAL, INDIRECT
 * OR CONSEQUENTIAL DAMAGES EVEN IF HITEX HAS BEEN ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGES.
 ********************************************************************/
#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#define RCC_APB2ENR_Mask        (((Gating_Mask_USART1 | Gating_Mask_SPI | Gating_Mask_TIM1 | Gating_Mask_ADC2 | \
                                 Gating_Mask_ADC1) << 8) | \
                                 Gating_Mask_IOPE | Gating_Mask_IOPD | Gating_Mask_IOPC | \
                                 Gating_Mask_IOPA | Gating_Mask_AFIO)
#define RCC_APB2ENR_Must        (RCC_APB2Periph_GPIOA  | RCC_APB2Periph_GPIOB | \
                                 RCC_APB2Periph_GPIOC  | RCC_APB2Periph_GPIOD | \
                                 RCC_APB2Periph_ADC1   | RCC_APB2Periph_AFIO )
#define RCC_APB1ENR_Mask        (((Gating_Mask_PWR  | Gating_Mask_BKP  | Gating_Mask_CAN)<<24) | \
                                 ((Gating_Mask_USB  | Gating_Mask_I2C2 | Gating_Mask_I2C1 | \
                                   Gating_Mask_USART2)<<16) | \
                                  (Gating_Mask_SPI2<<8) | \
                                   Gating_Mask_TIM4 | Gating_Mask_TIM3 | Gating_Mask_TIM2)
//#define RCC_APB1ENR_Must       ((Gating_Mask_USART3<<16)|(Gating_Mask_WWDG<<8))  /* Gating_Mask_USART3 must be enabled */
#define RCC_APB1ENR_Must        (RCC_APB1Periph_USART3 | RCC_APB1Periph_WWDG | \
                                 RCC_APB1Periph_PWR    | RCC_APB1Periph_BKP  | \
                                 RCC_APB1Periph_TIM2   | RCC_APB1Periph_USB)
                                 

                                 
                                 
/** Puplic function prototypes */
extern void RCC_Configuration(void);
extern void NVIC_Configuration(void);
extern void GPIO_Configuration(void);
;

#endif   /* __HARDWARE_H__ */

 