/******************** (C) COPYRIGHT 2007 STMicroelectronics ********************
* File Name          : stm32f10x_it.c
* Author             : MCD Application Team
* Version            : V1.0
* Date               : 10/08/2007
* Description        : Main Interrupt Service Routines.
*                      This file can be used to describe all the exceptions 
*                      subroutines that may occur within user application.
*                      When an interrupt happens, the software will branch 
*                      automatically to the corresponding routine.
*                      The following routines are all empty, user can write code 
*                      for exceptions handlers and peripherals IRQ interrupts.
********************************************************************************
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "main.h"
#include "system.h"
#include "usb_lib.h"
#include "systick.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/  
//extern vu32 TimeTick; /* global counter */
extern void USB_Istr(void);

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : NMIException
* Description    : This function handles NMI exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(2) NMIException(void)
#else
void NMIException(void)
#endif
{
}

/*******************************************************************************
* Function Name  : HardFaultException
* Description    : This function handles Hard Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(3) __noreturn__ HardFaultException(void)
#else
void HardFaultException(void)
#endif
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : MemManageException
* Description    : This function handles Memory Manage exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(4) __noreturn__ MemManageException(void)
#else
void MemManageException(void)
#endif
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : BusFaultException
* Description    : This function handles Bus Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(5) __noreturn__ BusFaultException(void)
#else
void BusFaultException(void)
#endif
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : UsageFaultException
* Description    : This function handles Usage Fault exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(6) __noreturn__ UsageFaultException(void)
#else
void UsageFaultException(void)
#endif
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/*******************************************************************************
* Function Name  : DebugMonitor
* Description    : This function handles Debug Monitor exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(12) DebugMonitor(void)
#else
void DebugMonitor(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SVCHandler
* Description    : This function handles SVCall exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(11) SVCHandler(void)
#else
void SVCHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : PendSVC
* Description    : This function handles PendSVC exception.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(14) PendSVC(void)
#else
void PendSVC(void)
#endif
{
}
/*amp-st-2016*/
/*******************************************************************************
* Function Name  : SysTickHandler
* Description    : This function handles SysTick Handler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(15) SysTickHandler(void)
#else
void SysTickHandler(void)
#endif
{
  TimingDelay_Decrement();
}
/*amp-end-2016*/
/*******************************************************************************
* Function Name  : WWDG_IRQHandler
* Description    : This function handles WWDG interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(16) __noreturn__ WWDG_IRQHandler(void)
#else
void WWDG_IRQHandler(void)
#endif
{
   while(1);
}

/*******************************************************************************
* Function Name  : PVD_IRQHandler
* Description    : This function handles PVD interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(17) PVD_IRQHandler(void)
#else
void PVD_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TAMPER_IRQHandler
* Description    : This function handles Tamper interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(18) TAMPER_IRQHandler(void)
#else
void TAMPER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : RTC_IRQHandler
* Description    : This function handles RTC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(19) RTC_IRQHandler(void)
#else
void RTC_IRQHandler(void)
#endif
{
   
}

/*******************************************************************************
* Function Name  : FLASH_IRQHandler
* Description    : This function handles Flash interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(20) FLASH_IRQHandler(void)
#else
void FLASH_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : RCC_IRQHandler
* Description    : This function handles RCC interrupt request. 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(21) RCC_IRQHandler(void)
#else
void RCC_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI0_IRQHandler
* Description    : This function handles External interrupt Line 0 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(22) EXTI0_IRQHandler(void)
#else
void EXTI0_IRQHandler(void)
#endif
{
   /*Interruptfunktin for Event Counter*/
   
}

/*******************************************************************************
* Function Name  : EXTI1_IRQHandler
* Description    : This function handles External interrupt Line 1 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(23) EXTI1_IRQHandler(void)
#else
void EXTI1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI2_IRQHandler
* Description    : This function handles External interrupt Line 2 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(24) EXTI2_IRQHandler(void)
#else
void EXTI2_IRQHandler(void)
#endif
{
   
}

/*******************************************************************************
* Function Name  : EXTI3_IRQHandler
* Description    : This function handles External interrupt Line 3 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(25) EXTI3_IRQHandler(void)
#else
void EXTI3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI4_IRQHandler
* Description    : This function handles External interrupt Line 4 request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(26) EXTI4_IRQHandler(void)
#else
void EXTI4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel1_IRQHandler
* Description    : This function handles DMA Stream 1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(27) DMAChannel1_IRQHandler(void)
#else
void DMAChannel1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel2_IRQHandler
* Description    : This function handles DMA Stream 2 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(28) DMAChannel2_IRQHandler(void)
#else
void DMAChannel2_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel3_IRQHandler
* Description    : This function handles DMA Stream 3 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(29) DMAChannel3_IRQHandler(void)
#else
void DMAChannel3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel4_IRQHandler
* Description    : This function handles DMA Stream 4 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(30) DMAChannel4_IRQHandler(void)
#else
void DMAChannel4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel5_IRQHandler
* Description    : This function handles DMA Stream 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(31) DMAChannel5_IRQHandler(void)
#else
void DMAChannel5_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel6_IRQHandler
* Description    : This function handles DMA Stream 6 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(32) DMAChannel6_IRQHandler(void)
#else
void DMAChannel6_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : DMAChannel7_IRQHandler
* Description    : This function handles DMA Stream 7 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(33) DMAChannel7_IRQHandler(void)
#else
void DMAChannel7_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : ADC_IRQHandler
* Description    : This function handles ADC global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(34) ADC_IRQHandler(void)
#else
void ADC_IRQHandler(void)
#endif
{
   /* Clear ADC1 JEOC pending interrupt bit */
   //ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
}

/*******************************************************************************
* Function Name  : USB_HP_CAN_TX_IRQHandler
* Description    : This function handles USB High Priority or CAN TX interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(35) USB_HP_CAN_TX_IRQHandler(void)
#else
void USB_HP_CAN_TX_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USB_LP_CAN_RX0_IRQHandler
* Description    : This function handles USB Low Priority or CAN RX0 interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(36) USB_LP_CAN_RX0_IRQHandler(void)
#else
void USB_LP_CAN_RX0_IRQHandler(void)
#endif
{
   //RemoteRoutine();
       USB_Istr();
    

}

/*******************************************************************************
* Function Name  : CAN_RX1_IRQHandler
* Description    : This function handles CAN RX1 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(37) CAN_RX1_IRQHandler(void)
#else
void CAN_RX1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : CAN_SCE_IRQHandler
* Description    : This function handles CAN SCE interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(38) CAN_SCE_IRQHandler(void)
#else
void CAN_SCE_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : EXTI9_5_IRQHandler
* Description    : This function handles External lines 9 to 5 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(39) EXTI9_5_IRQHandler(void)
#else
void EXTI9_5_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_BRK_IRQHandler
* Description    : This function handles TIM1 Break interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(40) TIM1_BRK_IRQHandler(void)
#else
void TIM1_BRK_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_UP_IRQHandler
* Description    : This function handles TIM1 overflow and update interrupt 
*                  request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(41) TIM1_UP_IRQHandler(void)
#else
void TIM1_UP_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_TRG_COM_IRQHandler
* Description    : This function handles TIM1 Trigger and commutation interrupts 
*                  requests.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(42) TIM1_TRG_CCUP_IRQHandler(void)
#else
void TIM1_TRG_COM_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : This function handles TIM1 capture compare interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(43) TIM1_CC_IRQHandler(void)
#else
void TIM1_CC_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM2_IRQHandler
* Description    : This function handles TIM2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(44) TIM2_IRQHandler(void)
#else
void TIM2_IRQHandler(void)
#endif
{
   
 
}

/*******************************************************************************
* Function Name  : TIM3_IRQHandler
* Description    : This function handles TIM3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(45) TIM3_IRQHandler(void)
#else
void TIM3_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : TIM4_IRQHandler
* Description    : This function handles TIM4 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(46) TIM4_IRQHandler(void)
#else
void TIM4_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C1_EV_IRQHandler
* Description    : This function handles I2C1 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(47) I2C1_EV_IRQHandler(void)
#else
void I2C1_EV_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C1_ER_IRQHandler
* Description    : This function handles I2C1 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(48) I2C1_ER_IRQHandler(void)
#else
void I2C1_ER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C2_EV_IRQHandler
* Description    : This function handles I2C2 Event interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(49) I2C2_EV_IRQHandler(void)
#else
void I2C2_EV_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : I2C2_ER_IRQHandler
* Description    : This function handles I2C2 Error interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(50) I2C2_ER_IRQHandler(void)
#else
void I2C2_ER_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SPI1_IRQHandler
* Description    : This function handles SPI1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(51) SPI1_IRQHandler(void)
#else
void SPI1_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : SPI2_IRQHandler
* Description    : This function handles SPI2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(52) SPI2_IRQHandler(void)
#else
void SPI2_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USART1_IRQHandler
* Description    : This function handles USART1 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(53) USART1_IRQHandler(void)
#else
void USART1_IRQHandler(void)
#endif
{

  
}

/*******************************************************************************
* Function Name  : USART2_IRQHandler
* Description    : This function handles USART2 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(54) USART2_IRQHandler(void)
#else
void USART2_IRQHandler(void)
#endif
{
  
}

/*******************************************************************************
* Function Name  : USART3_IRQHandler replaced by the UART.c implemented handler
* Description    : This function handles USART3 global interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(55) USART3_IRQHandler(void)
#else
void USART3_IRQHandler(void)
#endif
{
  
}

/*******************************************************************************
* Function Name  : EXTI15_10_IRQHandler
* Description    : This function handles External lines 15 to 10 interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(56) EXTI15_10_IRQHandler(void)
#else
void EXTI15_10_IRQHandler(void)
#endif
{
  

}

/*******************************************************************************
* Function Name  : RTCAlarm_IRQHandler
* Description    : This function handles RTC Alarm interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(57) RTCAlarm_IRQHandler(void)
#else
void RTCAlarm_IRQHandler(void)
#endif
{
}

/*******************************************************************************
* Function Name  : USBWakeUp_IRQHandler
* Description    : This function handles USB WakeUp interrupt request.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef TaskingVXtoolset
void __interrupt(58) USBWakeUp_IRQHandler(void)
#else
void USBWakeUp_IRQHandler(void)
#endif
{
}

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
